
 /**
 * @addtogroup io
 * @{
 * @file io.h
 * @brief functions to read and write matrices in double/float/int, display a progress bar,
 * io tools.
 * @}
 */
