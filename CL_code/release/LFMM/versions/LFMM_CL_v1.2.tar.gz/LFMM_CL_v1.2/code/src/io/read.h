/**
 * @file read.h
 *
 * @brief few common defines
 */

#ifndef READ_H
#define READ_H

// separator between elements
#define SEP " "	

// max size of an element (in char)
# define MAX_LENGTH_NB 10

#endif // READ_H
