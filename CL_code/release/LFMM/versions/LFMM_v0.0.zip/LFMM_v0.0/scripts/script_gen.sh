#! /bin/sh
# @(#)Script servant à la création d'une galerie d'image html

K="5"
#rep="1 2 3 4 5 6 7 8 9 10"
rep="1"
#K="1 2"
#rep="1 2"
name=""

for t in $K
do
	for i in $rep
	do
		#name="gen_$t-$i.txt"
		#name1="gen_$t-$i.txt"
		#file="../../Project/simu_ms/neutre/ms_0-$i.txt"
		./LFMM -g gen_data.txt -d gen_cov.txt -N 200 -M 1000 -K $t -n 1000 -b 100
		./LFMM -g gen_data.txt -d gen_cov.txt -N 200 -M 1000 -K $t -n 1000 -b 100
		cp gen_beta.txt $name
		echo "run for $name\n"
	done
done
