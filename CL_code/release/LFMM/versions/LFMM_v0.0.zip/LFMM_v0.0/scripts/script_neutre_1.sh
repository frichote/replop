#! /bin/sh
# @(#)Script servant à la création d'une galerie d'image html

K="1 3 5 10 20 50"
rep="1 2 3 4 5 6 7 8 9 10"
#K="1 2"
#rep="1 2"
name=""

for t in $K
do
	for i in $rep
	do
		name="neutre_1_$t-$i.txt"
		file="../../Project/simu_ms/neutre_1/ms_0-$i.txt"
		./LFMM -i $file -c C_neutre.txt -N 100 -M 1000 -K $t -n 1000 -b 100 -o $name
		echo "run for $name\n"
	done
done
