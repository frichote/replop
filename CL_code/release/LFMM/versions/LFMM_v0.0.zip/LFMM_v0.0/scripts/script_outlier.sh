#! /bin/sh
# @(#)Script servant à la création d'une galerie d'image html

K="1 2 3 4 5 6 7 8 9 10 20 50"
#K="1"
rep="1 2 3 4 5 6 7 8 9 10"
#rep="1"
time="0.01 0.07 0.1 0.2 0.5"
#time="0.01"
#K="1 2"
#rep="1 2"
name=""

for ti in $time
do
for t in $K
do
	for i in $rep
	do
		name="outlier_$ti-$t-$i.txt"
		file="../../Project/simu_ms_bv/R1_$ti-$i.txt"
		C="../../Project/simu_ms_bv/C_$ti.txt"
		./LFMM -i $file -c $C -N 200 -M 1050 -K $t -n 1000 -b 100 -o $name
		echo "run for $name\n"
	done
done
done
