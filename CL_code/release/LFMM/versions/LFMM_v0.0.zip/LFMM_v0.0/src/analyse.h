#ifndef ANALYSE_H
#define ANALYSE_H

void analyse_col(float *data, int N, int M, int *nM, int missing, int* I);

void analyse_row(float *data, int N, int M, int* row, int *nN);

#endif // ANALYSE_H
