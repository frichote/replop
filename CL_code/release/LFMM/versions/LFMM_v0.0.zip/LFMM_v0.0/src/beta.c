#include <stdio.h>
#include <stdlib.h>
#include "beta.h"
#include "data.h"
#include "matrix.h"
#include "cholesky.h"
#include "inverse.h"
#include "rand.h"
#include "thread.h"
#include "thread_beta.h"

extern void slice_mbeta_beta(void *G);
extern void slice_rand_beta(void *G);

void create_m_beta(double* C, float* R, double *U, double *V, double *m_beta, 
		int M, int N, int D, int K, float* datb, int num_thrd) {

	//int i,j,d,k;
	//double *tmp_j = (double *)malloc(N*sizeof(double)); 


	//if (num_thrd > 1) { 
		thread_fct(R, datb,  U, V,C,NULL,m_beta,NULL,NULL,
				K,D, M, N, num_thrd,slice_mbeta_beta,0,0);
	/*
	} else {
		for(j=0; j<M; j++) {
			for (i=0; i<N; i++) {
					tmp_j[i] = (double)(R[i*M+j]); // R(N,M)
					for (d=0; d<D; d++) {
						tmp_j[i] -= U[d*N+i]*V[d*M+j]; // U(D,N) V(D,M)
					}
			}
			for (k=0; k<K; k++) {
				m_beta[k*M+j] = 0;
				for (i=0; i<N; i++)
					m_beta[k*M+j] += C[i*K+k] * tmp_j[i]; // C(N,K)
			}
		}
	}
	free(tmp_j);
	*/
}

void create_CCt(double *tmp, double *C, int K, int N) {

	int k1,k2,i;

	for(k1=0; k1<K; k1++) {
		for(k2=0; k2<K; k2++) {
			for(i=0; i<N; i++)
				tmp[k1*K+k2] += C[i*K+k1]* C[i*K+k2]; // C(N,K)
		}
	}
}

void create_inv_cov_beta(double* inv_cov_beta, double *alpha_beta, double alpha_R,
		int K, double *tmp) {

	int k1,k2;
	double *tmp2 = (double*)calloc(K*K,sizeof(double));


	// alpha_R .* C'*C
	for(k1=0; k1<K; k1++) {
		for(k2=0; k2<K; k2++) {
			tmp2[k1*K+k2] = alpha_R*tmp[k1*K+k2]; 
			if (k1 == k2)
				// alpha_beta .* eye(K)
				tmp2[k1*(K+1)] += alpha_beta[k1];
		}
	}

	// inverse
	if (K==1) {
		inv_cov_beta[0] = 1.0/tmp2[0];
	} else {
		fast_inverse(tmp2,K,inv_cov_beta);
		//cofact(tmp2,K,inv_cov_beta);
	}

	free(tmp2);
} 

void rand_beta(double* beta, double* m_beta, double* inv_cov_beta, double alpha_R, int K, int M, int num_thrd) {

	double* L=(double*)calloc(K*K,sizeof(double));
	//double* mu=(double*)calloc(K,sizeof(double));
	//double* y=(double*)calloc(K,sizeof(double));
	//int j,k,kp;	

	cholesky(inv_cov_beta,K,L);

	//if(num_thrd > 1) {
		thread_fct(NULL, NULL,  NULL, NULL,NULL,beta,m_beta,inv_cov_beta,L,
				K,0, M, 0, num_thrd,slice_rand_beta,0,alpha_R);
	/*
	} else {
	for(j=0;j<M;j++) {
		for(k=0;k<K;k++) {
			mu[k] = 0;
			for(kp=0;kp<K;kp++) {
				mu[k] += inv_cov_beta[k*K+kp] * m_beta[kp*M+j]; // inv(K,K) 
			}
			mu[k] *= alpha_R;
		}
		mvn_rand(mu,L,K,y);
		for(k=0;k<K;k++)
			beta[k*M+j] = y[k]; // beta(K,M)
	}
	}*/
	free(L);
	//free(mu);
	//free(y);
}
