#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "data.h"
#include "error.h"
#include "thread_var.h"
#include "rand.h"

int check_mat(double *A, int n) {

	int i;

	for(i=0;i<n;i++) {
		if (isnan(A[i]))
			return 1;
	}
	return 0;

}

void zscore_calc(double *beta, double *mean, double *sum, double *sum2, int n, int cur) {

	int i;
	double var;

	for(i=0;i<n;i++) {
		var = ((sum2[i] - 2*mean[i]*sum[i] + mean[i]*mean[i]*cur)/(double)(cur-1));
		beta[i] = (mean[i])/sqrt(var);
	}

}

void update_sum(double *beta, double *sum, int n) {

	int i;

	for(i=0;i<n;i++) 
		sum[i] += beta[i];

}

void update_sum2(double *beta, double *sum2, int n) {

	int i;

	for(i=0;i<n;i++) 
		sum2[i] += (beta[i] * beta[i]);

}

void update_mean(double *beta, double *mean, int n, int cur) {

	int i;

	for(i=0;i<n;i++) 
		mean[i] = ((double)(cur-1)*mean[i] + beta[i])/(double)cur;

}

void modify_C(double *C, int N, int K, double *Cpp) {

	int i,k;

	for (i=0; i<N; i++)
		Cpp[i*K] = 1.0;

	for (i=0; i<N; i++) {
		for (k=0; k<K-1; k++) {
			Cpp[i*K+k+1] = C[i*(K-1)+k];
		}
	}


}

void create_I(float* dat, int* I, int N, int M) {

	int i;
	for (i=0; i<N*M; i++) {
		if (dat[i] == -9)
			I[i] = 0;
		else
			I[i] = 1;
	}
}

void read_data_float(char *file_data, int N, int M, float* dat) {

	FILE *file = NULL;
	int i,j, tmp = 1;
	char st;

	file = fopen(file_data,"r");
	if (!file)
		print_error("open",file_data,0);

	for(i=0; i<N; i++) {
		for(j = 0; j < M-1; j++) {
			tmp *= fscanf(file, "%g ", &dat[i*M+j]);        
		}
		tmp *= fscanf(file, "%g",&dat[i*M+(M-1)]);        
		tmp *= fscanf(file, "%c",&st);        
		if(!strcmp(&st,"\n")) {
			tmp=1;
		} else if(!strcmp(&st," ")) {
			tmp *= fscanf(file, "%c",&st);        
			if(!strcmp(&st,"\n"))
				tmp=1;
			else
				tmp=0;
		} else {
			tmp=0;
		}
	
	}
	tmp *= fscanf(file, "EOF");        
	fclose(file);

	if (!tmp)
		print_error("read",file_data,0);
}

/*
void read_data_float2(char *file_data, int N, int M, float* dat) {

	FILE* m_File=NULL;
	int	i = 0;
	int	j;
	
	char	szbuff[max_char_per_line];
	char* token;
	char sep = " ";
	int lmax = N;
	int cmax = M;
	
	// On réinitialise le compteur de ligne car i;a été incrémenté lors de l'iniatialisation
	i = 0;
	
	// On ouvre le fichier en lecture seule et en mode texte
	m_File = fopen(file_data,"rt");

	// On vérifie qu'il n'y ai pas eu d'erreur pendant l'ouverture du fichier
        if (!m_File) {
                printf("Error: unable to read file %s.\n",file_data);
                exit(1);
        }

	// On lit le fichier ligne a ligne et on stocke les valeurs dans un tableau d'entier
	// La boucle while a l'avantage de permettre la lecture d'un fichier sans connaitre son nombre de ligne exact
	// et nous évite donc de faire bugger le programme
	// Le "feof" veut "End Of File". On lit donc jusuqu'à la fin du fichier
	while(!feof(m_File))
	{
		if (i >= lmax) {
			printf("Error: File %s contains more than %d lines\n",file_data, N);
			fclose(m_File);
			exit(1);
		}
		j = 0;
		// On récupere la ligne courante du fichier
		fgets(szbuff,max_char_per_line,m_File);
		// On decoupe la ligne selon le charactere de séparation SEP (" ")
		token = strtok(szbuff,sep);
		// On lit les éléments découpés un à un et on les stocke dans le tableau Tab
		while(token != NULL)
		{
			if (j >= cmax) {
				printf("Error: File %s contains more than %d columns at line\n",file_data, M,i+1);
				fclose(m_File);
				exit(1);
			}
			// On stocke la valeur lue dans le tableau
			dat[i*M+j] = atoi(token);
			// On lit l'element suivant retourner par strtok
			token = strtok(NULL,sep);
			// On incremente le compteur des ordonnées
			j++;
		}
		// On incrémente le compteur des abscisses
		i++;
	}

	
	fclose(m_File);

}
*/

void read_data_double(char *file_data, int N, int M, double* dat) {

	FILE *file = NULL;
	int i, j, tmp = 1;
	float tmp2;
	char st;

	file = fopen(file_data,"r");
	if (!file) 
		print_error("open",file_data,0);

	for(i=0; i<N; i++) {
		for(j = 0; j < M-1; j++) {
			tmp *= fscanf(file, "%g ", &tmp2);
			dat[i*M+j] = (double)tmp2;        
		}
		tmp *= fscanf(file, "%g",&tmp2);        
		dat[i*M+(M-1)] = (double)tmp2;        

		tmp *= fscanf(file, "%c",&st);        
		if(!strcmp(&st,"\n")) {
			tmp*=1;
		} else if(!strcmp(&st," ")) {
			tmp *= fscanf(file, "%c",&st);        
			if(!strcmp(&st,"\n"))
				tmp*=1;
			else
				tmp*=0;
		} else {
			tmp*=0;
		}
	
	}
	tmp *= fscanf(file, "EOF");        
	fclose(file);

	if (!tmp)
		print_error("read",file_data,0);
}

void read_data_int(char *file_data, int N, int M, int* dat) {

	FILE *file = NULL;
	int i,j, tmp=1;
	char st;

	file = fopen(file_data,"r");
	if (!file)
		print_error("open",file_data,0);

	for(i=0; i<N; i++) {
		for(j = 0; j < M-1; j++) {
 			tmp *= fscanf(file, "%d ", &dat[i*M+j]);        
		}
		tmp *= fscanf(file, "%d",&dat[i*M+(M-1)]);        
		tmp *= fscanf(file, "%c",&st);        
		if(!strcmp(&st,"\n"))
			tmp*=1;
		else if(!strcmp(&st," ")) {
			tmp *= fscanf(file, "%c",&st);        
			if(!strcmp(&st,"\n"))
				tmp*=1;
			else
				tmp*=0;
		} else {
			tmp*=0;
		}
	
	}
	tmp *= fscanf(file, "EOF");        
	fclose(file);

	if (!tmp)
		print_error("read",file_data,0);
}

void write_data_float(char *file_data, int N, int M, float* dat) {

	FILE *file = NULL;
	int i,j;

	file = fopen(file_data,"w");
	if (!file) 
		print_error("open",file_data,0);

	for(i=0; i<N; i++) {
		for(j = 0; j < M-1; j++) {
			fprintf(file, "%G ", dat[i*M+j]);        
		}
		fprintf(file, "%G", dat[i*M+(M-1)]);        
		fprintf(file, "\n");        
	}
	fclose(file);
}

void write_zscore_double(char *file_data, int N, int M, double* dat) {

	FILE *file = NULL;
	int i,j;

	file = fopen(file_data,"w");
	if (!file) 
		print_error("open",file_data,0);

	for(i=1; i<N; i++) {
		for(j = 0; j < M-1; j++) {
			fprintf(file, "%G ", dat[i*M+j]);        
		}
		fprintf(file, "%G", dat[i*M+(M-1)]);        
		fprintf(file, "\n");        
	}
	fclose(file);
}

void write_data_double(char *file_data, int N, int M, double* dat) {

	FILE *file = NULL;
	int i,j;

	file = fopen(file_data,"w");
	if (!file) 
		print_error("open",file_data,0);

	for(i=0; i<N; i++) {
		for(j = 0; j < M-1; j++) {
			fprintf(file, "%G ", dat[i*M+j]);        
		}
		fprintf(file, "%G", dat[i*M+(M-1)]);        
		fprintf(file, "\n");        
	}
	fclose(file);
}

void print_data(float *dat, int N, int M) {

	int i,j;

	for(i=0; i<N; i++) {
		for(j = 0; j < M; j++) {
			printf("%f ", dat[i*M+j]);        
		}
		printf("\n");        
	}
}

void clean_data(float *dat, int*col, int N, int M, int nM) {
	int i,j,jp;
	float *tmp, *tmp2;
	int newM;

	if(nM) {
		newM = M - nM;
		tmp = (float*)malloc(N*newM*sizeof(float));
		jp = 0;
		for(j = 0; j < M; j++) {
			if(!col[j]) {	
				for(i=0; i<N; i++) {
					tmp[i*M+jp] = dat[i*M+j];
				}
				jp ++;
			}
		}
		tmp2 = dat;
		free(tmp2);
		dat = tmp;
	}
}

double var_data(float *R, double *U, double *V, double *C, double *beta, int N, int M, int K, int D, int num_thrd) {

	int i,j,k,d;
	double mean;
	double tmp1,tmp2;
	double var;

	if (num_thrd > 1) {
		thrd_var(R,U,V,C,beta,K,D,M,N,num_thrd,slice_mean,0,&mean);
		mean /= N*M;
		thrd_var(R,U,V,C,beta,K,D,M,N,num_thrd,slice_var,mean,&var);
		return var/(N*M -1);


	} else {
		mean = 0;
		for(i=0;i<N;i++) {
			for(j=0;j<M;j++) {
				tmp1 = 0;
				for(k=0;k<K;k++)
					tmp1 += C[i*K+k]*beta[k*M+j];
				tmp2 = 0;
				for(d=0;d<D;d++)
					tmp2 += U[d*N+i]*V[d*M+j];
				mean += (double)(R[i*M+j])-tmp1-tmp2;
			}
		}
		mean /= N*M;

		var = 0;
		for(i=0;i<N;i++) {
			for(j=0;j<M;j++) {
				tmp1 = 0;
				for(k=0;k<K;k++)
					tmp1 += C[i*K+k]*beta[k*M+j];
				tmp2 = 0;
				for(d=0;d<D;d++)
					tmp2 += U[d*N+i]*V[d*M+j];
				var += ((double)(R[i*M+j])-tmp1-tmp2 - mean)*((double)(R[i*M+j])-tmp1-tmp2 - mean);
			}
		}
		return var/(N*M-1);
	}

}

void inputation(float *R, double *U, double *V, double *C, double *beta, int *I, int N, int M, int K, int D) {

	int i,j,k,d;
	double tmp1, tmp2;

	for(i=0;i<N;i++) {
		for(j=0;j<M;j++) {
			if (!I[i*M+j]) {
				tmp1 = 0;
				for(k=0;k<K;k++)
					tmp1 += C[i*K+k]*beta[k*M+j];
				tmp2 = 0;
				for(d=0;d<D;d++)
					tmp2 += U[d*N+i]*V[d*M+j];
				R[i*M+j] = (float)(tmp1+tmp2);
			}
		}
	}
}
