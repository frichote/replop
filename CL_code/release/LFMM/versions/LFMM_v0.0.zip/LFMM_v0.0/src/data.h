#ifndef DATA_H
#define DATA_H

int check_mat(double *A, int n);

void write_zscore_double(char *file_data, int N, int M, double* dat);

void zscore_calc(double *beta, double *mean, double *sum, double *sum2, int n, int cur);

void update_sum(double *beta, double *sum, int n);

void update_sum2(double *beta, double *sum2, int n);

void update_mean(double *beta, double *mean, int n, int cur);

void create_I(float* dat, int* I, int N, int M);

void read_data_float(char *file_data, int N, int M, float* dat);

void read_data_float2(char *file_data, int N, int M, float* dat);

void read_data_double(char *file_data, int N, int M, double* dat);

void read_data_int(char *file_data, int N, int M, int* dat);

void print_data(float *dat, int N, int M);

void clean_data(float *dat, int*col, int N, int M, int n);

void modify_C(double *C, int N, int K, double *Cpp);

void write_data_float(char *file_data, int N, int M, float* dat);

void write_data_double(char *file_data, int N, int M, double* dat);

double var_data(float *R, double *U, double *V, double *C, double *beta, int N, int M, int K, int D, int num_thrd);

void inputation(float *R, double *U, double *V, double *C, double *beta, int *I, int N, int M, int K, int D);

#endif // DATA_H
