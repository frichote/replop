#ifndef INVERSE_H
#define INVERSE_H
// return inv the inverse of A, a DxD matrix
// required: memory allocated
void fast_inverse(double* A, int D, double* inv);

double detrm( double* a, int k);

void cofact( double* num, int f, double *inv );

void trans( double* num, double* fac, int r, double* inv);

#endif // INVERSE_H
