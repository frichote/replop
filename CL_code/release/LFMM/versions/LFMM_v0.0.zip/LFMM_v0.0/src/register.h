#ifndef REGISTER_H
#define REGISTER_H

void analyse_param(     int argc, char *argv[],
                        int *N, int* M, int* K, int* Niter, int* burn,
                        int *m, char *output, char *input, char *cov_file,
                        int* g_data, int* g_cov, int* num_thrd);

#endif // REGISTER_H
