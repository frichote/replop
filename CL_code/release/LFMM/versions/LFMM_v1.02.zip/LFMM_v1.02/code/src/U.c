/*
    LFMM, file: U.c
    Copyright (C) 2012 Eric Frichot

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include <stdio.h>
#include <stdlib.h>
#include "U.h"
#include "data.h"
#include "matrix.h"
#include "cholesky.h"
#include "inverse.h"
#include "rand.h"
#include "thread_U.h"
#include "thread.h"

extern void slice_mU_U(void *G);
extern void slice_rand_U(void *G);
extern void slice_inv_cov_U(void *G);

void create_m_U(double* V, float* R, double *C, double *beta, double *m_U, 
		int M, int N, int D, int K, float *datb, int num_thrd) {

	//int i,j,d,k;
	//double *tmp_i = (double *)malloc(M*sizeof(double)); 

	//if (num_thrd > 1) { 
		thread_fct(R, datb,  NULL, V,C,beta,m_U,NULL,NULL,
				K,D, M, N, num_thrd,slice_mU_U,0,0);
	/*
	} else {
	for(i=0; i<N; i++) {
		for (j=0; j<M; j++) {
				tmp_i[j] =(double)(R[i*M+j]);
				for (k=0; k<K; k++) {
					tmp_i[j] -= C[i*K+k]*beta[k*M+j];
				}
		}
		for (d=0; d<D; d++) {
			m_U[i*D+d] = 0;
			for (j=0; j<M; j++)
				m_U[i*D+d] += V[d*M+j] * tmp_i[j];
		}
	}
	}
	free(tmp_i);
	*/
}

void create_inv_cov_U(double* inv_cov_U, double alpha, double alpha_R, double *V, 
		     int D, int M, int num_thrd) {

	//int d1,d2,j;
	double *tmp2 = (double*)calloc(D*D,sizeof(double));

	//if(num_thrd > 1) {
		thread_fct(NULL, NULL,  NULL, V,NULL,NULL,NULL,tmp2,NULL,
				0,D, M, 0, num_thrd,slice_inv_cov_U,alpha,alpha_R);
	/*
	} else {
	for(d1=0; d1<D; d1++) {
		for(d2=0; d2<D; d2++) {
			tmp2[d1*D+d2] = 0;
			for(j=0; j<M; j++)
				tmp2[d1*D+d2]  += (V[d1*M+j])* (V[d2*M+j]);
			tmp2[d1*D+d2]  *= alpha_R;
		}
		tmp2[d1*(D+1)] += alpha;
	}	
	}
	*/	

	// inverse tmp 
	if (D == 1) {
		inv_cov_U[0] = 1/tmp2[0];
	} else {
		fast_inverse(tmp2,D,inv_cov_U);
	}

	free(tmp2);
} 

void rand_U(double* U, double* m_U, double* inv_cov_U, double alpha_R, int D, int N, int num_thrd) {

	double* L=(double*)calloc(D*D,sizeof(double));
	//double* mu=(double*)calloc(D,sizeof(double));
	//double* y=(double*)calloc(D,sizeof(double));
	//int i,d,dp;	

	
	cholesky(inv_cov_U,D,L);

	//if(num_thrd > 1) {
		thread_fct(NULL, NULL,  U, NULL,NULL,NULL,m_U,inv_cov_U,L,
				0,D, 0, N, num_thrd,slice_rand_U,0,alpha_R);
	/*
	} else {
	for(i=0;i<N;i++) {
		for(d=0;d<D;d++) {
			mu[d] = 0;
			for(dp=0;dp<D;dp++) {
				mu[d] += inv_cov_U[d*D+dp] * m_U[i*D+dp];
			}
			mu[d] *= alpha_R;
		}
		mvn_rand(mu,L,D,y);
		for(d=0;d<D;d++)
			U[d*N+i] = y[d];
	}
	}
	*/
	free(L);
	//free(mu);
	//free(y);
}
