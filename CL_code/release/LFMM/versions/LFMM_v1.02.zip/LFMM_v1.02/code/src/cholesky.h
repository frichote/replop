#ifndef CHOLESKY_H
#define CHOLESKY_H

void cholesky(double* A, int n, double* L);

#endif // CHOLESKY_H
