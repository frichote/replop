#ifndef ERROR_H
#define ERROR_H

void print_error(char* msg, char* file, int n);

#endif // ERROR_H
