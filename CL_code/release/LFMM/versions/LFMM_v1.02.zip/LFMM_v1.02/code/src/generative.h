#ifndef GENERATIVE_H
#define GENERATIVE_H

void generate_data(float *data, double *beta, double* U, double* V,  double* C, int N, int M, int K, int D);

#endif // GENERATIVE_H
