#ifndef MATRIX_H
#define MATRIX_H
#include <math.h> 

void dble_sum2(double* A, int K, int M, double *res, double epsilon);
	
int diff_int(int *A,int *B, int n);

double diff(double *A, double *B, int n);

void ones(float* A, int size);

double dble_sum(double* A, int size);

void copy_vect(double *in, double *out, int size);

float* prod(float *A, float *B, int n, float alpha);

float norm_1(float *A, float *B, int n);

int vect_max(int *v, int n, int max);

int vect_min(int *v, int n, int min);

int imax(int a, int b);

int imin(int a, int b);

void basic_prod(float *a, float *b, float *res, int size);

#endif // MATRIX_H

