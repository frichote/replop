#ifndef NORMALIZE_H
#define NORMALIZE_H

void normalize_data(float *data, int N, int M, int* I, int missing_data);

void normalize_cov(double *C, int N, int K);

#endif // NORMALIZE_H
