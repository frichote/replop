#ifndef PRINT_H
#define PRINT_H

void print_licence();

void print_head_licence();

void print_mat(double*A, int N, int M);

void print_help();

void print_head();

void print_summary (     int N, int M, int K, int D, int Niter, int burn,
                        int m, char *output, char *input, char *cov_file, int num_thrd);


#endif // PRINT_H
