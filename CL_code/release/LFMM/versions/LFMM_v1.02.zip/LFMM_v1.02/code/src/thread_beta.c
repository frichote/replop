/*
    LFMM, file: thread_beta.c
    Copyright (C) 2012 Eric Frichot

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include "thread.h"
#include "rand.h"
#include "thread_beta.h"
#include <string.h>
#include <math.h>
#include <time.h>
#include <float.h>

void slice_mbeta_beta(void* G) {

	Matrix Ma = (Matrix) G;
	float *R = Ma->R;
	double *U = Ma->U;
	double *V = Ma->V;
	double *C = Ma->C;
	double *m_beta = Ma->m;
	int N = Ma->N;
	int M = Ma->M;
	int K = Ma->K;
	int D = Ma->D;
	double *tmp_j = (double *)malloc(N*sizeof(double));
	int nb_data = M;
	int s = Ma->slice;
	int num_thrd = Ma->num_thrd;
	int from = (s * nb_data)/num_thrd; // note that this 'slicing' works fine
	int to = ((s+1) * nb_data)/num_thrd; // even if SIZE is not divisible by num_thrd
	int i,j,k,d;

	for(j=from; j<to; j++) {
		for (i=0; i<N; i++) {
				tmp_j[i] = (double)(R[i*M+j]); // R(N,M)
				for (d=0; d<D; d++) {
					tmp_j[i] -= U[d*N+i]*V[d*M+j]; // U(D,N) V(D,M)
				}
		}
		for (k=0; k<K; k++) {
			m_beta[k*M+j] = 0;
			for (i=0; i<N; i++)
				m_beta[k*M+j] += C[i*K+k] * tmp_j[i]; // C(N,K)
		}
	}
	free(tmp_j);
}

void slice_rand_beta(void* G) {

	Matrix Ma = (Matrix) G;
	double *m_beta = Ma->m;
	double *inv_cov_beta = Ma->inv_cov;
	double *beta = Ma->beta;
	double *L = Ma->L;
	double alpha_R = Ma->alpha_R;
	int M = Ma->M;
	int K = Ma->K;
	int nb_data = M;
	int s = Ma->slice;
	int num_thrd = Ma->num_thrd;
	int from = (s * nb_data)/num_thrd; // note that this 'slicing' works fine
	int to = ((s+1) * nb_data)/num_thrd; // even if SIZE is not divisible by num_thrd
	int j,k,kp;
        double* mu=(double*)calloc(K,sizeof(double));
        double* y=(double*)calloc(K,sizeof(double));


	for(j=from; j<to; j++) {
	                for(k=0;k<K;k++) {
                        mu[k] = 0;
                        for(kp=0;kp<K;kp++) {
                                mu[k] += inv_cov_beta[k*K+kp] * m_beta[kp*M+j]; // inv(K,K) 
                        }
			mu[k] *= alpha_R;
                }
                mvn_rand(mu,L,K,y);
                for(k=0;k<K;k++)
                        beta[k*M+j] = y[k]; // beta(K,M)
	}
	free(mu);
	free(y);
}

