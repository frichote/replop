#!/bin/sh

cd code
make clean
make

if [ ! -e "LFMM" ]; then
	echo "\nERROR: an error occured during the compilation of LFMM command-line program."
	cd ..
	exit 1
else
mv LFMM ..
fi
cd ..

echo "\nSUCCESS: LFMM command-line program was compiled without error."
exit 0
# Error a ne pas oublier.
#cp code/src/LFMM_GUI ./
