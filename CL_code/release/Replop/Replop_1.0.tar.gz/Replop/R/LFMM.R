LFMM <- function(input_file, 
		variable_file, 
		K,
		nd = NULL,
		all = FALSE,
		output_file = NULL, load.out = TRUE,
		missing_data = FALSE,
		num_CPU = 1,
		num_iterations = 3000,
		num_burnin = 1000,
		seed = -1, 
		DIC_file = NULL, load.dic = FALSE) 
{

        # test arguments and init
	# input file
        if(missing(input_file))
                stop("'input_file' argument is missing.")
        else if (!is.character(input_file))
                stop("'input_file' argument has to be of type character.")
	# cov file
        if(missing(variable_file))
                stop("'variable_file' argument is missing.")
        else if (!is.character(variable_file))
                stop("'variable_file' argument has to be of type character.")
	# K
        if(missing(K))
                stop("'K' argument is missing.")
        if (!missing(K) && (!is.integer(K) || K < 0))
                stop("'K' argument has to be of type integer and not negative.")
	# nd
        if (!missing(nd) && (!is.integer(nd) || nd <= 0))
                stop("'nd' argument has to be of type integer and positive.")
	# all
        if (!missing(all) && !is.logical(all)) {
                stop("'all' argument has to be of type logical.")
	} else if (missing(all)) {
		all_int = 0;
	} else {
		all_int = 1;
	}
	# output_file
        if (!missing(output_file) && !is.character(output_file))
                stop("'output_file' argument has to be of type character.")
        else if (missing(output_file))
                output_file = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1.zscore", input_file)
	# missing_data  
        if (!missing(missing_data) && !is.logical(missing_data)) {
                stop("'missing_data' argument has to be of type logical.")
	} else if (missing(missing_data)) {
		missing_data_int = 0
	} else {
		missing_data_int = 1;
	}
	# CPU	
        if (!missing(num_CPU) && !is.integer(num_CPU))
                stop("'num_CPU' argument has to be of type integer.")
        else if (missing(num_CPU) || (!missing(num_CPU) && num_CPU <= 0))
                num_CPU = 1;
        # num_iterations
        if (!missing(num_iterations) && !is.integer(num_iterations))
                stop("'num_iterations' argument has to be of type integer.")
        else if (!missing(num_iterations) && num_iterations < 0)
                num_iterations = 0
        else if (missing(num_iterations))
                num_iterations = 3000;
        # num_burnin
        if (!missing(num_burnin) && (!is.integer(num_burnin)))
                stop("'num_burnin' argument has to be of type integer.")
        else if (!missing(num_burnin) && num_burnin < 0)
                num_burnin = 0
        else if (missing(num_burnin))
                num_burnin = 1000
	if (num_burnin >= num_iterations) {
                stop("the number of iterations for burnin (num_burnin) is greater than the number total of iterations (num_iterations)")
	}
	# seed
        if (!missing(seed) && !is.integer(seed))
                stop("'seed' argument has to be of type integer.")
	# DIC_file
        if (!missing(DIC_file) && !is.character(DIC_file))
                stop("'DIC_file' argument has to be of type character.")
        else if (missing(DIC_file))
                DIC_file = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1.dic",input_file)
	# load.out
       	if (!missing(load.out) && !is.logical(load.out))
                stop("'load.out' argument has to be of type logical.")
	# load.dic
       	if (!missing(load.dic) && !is.logical(load.dic))
                stop("'load.dic' argument has to be of type logical.")


    	.C("R_LFMM", 
		as.character(input_file),
		as.character(output_file),
		as.character(variable_file),
		as.character(DIC_file),
		as.integer(nd),
		as.integer(K),
		as.integer(num_iterations),
		as.integer(num_burnin),
		as.integer(num_CPU),
		as.integer(seed),
		as.integer(missing_data_int),
		as.integer(all_int)
	);

	if (load.out && load.dic) {
		out = read.zscore(output_file);
		dic = read.dic(DIC_file);
		list(out, dic);
	} else if (load.out && !load.dic) {	
		out = read.zscore(output_file);
		list(out, DIC_file);
	} else if (!load.out && load.dic) {
		dic = read.dic(DIC_file);
		list(output_file, dic)
	} else {
		list(output_file, DIC_file)
	}
}
