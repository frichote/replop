
createDataSet <- function(input_file, output_file = NULL , ploidy = 2, seed = -1, percentage = 0.05) 
{
	# test arguments and init
	# input file
    	if(missing(input_file)) 
		stop("'input_file' argument is missing.")
	else if (!is.character(input_file))
		stop("'input_file' argument has to be of type character.")
	# output file	
	if (!missing(output_file) && !is.character(output_file))
		stop("'output_file' argument has to be of type character.")
	else if (missing(output_file))
		output_file = sub("([^.]+)\\.[[:alnum:]]+$", "\\1_I.geno",input_file)
	# ploidy	
	if (!missing(ploidy) && (!is.integer(ploidy) || ploidy <= 0))
		stop("'ploidy' argument has to be of type integer and positive.")
	else if (missing(ploidy))
		ploidy = 2;	
	# seed
	if (!missing(seed) && !is.integer(seed))
		stop("'seed' argument has to be of type integer.")
	# percentage
	if (!missing(percentage) && (!is.double(percentage) || percentage <= 0 || percentage >= 1))
		stop("'percentage' argument has to be of type double and between 0 and 1.")
	else if (missing(percentage))
		percentage = 0.05;	

	# run method
    .C("R_createDataSet", 
	as.character(input_file),
	as.integer(ploidy),
	as.integer(seed),
	as.double(percentage),
	as.character(output_file)
	);

	# create output 
	output_file;
}
