
createDataSet <- function(input_file, output_file = NULL , ploidy = NULL, seed = NULL, percentage = NULL) {

	# test arguments and init
    	if(missing(input_file)) 
		stop("'input_file' argument is missing.")
	else if (!is.character(input_file))
		stop("'input_file' argument has to be of type character.")

	if (!missing(output_file) && !is.character(output_file))
		stop("'output_file' argument has to be of type character.")
	else if (missing(output_file))
		output_file = gsub("(.*)\\.geno","\\1_I.geno",input_file,perl=TRUE);
		
	if (!missing(ploidy) && !is.integer(ploidy))
		stop("'ploidy' argument has to be of type integer.")
	else if (missing(ploidy))
		ploidy = 2;	

	if (!missing(seed) && !is.integer(seed))
		stop("'seed' argument has to be of type integer.")

	if (!missing(percentage) && !is.double(percentage))
		stop("'percentage' argument has to be of type double.")
	else if (missing(percentage))
		percentage = 0.05;	


	# run method
    .C("R_createDataSet", 
	as.character(input_file),
	as.integer(ploidy),
	as.integer(seed),
	as.double(percentage),
	as.character(output_file)
	);

	# create output 
	output_file;
}
