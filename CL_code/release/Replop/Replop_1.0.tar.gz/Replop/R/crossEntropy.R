
crossEntropy <- function(genotype_file, K, missing_data_file = NULL, Q_file = NULL, 
	F_file = NULL, ploidy = 2) {

	# test arguments and init
	# genotype file
    	if(missing(genotype_file)) 
		stop("'genotype_file' argument is missing.")
	else if (!is.character(genotype_file))
		stop("'genotype_file' argument has to be of type character.")
	# K
    	if(missing(K)) 
		stop("'K' argument is missing.")
	if (!missing(K) && (!is.integer(K) || K <= 0))
		stop("'K' argument has to be of type integer and positive.")

	# masked data file
	if (!missing(missing_data_file) && !is.character(missing_data_file))
		stop("'output_file' argument has to be of type character.")
	else if (missing(missing_data_file))
		missing_data_file = gsub("(.*)\\.geno","\\1_I.geno",genotype_file,perl=TRUE);
	# Q file	
	if (!missing(Q_file) && !is.character(Q_file))
		stop("'Q_file' argument has to be of type character.")
	else if (missing(Q_file)) {
		Q_file = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1_I.",genotype_file)
		Q_file = paste(Q_file,K,".Q",sep="")
	}
	# F file
	if (!missing(F_file) && !is.character(F_file))
		stop("'F_file' argument has to be of type character.")
	else if (missing(F_file)) {
		F_file = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1_I.",genotype_file)
		F_file = paste(F_file,K,".F",sep="")
	}
	# ploidy
	if (!missing(ploidy) && (!is.integer(ploidy) || ploidy <= 0))
		stop("'ploidy' argument has to be of type integer and positive.")
	else if (missing(ploidy))
		ploidy = 2;	


	# run method
    	.C("R_crossEntropy", 
		as.character(genotype_file),
		as.character(missing_data_file),
		as.character(Q_file),
		as.character(F_file),
		as.integer(K),
		as.integer(ploidy)
	);
}
