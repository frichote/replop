
crossEntropy <- function(genotype_file, K, missing_data_file = NULL, Q_file = NULL, 
	F_file = NULL, ploidy = NULL) {

	# test arguments and init
    	if(missing(genotype_file)) 
		stop("'genotype_file' argument is missing.")
	else if (!is.character(genotype_file))
		stop("'genotype_file' argument has to be of type character.")

    	if(missing(K)) 
		stop("'K' argument is missing.")
	if (!missing(K) && !is.integer(K))
		stop("'K' argument has to be of type integer.")

	if (!missing(missing_data_file) && !is.character(missing_data_file))
		stop("'output_file' argument has to be of type character.")
	else if (missing(missing_data_file))
		output_file = gsub("(.*)\\.geno","\\1_I.geno",genotype_file,perl=TRUE);
		
	if (!missing(Q_file) && !is.character(Q_file))
		stop("'Q_file' argument has to be of type character.")
	else if (missing(Q_file))
		output_file = gsub("(.*)\\.geno","\\1_I.Q",genotype_file,perl=TRUE);

	if (!missing(F_file) && !is.character(F_file))
		stop("'F_file' argument has to be of type character.")
	else if (missing(F_file))
		output_file = gsub("(.*)\\.geno","\\1_I.F",genotype_file,perl=TRUE);

	if (!missing(ploidy) && !is.integer(ploidy))
		stop("'ploidy' argument has to be of type integer.")
	else if (missing(ploidy))
		ploidy = 2;	


	# run method
    	.C("R_crossEntropy", 
		as.character(genotype_file),
		as.character(missing_data_file),
		as.character(Q_file),
		as.character(F_file),
		as.integer(K),
		as.integer(ploidy),
	);
}
