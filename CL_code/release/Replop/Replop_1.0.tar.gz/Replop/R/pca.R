pca <- function(input_file, 
		K = NULL, 
		scaled = FALSE, 
		output_file.eigenvalues = NULL, load.eigenvalues = TRUE, 
		output_file.eigenvectors = NULL, load.eigenvectors = TRUE) 
{

        # test arguments and init
	# input file
        if(missing(input_file))
                stop("'input_file' argument is missing.")
        else if (!is.character(input_file))
                stop("'input_file' argument has to be of type character.")
	# K
        if (!missing(K) && (!is.integer(K) || K <= 0))
                stop("'K' argument has to be of type integer and positive.")
	# scaled
        if (!missing(scaled) && !is.logical(scaled)) {
                stop("'scaled' argument has to be of type logical.")
        } else if (missing(scaled)) {
                scaled_int = scaled;
        } else {
                scaled_int = 1;
        }
	# eigenvalues file 
        if (!missing(output_file.eigenvalues) && !is.character(output_file.eigenvalues))
                stop("'output_file.eigenvalues' argument has to be of type character.")
        else if (missing(output_file.eigenvalues)) {
                output_file.eigenvalues = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1.eigenvalues",input_file)
	}
	# eigenvectors file 
        if (!missing(output_file.eigenvectors) && !is.character(output_file.eigenvectors))
                stop("'output_file.eigenvectors' argument has to be of type character.")
        else if (missing(output_file.eigenvectors)) {
                output_file.eigenvectors = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1.eigenvectors",input_file)
	}

    	.C("R_pca", 
		as.character(input_file),
		as.character(output_file.eigenvalues),
		as.character(output_file.eigenvectors),
		as.integer(K),
		as.double(scaled_int)
	);

	if (load.eigenvalues && load.eigenvectors) {
		eigenvalues = as.matrix(read.table(output_file.eigenvalues));
		eigenvectors = as.matrix(read.table(output_file.eigenvectors));
		list(eigenvalues,eigenvectors);
	} else if (load.eigenvalues && !load.eigenvectors) {	
		eigenvalues = as.matrix(read.table(output_file.eigenvalues));
		list(eigenvalues,output_file.eigenvectors);
	} else if (!load.eigenvalues && load.eigenvectors) {
		eigenvectors = as.matrix(read.table(output_file.eigenvectors));
		list(output_file.eigenvalues,eigenvectors)
	} else {
		list(output_file.eigenvalues,output_file.eigenvectors)
	}
}
