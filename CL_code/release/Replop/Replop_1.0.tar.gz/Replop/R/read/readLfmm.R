read.lfmm <- function(input_file) {

        # test arguments
        if(missing(input_file))
                stop("'input_file' argument is missing.")
        else if (!is.character(input_file))
                stop("'input_file' argument has to be of type character.")

	R = as.matrix(read.table(input_file);

	if(count(which(R != 2 && R != 1 && R != 9 && R != -9)) != 0)
                warning("Input file is not in lfmm format.")

}
