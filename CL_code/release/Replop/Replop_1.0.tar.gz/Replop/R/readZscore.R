read.zscore <- function(input_file) {

	# test arguments
	test_character("input_file", input_file, NULL)

	R = as.matrix(read.table(input_file));

	return(list(zscore=R[,1],mlog10pvalue=R[,2],pvalue=R[,3],mlog10qvalue=R[,4],qvalue=R[,5]))
}
