reverse <- function(x) {
    .Call("print_licence_lfmm")
    print(x)
}
