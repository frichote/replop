snmf <- function(input_file, 
		K, 
		alpha = NULL, 
		tol = NULL, 
		iterations = NULL, 
		ploidy = NULL, 
		seed = NULL, 
		num_thrd = NULL, 
		output_file.Q = NULL, load.Q = TRUE, 
		output_file.F = NULL, load.F = FALSE) 
{

        # test arguments and init

        if(missing(input_file))
                stop("'input_file' argument is missing.")
        else if (!is.character(input_file))
                stop("'input_file' argument has to be of type character.")

        if(missing(K))
                stop("'K' argument is missing.")
        if (!missing(K) && !is.integer(K))
                stop("'K' argument has to be of type integer.")

        if (!missing(alpha) && !is.double(alpha))
                stop("'alpha' argument has to be of type double.")
        else if (missing(alpha))
                alpha = 100;

        if (!missing(tol) && !is.double(tol))
                stop("'tol' argument has to be of type double.")
        else if (missing(tol))
                tol = 0.0001;

        if (!missing(iterations) && !is.integer(iterations))
                stop("'iterations' argument has to be of type integer.")
        else if (missing(iterations))
                iterations = 2;

        if (!missing(seed) && !is.integer(seed))
                stop("'seed' argument has to be of type integer.")

        if (!missing(num_thrd) && !is.integer(num_thrd))
                stop("'num_thrd' argument has to be of type integer.")
        else if (missing(num_thrd))
                num_thrd = 1;

        if (!missing(output_file.Q) && !is.character(output_file.Q))
                stop("'output_file.Q' argument has to be of type character.")
        else if (missing(output_file.Q))
                output_file = gsub("(.*)\\.geno","\\1.Q",genotype_file,perl=TRUE);

        if (!missing(output_file.F) && !is.character(output_file.F))
                stop("'output_file.F' argument has to be of type character.")
        else if (missing(output_file.F))
                output_file = gsub("(.*)\\.geno","\\1.F",genotype_file,perl=TRUE);

        if (!missing(F_file) && !is.character(F_file))
                stop("'F_file' argument has to be of type character.")
        else if (missing(F_file))
                output_file = gsub("(.*)\\.geno","\\1_I.F",genotype_file,perl=TRUE);

        if (!missing(load.Q) && !is.logical(load.Q))
                stop("'load.Q' argument has to be of type logical.")
	
        if (!missing(load.F) && !is.logical(load.F))
                stop("'load.F' argument has to be of type logical.")


    	.C("R_sNMF", 
		as.character(input_file),
		as.integer(K),
		as.double(alpha),
		as.double(tol),
		as.integer(iteration),
		as.integer(ploidy),
		as.integer(seed),
		as.integer(num_thrd),
		as.character(output_file_Q),
		as.character(output_file_F)
	);

	if (load.Q && load.F) {
		Q = as.matrix(read.table(output_file_Q));
		F = as.matrix(read.table(output_file_F));
		list(Q,F);
	} else if (load.Q && !load.F) {	
		Q = as.matrix(read.table(output_file_Q));
		list(Q.output_file_F);
	} else if (!load.Q && load.F) {
		F = as.matrix(read.table(output_file_F));
		list(output_file_Q,F)
	} else {
		list(output_file_Q,output_file_F)
	}
}
