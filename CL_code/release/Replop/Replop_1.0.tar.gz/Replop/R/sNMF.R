sNMF <- function(input_file, 
		K, 
		alpha = 100, 
		tol = 0.0001, 
		percentage = NULL,
		iterations = 200, 
		ploidy = 2, 
		seed = -1, 
		num_CPU = 1, 
		output_file.Q = NULL, load.Q = TRUE, 
		output_file.F = NULL, load.F = FALSE) 
{

        # test _rguments and init
	# input file
        if(missing(input_file))
                stop("'input_file' argument is missing.")
        else if (!is.character(input_file))
                stop("'input_file' argument has to be of type character.")
	# K
        if(missing(K))
                stop("'K' argument is missing.")
        if (!missing(K) && ((!is.integer(K) && !is.double(K))|| K <= 0))
                stop("'K' argument has to be of type integer and positive.")
	# alpha
        if (!missing(alpha) && !is.double(alpha))
                stop("'alpha' argument has to be of type double.")
        else if (!missing(alpha) && alpha < 0)
		alpha = 0	
        else if (missing(alpha))
                alpha = 100
	# tolerance
        if (!missing(tol) && !is.double(tol))
                stop("'tol' argument has to be of type double.")
        else if (missing(tol) || (!missing(tol) && tol <= 0))
                tol = 0.0001;
	# percentage
        if (!missing(percentage) && !is.double(percentage))
                stop("'percentage' argument has to be of type double.")
        else if (!missing(percentage) && (percentage <= 0 || percentage >= 1))
                percentage = 0.05
        else if (missing(percentage))
                percentage = 0;
	# iterations
        if (!missing(iterations) && !is.integer(iterations))
                stop("'iterations' argument has to be of type integer.")
        else if (missing(iterations) || (!missing(iterations) && iterations <= 0))
                iterations = 200;
	# ploidy
        if (!missing(ploidy) && !is.integer(ploidy))
                stop("'ploidy' argument has to be of type integer.")
        else if (missing(ploidy) || (!missing(ploidy) && iterations <= 0))
                ploidy = 2;
	# seed
        if (!missing(seed) && !is.integer(seed))
                stop("'seed' argument has to be of type integer.")
	# CPU	
        if (!missing(num_CPU) && !is.integer(num_CPU))
                stop("'num_CPU' argument has to be of type integer.")
        else if (missing(num_CPU) || (!missing(num_CPU) && num_CPU <= 0))
                num_thrd = 1;
	# Q file 
        if (!missing(output_file.Q) && !is.character(output_file.Q))
                stop("'output_file.Q' argument has to be of type character.")
        else if (missing(output_file.Q)) {
                output_file.Q = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1.",input_file)
                output_file.Q = paste(output_file.Q, K, ".Q", sep="")
	}
	# F file
        if (!missing(output_file.F) && !is.character(output_file.F))
                stop("'output_file.F' argument has to be of type character.")
        else if (missing(output_file.F)) { 
                output_file.F = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1.",input_file)
                output_file.F = paste(output_file.F, K, ".F", sep="")
	}
	# load Q
        if (!missing(load.Q) && !is.logical(load.Q))
                stop("'load.Q' argument has to be of type logical.")
	# load F
        if (!missing(load.F) && !is.logical(load.F))
                stop("'load.F' argument has to be of type logical.")


    	.C("R_sNMF", 
		as.character(input_file),
		as.integer(K),
		as.double(alpha),
		as.double(tol),
		as.double(percentage),
		as.integer(iterations),
		as.integer(seed),
		as.integer(ploidy),
		as.integer(num_CPU),
		as.character(output_file.Q),
		as.character(output_file.F)
	);

	if (load.Q && load.F) {
		Q = as.matrix(read.table(output_file.Q));
		F = as.matrix(read.table(output_file.F));
		list(Q,F);
	} else if (load.Q && !load.F) {	
		Q = as.matrix(read.table(output_file.Q));
		list(Q,output_file.F);
	} else if (!load.Q && load.F) {
		F = as.matrix(read.table(output_file.F));
		list(output_file.Q,F)
	} else {
		list(output_file.Q,output_file.F)
	}
}
