sNMF <- function(input_file, K, 
		alpha = NULL, 
		tol = NULL, 
		iteration = NULL, 
		ploidy = NULL, 
		seed = NULL, 
		num_thrd = NULL, 
		output_file.Q = NULL, load.Q = TRUE, 
		output_file.F = NULL, load.F = FALSE) {

    if(missing(input_file)) stop("'target' is missing")

    .C("main_sNMF", 
	as.character(input_file),
	as.integer(K),
	as.double(alpha),
	as.double(tol),
	as.integer(iteration),
	as.integer(ploidy),
	as.integer(seed),
	as.integer(num_thrd),
	as.character(output_file)
	);

	# choose output_file
	output_file;
}
