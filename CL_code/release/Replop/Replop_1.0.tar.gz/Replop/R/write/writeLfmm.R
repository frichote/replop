write.lfmm <- function(data, ouput_file.lfmm) 
{

        if(missing(data))
                stop("'data' argument is missing.")
        else if (!(is.matrix(data) || is.data.frame(data) || is.vector(data))
                stop("'data' argument has to be of type matrix, data.frame or vector.")
	else if (is.vector(data))
		data = matrix(data,ncol=1,nrow=length(data))
	else if (is.data.frame(data))
		data = as.matrix(data)

        if(missing(output_file.lfmm))
                stop("'output_file.lfmm' argument is missing.")
        else if (!is.character(output_file.lfmm))
                stop("'output_file.lfmm' argument has to be of type character.")

	data[which(is.na(data))] = 9
	data[which(is.nan(data))] = 9

	write.table(data,output_file.lfmm,col.names=FALSE,row.names=FALSE,sep="");
	
	output_file.lfmm;
}
