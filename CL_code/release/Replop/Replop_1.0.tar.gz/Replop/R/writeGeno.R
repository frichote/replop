write.geno <- function(data, ouput_file) 
{

        if(missing(data))
                stop("'data' argument is missing.")
        else if (!(is.matrix(data) || is.data.frame(data) || is.vector(data)))
                stop("'data' argument has to be of type matrix, data.frame or vector.")
	else if (is.vector(data))
		data = matrix(data,ncol=1,nrow=length(data))
	else if (is.data.frame(data))
		data = as.matrix(data)

        if(missing(output_file))
                stop("'output_file.geno' argument is missing.")
        else if (!is.character(output_file))
                stop("'output_file.geno' argument has to be of type character.")

	data[which(is.na(data))] = 9
	data[which(is.nan(data))] = 9

	if(any(data != 2 & data != 1 & data != 0 & data != 9))
		stop("'data' matrix can only contains 0, 1, 2 or 9.") 

	write.table(t(data), output_file, col.names=FALSE,row.names=FALSE,sep="");
	
	print("A file with plop ndi QQQQQ")

	return(output_file)
}
