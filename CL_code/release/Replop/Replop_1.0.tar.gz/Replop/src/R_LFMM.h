/**
 * @file R_LFMM.h
 *
 * @brief C wrapper for LFMM command line program
 */

#ifndef R_LFMM_H
#define R_LFMM_H

int main_LFMM(int argc, char *argv[]);

#endif // R_LFMM_H
