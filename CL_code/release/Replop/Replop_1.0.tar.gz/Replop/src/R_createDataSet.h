/**
 * @file R_createDataSet.h
 *
 * @brief C wrapper for createDataSet command line program
 */

#ifndef R_createDataSet_H
#define R_createDataSet_H

int main_createDataSet(int argc, char *argv[]);

#endif // R_createDataSet_H
