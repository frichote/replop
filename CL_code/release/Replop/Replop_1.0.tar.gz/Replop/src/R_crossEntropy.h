/**
 * @file R_crossEntropy.h
 *
 * @brief C wrapper for crossEntropy command line program
 */

#ifndef R_crossEntropy_H
#define R_crossEntropy_H

int main_crossEntropy(int argc, char *argv[]);

#endif // R_crossEntropy_H
