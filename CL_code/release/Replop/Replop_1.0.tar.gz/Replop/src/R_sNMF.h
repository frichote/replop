/**
 * @file R_sNMF.h
 *
 * @brief C wrapper for sNMF command line program
 */

#ifndef R_sNMF_H
#define R_sNMF_H

int main_sNMF(int argc, char *argv[]);

#endif // R_sNMF_H
