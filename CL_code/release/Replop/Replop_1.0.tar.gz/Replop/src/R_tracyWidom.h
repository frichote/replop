/**
 * @file R_tracyWidom.h
 *
 * @brief C wrapper for tracyWidom command line program
 */

#ifndef R_TRACYWIDOM_H
#define R_TRACYWIDOM_H

void R_tracyWidom (char** R_input_file, char **R_output_file);

#endif // R_TRACYWIDOM_H
