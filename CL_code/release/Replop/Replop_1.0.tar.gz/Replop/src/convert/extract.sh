#!/bin/sh

h_file=$1

# remove comments

# look for function definitions

# extract function name 

 
