/*
    NMF, file: main.c
    Copyright (C) 2013 François Mathieu, Eric Frichot

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include <R.h>


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "als.h"
#include "als_k1.h"
#include "criteria.h"
#include "print_snmf.h"
#include "register_snmf.h"
#include "../matrix/matrix.h"
#include "../matrix/rand.h"
#include "../io/io_data_double.h"
#include "../io/io_tools.h"
#include "../bituint/io_geno_bituint.h"
#include "../bituint/bituint.h"
#include "../createDataSet/createDataSet.h"
#include "../crossEntropy/crossEntropy.h"

void sNMF(char* input_file, int K, double alpha, double tol, double e, int maxiter, 
	long long seed, int m, int num_thrd, char* output_file_Q, char* output_file_F) {
	
	//parameters initialization

	int N = 0;			// number of individuals
	int M = 0;			// number of SNPs
	double *Q_res;			// matrix for ancestral admixture coefficients (of size NxK)
	double *F_res;			// matrix for ancestral allele frequencies (of size M x nc xK)
	int Mc;				// size of memory allocation for one individual
	bituint* X;			// data matrix
	int Mp;				// ???
	int nc = 3;			// ploidy, 3 if 0,1,2 , 2 if 0,1 (number of factors)
	double like = 0.0;
	char *tmp_file; 
	char data_file[512];
	double all_ce, missing_ce;

	//  random init
	init_random(&seed);

	// fix the number of possible factors 
	if (m)
		nc = m + 1;
	else 
		m = 2;

	// count the number of lines and columns
	N = nb_cols_geno(input_file);
	M = nb_lines(input_file, N);

	// write command line summary
        print_summary_snmf(N, M, m, seed, K, alpha, tol, maxiter, 
		input_file, num_thrd, e, output_file_Q, output_file_F);

        // write input file name
	if (e) {
	        tmp_file = remove_ext(input_file,'.','/');
                strcpy(data_file, tmp_file);
	        strcat(data_file, "_I.geno");
	        Free(tmp_file);
		// create file with masked genotypes
		Rprintf("\n <<<<<< createDataSet program\n\n");
		createDataSet(input_file, m, -1, e, data_file);
		Rprintf("\n >>>>>>\n\n");
	} else 
                strcpy(data_file,input_file);
	
	// memory allocation
	Mc = nc*M;
	init_mat_bituint(&X,N,Mc,&Mp);
        Q_res = (double *) Calloc(N*K * sizeof(double), double);      // of size NxK
        F_res = (double *) Calloc(K*Mc * sizeof(double), double);     // of size McxK

	// read of genotypic data
	read_geno_bituint(data_file, N, M, Mp, nc, X);
        Rprintf("Read genotype file %s:\t\tOK.\n\n",input_file);

	// parameter estimation
	if (K == 1) 
		ALS_k1(X, Q_res, F_res, N, M, nc, Mp);
	else
		ALS(X, Q_res, F_res, N, M, nc, Mp, K, maxiter, tol, num_thrd, alpha);

	// least square estimates
	like = least_square(X, Q_res, F_res, N, M, nc, Mp, K, alpha); 
	Rprintf("\n\nLeast-square error: %f\n\n", like);

	write_data_double(output_file_Q, N, K, Q_res);
       	Rprintf("Write individual ancestry coefficient file %s:"
		"\t\tOK.\n\n",output_file_Q);

	write_data_double(output_file_F, Mc, K ,F_res);
        Rprintf("Write ancestral allele frequency coefficient file %s:"
		"\tOK.\n\n",output_file_F);

	if (e) {
		Rprintf("\n <<<<<< crossEntropy program\n\n");
		crossEntropy(input_file, data_file, output_file_Q, 
			output_file_F, K, m, &all_ce, &missing_ce);	
		Rprintf("\n >>>>>>\n\n");
	}

	//free memory
	Free(X);
	Free(Q_res);
	Free(F_res);
}
