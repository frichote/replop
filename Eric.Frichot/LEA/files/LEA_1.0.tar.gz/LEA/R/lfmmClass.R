# create cl lfmm
setClass("lfmmClass",
	slots = c(directory="character", 
		lfmmClass_file ="character",
		input_file ="character",
		variable_file ="character",
		n="integer", L="integer", K="integer", D="integer", 
		d = "integer", Niter = "integer", burn = "integer",
		CPU = "integer", seed="integer", lambda = "numeric", 
		missing_data = "logical", all="logical", 
		epsilon_noise = "numeric", epsilon_b = "numeric",
		random_init = "logical",
		zscore_file="character", dic_file="character",
		deviance="numeric", DIC="numeric"
	)
)

# listMethods

listMethods_LFMM <- function()
{
c(	"zscores",
	"pvalues",
	"mlog10pvalues"
);
}

# listSlots

listSlots_LFMM <- function()
{
c(	"directory", "n", "L", "K", "D", "Niter", 
	"burn", "CPU", "seed", "all", "missing_data",
	"d", "lfmmClass_file", "input_file", "variable_file",
	"noise_epsilon", "b_epsilon", "lambda",
	"zscore_file", "dic_file", "epsilon_noise", "epsilon_b", 
	"random_init", "deviance", "DIC")
}

.DollarNames.lfmmClass <- function(x, pattern) c(listSlots_LFMM(),listMethods_LFMM())

# $ 

setMethod("$", "lfmmClass",
           function(x, name) {
             if (!(name %in% listMethods_LFMM() || name %in% listSlots_LFMM())) {
               stop("no $ method for object without attributes")
	     } else if (name %in% listMethods_LFMM()) {
		do.call(name, list(x));
	     } else {
		slot(x, name)
	     }
           }
)

# pvalues

setGeneric("pvalues", function(object) matrix);
setMethod("pvalues", "lfmmClass",
	function(object) {
		R = read.zscore(paste(object@directory,
			object@zscore_file,sep="/"));	
		res = R$pvalues;
	}
)

# mlog10pvalues

setGeneric("mlog10pvalues", function(object) matrix);
setMethod("mlog10pvalues", "lfmmClass",
	function(object) {
		R = read.zscore(paste(object@directory,
			object@zscore_file,sep="/"));	
		res = R$mlog10pvalues;
	}
)

# zscores

setGeneric("zscores", function(object) matrix);
setMethod("zscores", "lfmmClass",
	function(object) {
		R = read.zscore(paste(object@directory,
			object@zscore_file,sep="/"));	
		res = R$zscores;
	}
)

# ecdf

setGeneric("ecdf",  function(object) NULL)
setMethod("ecdf", "lfmmClass", 
        function(object){
		main="Empirical Cumulative Distribution Function"
		plot.ecdf(pvalues(object), main=main)
	}
)

# plot

setMethod("plot", "lfmmClass",
          function(x, y, ...){
            plot(mlog10pvalues(x), main="Manhattan plot", ...)
          }
)

# lambda

setGeneric("getLambda", function(object) numeric)
setMethod("getLambda", "lfmmClass",
	function (object) {
		pp =  seq(.5,.9, by=0.01)
		zs.0 = zscores(object)
		p.0 = 1 - pchisq( zs.0^2  , df = 1)

		lambda = median(quantile(zs.0^2, prob = pp)/qchisq(pp, df = 1))
	}
)

# cFR
setGeneric("cFDR.lfmmClass",function(object, percentage) vector)
setMethod("cFDR.lfmmClass", signature=signature(object="lfmmClass", percentage="numeric"),
	function(object, percentage) {
		zs.0 = zscores(object)
		lambda = object@lambda
		p = 1 - pchisq( zs.0^2/lambda , df = 1)
		k = sum(sort(p) < percentage * (1:length(p)) / length(p))
		res = which(p <  percentage * k / length(p))
	} 
)

# show

setMethod("show", "lfmmClass",
	function(object) {
		cat("* lfmm class *\n\n")
		cat("file directory:                 ", object@directory, "\n")
		cat("lfmmClass file:                 ", object@lfmmClass_file, "\n")
		cat("input file:                     ", object@input_file, "\n")
		cat("variable file:                  ", object@variable_file, "\n")
		cat("number of individuals:          ", object@n, "\n")
		cat("number of loci:                 ", object@L, "\n")
		cat("number of latent factors:       ", object@K, "\n")
		cat("number of variables:            ", object@D, "\n")
		cat("number of total iterations:     ", object@Niter, "\n")
		cat("number of burnin iterations:    ", object@burn, "\n")
		cat("number of CPUs:                 ", object@CPU, "\n")
		cat("seed:                           ", object@seed, "\n")
		cat("missing data:                   ", object@missing_data, "\n")
		cat("noise epsilon:                  ", object@epsilon_noise, "\n")
		cat("correlation epsilon:            ", object@epsilon_b, "\n")
		cat("random init:                    ", object@random_init, "\n")
		cat("all variables at the same time: ", object@all, "\n")
		if (object@d) 
			cat("Run for variable:               ", object@d, "\n")
		cat("zscore file:                    ", object@zscore_file, "\n")
		cat("DIC file:                       ", object@dic_file, "\n")

	}
)

# summary

setGeneric("summary", function(object) NULL)
setMethod("summary", "lfmmClass",
	function(object) {
		percentage = c(.9,.8,.7,.6,.5,.4,.3,.2,.1,.05,.02,.01)
		colnames = paste(percentage *100, "%")	
		rownames = "proportion of correlations"
		res = matrix(NA,ncol=length(percentage), nrow=1, dimnames= list(rownames, colnames)) 
		for (p in 1:length(percentage))
			res[p] = length(cFDR.lfmmClass(object, percentage[p]))/object@L
		return(list(cFDR=res));
	}
)

# read

setGeneric("read.lfmmClass", function(file="character") attributes("lfmmClass"))
setMethod("read.lfmmClass", "character",
	function(file) {
		return(dget(file));
	}
)

# write
setGeneric("write.lfmmClass", function(x="lfmmClass", file="character") NULL)
setMethod("write.lfmmClass", signature(x="lfmmClass", file="character"),
	function(x, file) {
		dput(x, file) 
	}
)
