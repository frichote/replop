
# create cl PCA
setClass("pcaClass",
	slots = c(directory="character", 
		n="integer", L="integer", K="integer", 
		center="logical", scale="logical", 
		pcaClass_file ="character",
		input_file ="character",
		eigenvalue_file="character",
		eigenvector_file="character",
		sdev_file="character",
		projection_file="character")
)

# listMethods

listMethods_pcaClass <- function()
{
c(	"eigenvalues",
	"eigenvectors",
	"sdev",
	"projections"
);
}

# listSlots

listSlots_pcaClass <- function()
{
c(	"directory", "n", "L", "K", "center",
	"scale", "pcaClass_file", "input_file",
	"eigenvalue_file", "eigenvector_file",
	"sdev_file", "projection_file")
}

.DollarNames.pcaClass <- function(x, pattern) c(listSlots_pcaClass(),listMethods_pcaClass())

# [
#setMethod("[", signature(x = "testClass", i = "ANY", j="ANY"),
#         function (x, i, j, ..., drop){
#             print("void function")
#         }
#)

# $

setMethod("$", "pcaClass",
           function(x, name) {
             if (!(name %in% listMethods_pcaClass() || name %in% listSlots_pcaClass())) {
               stop("no $ method for object without attributes")
	     } else if (name %in% listMethods_pcaClass()) {
		do.call(name, list(x));
	     } else {
		slot(x, name)
	     }
           }
)

# eigenvalues

setGeneric("eigenvalues", function(object) matrix);
setMethod("eigenvalues", "pcaClass",
	function (object) {
		as.matrix(read.table(paste(object@directory,
				object@eigenvalue_file,sep="/")));
	}
)

# eigenvectors

setGeneric("eigenvectors", function(object) matrix);
setMethod("eigenvectors", "pcaClass",
	function (object) {
		as.matrix(read.table(paste(object@directory,
				object@eigenvector_file,sep="/")));
	}
)

# sdev

setGeneric("sdev", function(object) matrix);
setMethod("sdev", "pcaClass",
	function (object) {
		as.matrix(read.table(paste(object@directory,
				object@sdev_file,sep="/")));
	}
)

# projections

setGeneric("projections", function(object) matrix);
setMethod("projections", "pcaClass",
	function (object) {
		as.matrix(read.table(paste(object@directory,
				object@projection_file,sep="/")));
	}
)

# plot

setMethod("plot", "pcaClass",
          function(x, y, ...){
            plot(eigenvalues(x), ...)
          })

# show

setMethod("show", "pcaClass",
	function(object) {
		cat("* pca class *\n\n")
		cat("file directory:                 ", object@directory, "\n")
		cat("pcaClass file:                  ", object@pcaClass_file, "\n")
		cat("number of individuals:          ", object@n, "\n")
		cat("number of loci:                 ", object@L, "\n")
		cat("number of principal components: ", object@K, "\n")
		cat("input file:                     ", object@input_file, "\n")
		cat("eigenvalue file:                ", object@eigenvalue_file, "\n")
		cat("eigenvector file:               ", object@eigenvector_file, "\n")
		cat("standard deviation file:        ", object@sdev_file, "\n")
		cat("projection file:                ", object@projection_file, "\n")
		cat("centered:                       ", object@center, "\n")
		cat("scaled:                         ", object@scale, "\n")
	}
)

# summary

setGeneric("summary", function(object) NULL)
setMethod("summary", "pcaClass",
	function(object) {
               	cat("Importance of components:\n");
                rownames = c("Standard deviation", "Proportion of Variance", "Cumulative Proportion");
                colnames = paste("PC", 1:object@n, sep="");
                R = matrix(NA, ncol=object@K, nrow=3, dimnames= list(rownames, colnames));
                R[1,] = sdev(object);
                e = eigenvalues(object);
                R[2,] = e/sum(e);
                R[3,] = cumsum(R[2,]);

                R
	}
)

# read

setGeneric("read.pcaClass", function(file="character") attributes("pcaClass"))
setMethod("read.pcaClass", "pcaClass",
	function(file) {
		return(dget(file));
	}
)

# write

setGeneric("write.pcaClass", function(x="pcaClass", file="character") NULL)
setMethod("write.pcaClass", signature(x="pcaClass", file="character"),
	function(x, file) {
		dput(x, file) 
	}
)
