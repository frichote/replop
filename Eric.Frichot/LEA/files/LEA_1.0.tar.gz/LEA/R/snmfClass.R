# create cl sNMF
setClass("snmfClass",
	slots = c(directory="character", 
		snmfClass_file ="character",
		input_file ="character",
		n="integer", L="integer", K="integer", 
		CPU = "integer", seed="integer", alpha = "numeric",
		percentage = "numeric", 
		I = "integer", iterations = "integer",  
		entropy = "logical", tolerance = "numeric",
		crossEntropy = "numeric", ploidy = "integer",
		Q_input_file="character", Q_output_file = "character",
		G_output_file="character")
)

# listMethods

listMethods_snmfClass <- function()
{
c(	"Qvalues",
	"Gvalues"
);
}

# listSlots

listSlots_snmfClass <- function()
{
c(	"directory", "n", "L", "K", "CPU", "seed", "alpha", "missing_data",
	"snmfClass_file", "percentage ", "input_file", "I", "iterations", 
	"entropy", "error", "crossEntropy", "ploidy", "Q_input_file", "Q_output_file", 
	"G_output_file")
}

.DollarNames.snmfClass <- function(x, pattern) c(listSlots_snmfClass(),listMethods_snmfClass())

# $

setMethod("$", "snmfClass",
           function(x, name) {
             if (!(name %in% listMethods_snmfClass() || name %in% listSlots_snmfClass())) {
               stop("no $ method for object without attributes")
	     } else if (name %in% listMethods_snmfClass()) {
		do.call(name, list(x));
	     } else {
		slot(x, name)
	     }
           }
)

# Qvalues

setGeneric("Qvalues", function(object) matrix);
setMethod("Qvalues", "snmfClass",
	function(object) {
               R = as.matrix(read.table(paste(object@directory,
                                object@Q_output_file,sep="/")));
	}
)

# Gvalues

setGeneric("Gvalues", function(object) matrix);
setMethod("Gvalues", "snmfClass",
	function(object) {
               R = as.matrix(read.table(paste(object@directory,
                                object@G_output_file,sep="/")));
	}
)

setGeneric("getCrossEntropy", function(object="snmfClass") vector);
setMethod("getCrossEntropy", "snmfClass",
	function(object) {
		if (object@entropy)
			object@crossEntropy
		else 
			NULL
	}
)
# plot

# display lambda for a value of d, and a Manhattan plot for a value of K. 
setMethod("plot", "snmfClass",
          function(x, y, ...){
		# todo colors
	    barplot(t(x$Qvalues), main="Admixture coefficient plot", ...)
          }
)

# show

setMethod("show", "snmfClass",
	function(object) {
		cat("snmf class\n\n")
		cat("file directory:                  ", object@directory, "\n")
		cat("snmfClass file:                  ", object@snmfClass_file, "\n")
		cat("input file:                      ", object@input_file, "\n")
		cat("number of individuals:           ", object@n, "\n")
		cat("number of loci:                  ", object@L, "\n")
		cat("number of ancestral populations: ", object@K, "\n")
		cat("regularization parameter:        ", object@alpha, "\n")
		cat("number of CPUs:                  ", object@CPU, "\n")
		cat("seed:                            ", object@seed, "\n")
		cat("maximal number of iterations:    ", object@iterations, "\n")
		cat("tolerance error:                 ", object@tolerance, "\n")
		cat("Q input file:                    ", object@Q_input_file, "\n")
		cat("Q output file:                   ", object@Q_output_file, "\n")
		cat("G output file:                   ", object@G_output_file, "\n")
		if (object@entropy)
			cat("cross-Entropy:                   ", object@crossEntropy,"\n")
		else
			cat("cross-Entropy:                   ", object@entropy,"\n")
	}
)

# summary

setGeneric("summary", function(object) NULL)
setMethod("summary", "snmfClass",
	function(object) {
		show(object)
	}
)

# read

setGeneric("read.snmfClass", function(file="character") attributes("snmfClass"))
setMethod("read.snmfClass", "character",
	function(file) {
		return(dget(file));
	}
)

# write
setGeneric("write.snmfClass", function(x="snmfClass", file="character")NULL)
setMethod("write.snmfClass", signature(x="snmfClass", file="character"),
	function(x, file) {
		dput(x, file) 
	}
)
