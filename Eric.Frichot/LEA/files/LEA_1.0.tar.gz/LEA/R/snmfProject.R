# create Class sNMF Project
setClass("snmfProject",
	slots = c(snmfProject_file = "character", directory = "character", 
		input_file = "character", runs = "list", K="integer",
		snmfClass_files = "vector")
)

# addRun

setGeneric("addRun.snmfProject", function(project="snmfProject", run="snmfClass") attributes("snmfProject"));
setMethod("addRun.snmfProject", signature(project="snmfProject", run="snmfClass"),
	function(project, run) {
		project@runs[[length(project@runs) + 1]] = run
		project@K = c(project@K, run@K)
		project@snmfClass_files = c(project@snmfClass_files, run@snmfClass_file)
		return(project)
	}
)


# listMethods

listMethods_snmfProject <- function()
{
}

# listSlots

listSlots_snmfProject <- function()
{
c(	"snmfProject_file", "input_file", "runs", "K", "directory", "snmfClass_files")
}

.DollarNames.snmfProject <- function(x, pattern) c(listSlots_snmfProject(),
	listMethods_snmfProject())

# $
#setMethod("$<-", "snmfProject",
#           function(x, name, value) {
#             if (!(name %in% listSlots_snmfProject())) {
#               stop("no $ method for object without attributes")
#	     } else {
#		slot(x, name, check = TRUE) <- value
#	     }
#           }
#)

setMethod("$", "snmfProject",
           function(x, name) {
             if (!(name %in% listMethods_snmfProject() || name %in% listSlots_snmfProject())) {
               stop("no $ method for object without attributes")
	     } else if (name %in% listMethods_snmfProject()) {
		do.call(name, list(x));
	     } else {
		slot(x, name)
	     }
           }
)

# getRuns

setGeneric("getRuns.snmfProject", function(object, ...) standardGeneric("getRuns.snmfProject"));
setMethod("getRuns.snmfProject", "snmfProject",
	function(object, k) {
		# check of k
		if (missing(k)) {
			k = object@K;
		} else if (!(all(k %in% object@K))) {
			stop("Unknown k!")
		} 
		k = unique(k)
		res = list()
		# check of the run number
		for (ku in k) {
			for (rep in which(object@K == ku))
				res[[length(res) + 1]] = object@runs[[rep]]
		}
		res
	}
)

# plot

# display lambda for a value of d, and a Manhattan plot for a value of K. 
setMethod("plot", "snmfProject",
          function(x, ...){
	    s = summary(x);
	    axe = NULL
	    K = sort(unique(x@K))
	    
            for (k in 1:length(K)) {
			tK = FALSE
                        for (w in which(x@K == K[k])) {
                                if (x@runs[[w]]$entropy)
				tK = TRUE;
                        }
			if (tK)
				axe = c(axe, K[k])		
                }

            plot(s$crossEntropy[1,], ylab="Minimal Cross-Entropy", xlab="Number of ancestral populations", ...)
          }
)

# crossEntropy

setGeneric("getCrossEntropy", function(object, K) vector)
setMethod("getCrossEntropy", "snmfProject",
	function(object, K) {
		res = NULL
		for (i in which(object@K == K)) {
			if (object@runs[[i]]$entropy) 
				res = c(res, object@runs[[i]]$crossEntropy)
		}
		if (length(res) == 0) {
			return(NULL);
		} else {
			return(res);
		}
	}
) 

# show

setMethod("show", "snmfProject",
	function(object) {
		cat("snmf Project\n\n")
		cat("snmfProject file:                ", object@snmfProject_file, "\n")
		cat("directory:                       ", object@directory, "\n")
		cat("input file:                      ", object@input_file, "\n")
		cat("number of ancestral populations: ", object@K, "\n")
		if (length(object@runs)) {
		for (i in 1:length(object@runs)) {
			cat("\n")
			cat("*** run", i," ***\n");
			show(object@runs[[i]])
		}
		}
	}
)

# summary

setGeneric("summary", function(object) NULL)
setMethod("summary", "snmfProject",
	function(object) {
		K = sort(unique(object@K))
		rownames=c("with cross-entropy", "without cross-entropy", "total")
		colnames=paste("K =", K)
		rep = matrix(NA, ncol=length(K), nrow=3, dimnames= list(rownames, colnames))
		for (k in 1:length(K)) {
			rep[3,k] = length(which(object@K == K[k]))
			rep[1,k] = 0;
			for (w in which(object@K == K[k])) {
				if (object@runs[[w]]$entropy)
					rep[1,k] = rep[1,k] + 1
			}
			rep[2,k] = rep[3,k] - rep[1,k]
		}
		
      		rownames = c("min", "mean", "max");
		ce = matrix(NA, ncol=length(K), nrow=3, dimnames= list(rownames, colnames)); 
		for (k in 1:length(K)) {
			ceK = getCrossEntropy(object, K[k])
			if (!is.null(ceK)) { 
				ce[1,k] = min(ceK);
				ce[2,k] = mean(ceK);
				ce[3,k] = max(ceK);
			} else {
				ce[1,k] = NA
				ce[1,k] = NA
				ce[1,k] = NA
			}
		}
	list(repetitions=rep, crossEntropy=ce)
	}
)

# read

setGeneric("read.snmfProject", function(file="character") attributes("snmfProject"))
setMethod("read.snmfProject", "character",
	function(file) {
		res = dget(file);
		for (r in 1:length(res@snmfClass_files)) {
			res@runs[[r]] = read.snmfClass(res@snmfClass_files[r])
		}
		return(res);
	}
)

# write

setGeneric("write.snmfProject", function(x="snmfProject", file="character") NULL)
setMethod("write.snmfProject", signature(x="snmfProject", file="character"),
	function(x, file) {
		for (r in 1:length(x@runs)) {
			write.snmfClass(x@runs[[r]], x@snmfClass_files[r])
		}
		x@runs = list()
		dput(x, file) 
	}
)
