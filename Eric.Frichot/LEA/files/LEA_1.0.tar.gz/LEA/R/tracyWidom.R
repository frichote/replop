tracyWidom <- function(eigenvalue_input_file, 
		tracywidom_output_file)
{

        # test arguments and init
	# input file
	eigenvalue_input_file = test_character("input_file", eigenvalue_input_file, NULL)
	# K
	# output file 
        tmp = gsub("([^.]+)\\.[[:alnum:]]+$", "\\1.tracywidom",eigenvalue_input_file)
	tracywidom_output_file = test_character("output_file.tracywidom", tracywidom_output_file, tmp)

    	.C("R_tracyWidom", 
		as.character(eigenvalue_input_file),
		as.character(tracywidom_output_file)
	);

	read.table(tracywidom_output_file, header = TRUE)
}
