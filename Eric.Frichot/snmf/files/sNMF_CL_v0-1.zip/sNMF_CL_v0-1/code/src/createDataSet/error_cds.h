/**
 * @file error_nmf.h
 *
 * @brief function to manage error types
 */


#ifndef ERROR_CDS_H
#define ERROR_CDS_H

#include "../matrix/error.h"

/**
 * print a specific lfmm error message
 *
 * @param msg   the string to recognize the error type
 * @param file  the name of a file (depends on the error)
 */
void print_error_cds(char* msg, char* file);

#endif // ERROR_NMF_H
