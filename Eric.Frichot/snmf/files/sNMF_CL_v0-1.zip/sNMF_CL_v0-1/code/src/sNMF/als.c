/*
   NMF, file: als.c
   Copyright (C) 2013 François Mathieu, Eric Frichot

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "als.h"
#include "../matrix/matrix.h"
#include "../matrix/rand.h"
#include "../matrix/inverse.h"
#include "../matrix/normalize.h"
#include "../in_out/print_tools.h"
#include "mult.h"
#include "data_nmf.h"
#include "thread_F.h"
#include "thread_Q.h"
#include "thread.h"
#include "../bituint/bituint.h"

// ALS

void ALS(bituint *X, double *Q, double *F, int N, int M, int nc, int Mp, int K,
		int maxiter, double tol, int num_thrd, double alpha) 
{
	double prec2, sum2;
	int k, i, j, l, c;
	Memory mem;

	//Initialisation of Q, prec and bar
	rand_matrix_double(Q, N, K);
	normalize_lines(Q, N, K);
	init_bar(&i,&j);

	mem = allocate_memory(M*nc, K);

	for (k = 0; k < maxiter; k++) {
		print_bar(&i,&j,maxiter);

		// update F
		update_F(F, Q, X, N, M, nc, Mp, K, num_thrd, mem);
		normalize_F(F,M,nc, K);

		if (isnan(F[0])) {
			printf("ALS: Internal Error, F is NaN.\n");
			exit(1);
		}

		// update Q
		sum2 = update_nnlsm_Q(Q, F, X, N, M, nc, Mp, K, alpha,
				mem, num_thrd);
		normalize_Q(Q,N,K);

		if (isnan(Q[0])) {
			printf("ALS: Internal Error, Q is NaN.\n");
			exit(1);
		}

		// stopping criteria
		if (k > 15 	&& sum2 <= prec2 && fabs(prec2-sum2)/fabs(prec2) < tol) { 
			break;
		}
		prec2 = sum2;
	}
	printf("\n\nNumber of iterations: %d",k);
	normalize_F(F,M,nc, K);

	// to avoid numerical issues
	for(l = 0; l < N*K; l++) {
		if (fabs(Q[l]) < 0.0001)
			Q[l] = 0.0001;
		if (fabs(1-Q[l]) < 0.0001)
			Q[l] = 1-0.0001;
	}

	for(j = 0; j < M; j++) {
		for (c = 0; c < nc; c++) {
			for(k = 0; k < K; k++) {
				if (fabs(F[(nc*j+c)*K+k]) < 0.0001)
					F[(nc*j+c)*K+k] = 0.0001;
				if (fabs(1-F[(nc*j+c)*K+k]) < 0.0001)
					F[(nc*j+c)*K+k] = 1-0.0001;
			}
		}
	}

	free_memory(mem);
	free(mem);
}

void update_F(double *F, double *Q, bituint *X, int N, int M, int nc, int Mp, int K, 
		int num_thrd, Memory mem) 
{
	int i, j, k1, k2;
	double *temp1 = mem->temp1;
	double *temp2 = mem->tempQ;
	double *temp3 = mem->temp3;

	int Mc = nc*M;
	int Md = Mc / SIZEUINT; 
	int Mm = Mc % SIZEUINT;
	int jm;
	bituint value;

	// bullshit
	k1 = num_thrd;

	//computation of transpose(Q)*Q					(N K2)
	zeros(temp1,K*K);
	for (i = 0; i < N; i++) {
		for (k1 = 0; k1 < K; k1++) {
			for (k2 = 0; k2 < K; k2++) {
				temp1[k1*K+k2] += Q[i*K+k1] * Q[i*K+k2];
			}
		}
	}

	//computation of inverse(transpose(Q)*Q)			()
	fast_inverse(temp1, K, temp2);

	//computation of inverse(transpose(Q)*Q)*transpose(Q) FAUX	(N K2)
	for (k1 = 0; k1 < K; k1++) {
		for (i = 0; i < N; i++) {
			temp3[k1*N+i] = 0;
			for (k2 = 0; k2 < K; k2++) {
				temp3[k1*N+i] += temp2[k1*K+k2] * Q[i*K+k2];
			}
		}
	}

	// F = temp3*X							(M N K)
	zeros(F,K*Mc);

	thread_fct(X, temp3, NULL, F, nc, K, M, Mp, N, num_thrd, slice_temp3_X);

	/*
	   for (jd = 0; jd<Md; jd++) {
	   for (i = 0; i < N; i++) {
	   value = X[i*Mp+jd];
	   for (jm = 0; jm<SIZEUINT; jm++) {
	   if (value % 2) {
	   for (k1 = 0; k1 < K; k1++) 
	   F[(jd*SIZEUINT+jm)*K+k1] += temp3[k1*N+i];
	   }
	   value >>= 1;
	   }
	   }
	   }*/
	for (i = 0; i < N; i++) {
		value = X[i*Mp+Md];
		for (jm = 0; jm<Mm; jm++) {
			if (value % 2) {
				for (k1 = 0; k1 < K; k1++) 
					F[(Md*SIZEUINT+jm)*K+k1] += temp3[k1*N+i];
			}
			value >>= 1;
		}
	}

	for (j = 0; j<K*Mc; j++)
		F[j] = fmax(F[j],0);
}

// update_nnlsm_F (not used)

double update_nnlsm_F(double *F, double *Q, bituint *X, int N, int M, int nc, 
		int Mp, int K, int num_thrd, Memory mem) 
{
	int i,j,k1,k2;
	double res;

	int Mc = nc*M;
	int Md = Mc / SIZEUINT;
	int Mm = Mc % SIZEUINT;
	int jd, jm;
	bituint value;
	double* temp1 = mem->temp1;
	double* temp3 = mem->temp3;
	double* Y = mem->Y;

	// bullshit
	k1 = num_thrd;

	// t(Q)*Q
	zeros(temp1,K*K);
	for (i = 0; i < N; i++) {
		for (k1 = 0; k1 < K; k1++) {
			for (k2 = 0; k2 < K; k2++) {
				temp1[k1*K+k2] += Q[i*K+k1] * Q[i*K+k2];
			}
		}
	}
	// t(Q)*X
	zeros(temp3,K*Mc);
	for (i = 0; i < N; i++) {
		for (jd = 0; jd<Md; jd++) {
			value = X[i*Mp+jd];
			for (jm = 0; jm<SIZEUINT; jm++) {
				if (value & mask[jm]) {
					for (k1 = 0; k1 < K; k1++) 
						temp3[k1*Mc+jd*SIZEUINT+jm] += Q[i*K+k1];
				}
			}
		}
		value = X[i*Mp+Md];
		for (jm = 0; jm<Mm; jm++) {
			if (value & mask[jm]) {
				for (k1 = 0; k1 < K; k1++) 
					temp3[k1*Mc+Md*SIZEUINT+jm] += Q[i*K+k1];
			}
		}
	}
	// solve F
	nnlsm_blockpivot(temp1,temp3,Mc,K,F,Y,mem);
	// update criteria
	res = 0.0;
	for (j = 0; j < Mc*K; j++) {
		res += fabs(Y[j]);
	}

	return res;
}

// udpate_Q (not used)

void update_Q(double *Q, double *F, bituint *X, int N, int M, int nc, int Mp, 
		int K, 	double alpha, Memory mem) {

	int i, j, k1, k2;
	double *temp1 = mem->temp1;
	double *temp2 = mem->tempQ;
	double *temp3 = mem->temp3;

	int Mc = nc*M;
	int Md = Mc / SIZEUINT;
	int Mm = Mc % SIZEUINT;
	int jd, jm;

	//computation of F*t(F)
	for (k1 = 0; k1 < K; k1++) {
		for (k2 = 0; k2 < K; k2++) {
			for (j = 0; j < Mc; j++) 
				temp1[k1*K+k2] += F[k1*Mc+j] * F[k2*Mc+j];
			temp1[k1*K+k2] += alpha;
		}
	}
	//inverse of F*t(F)
	fast_inverse(temp1, K, temp2);
	// F*t(X)
	for (i = 0; i < N; i++) {
		for (jd = 0; jd<Md; jd++) {
			for (jm = 0; jm<SIZEUINT; jm++) {
				if (X[i*Mp+jd] & mask[jm]) {
					for (k1 = 0; k1 < K; k1++) 
						temp3[k1*N+i] += F[k1*Mc+jd*SIZEUINT+jm];
				}
			}
		}
		for (jm = 0; jm<Mm; jm++) {
			if (X[i*Mp+Md] & mask[jm]) {
				for (k1 = 0; k1 < K; k1++) 
					temp3[k1*N+i] += F[k1*Mc+Md*SIZEUINT+jm];
			}
		}
	}
	// temp2 * temp3
	zeros(Q,K*N);
	for(k1 = 0; k1 < K; k1++) {
		for(k2 = 0; k2 < K; k2++) {
			for(i = 0; i < N; i++) {
				Q[i*K+k2] += temp2[k2*K+k1] * temp3[k1*N+i];
			}
		}
	}
	// Q[Q < 0] = 0.0;
	for(j = 0; j < N; j++) 
		for(i = 0; i < K; i++) 
			Q[j*K+i] = fmax(Q[j*K+i],0);
}

// update_nnlsm_Q

double update_nnlsm_Q(double *Q, double *F, bituint *X, int N, int M, int nc, 
		int Mp, int K, double alpha, Memory mem, int num_thrd) {

	int i, j, k1, k2, k;

	double* temp1 = mem->temp1;
	double* tempQ = mem->tempQ;
	double* temp3 = mem->temp3;
	double* Y = mem->Y;
	double res;
	int Mc = nc*M;
	int Md = Mc / SIZEUINT;
	int Mm = Mc % SIZEUINT;
	int jd, jm;
	bituint value;


	// F*t(F)							(M K2)
	zeros(temp1,K*K);

	if (num_thrd > 1) {
		thread_fct(X, temp1, NULL, F, nc, K, M, Mp, N, num_thrd, slice_F_TF);
	} else {
		for (j = 0; j < Mc; j++) {
			for (k1 = 0; k1 < K; k1++) {
				for (k2 = 0; k2 < K; k2++) {
					temp1[k1*K+k2] += F[j*K+k1] * F[j*K+k2];
				}
			}
		}
	}

	if (alpha) {
		for (k1 = 0; k1 < K; k1++) {
			for (k2 = 0; k2 < K; k2++) {
				temp1[k1*K+k2] += alpha;
			}
		}
	}
	// F*t(X)							(M N K)
	zeros(temp3,K*N);

	if (num_thrd > 1) {
		thread_fct(X, temp3, NULL, F, nc, K, M, Mp, N, num_thrd, slice_F_TX);
	} else {
		for (jd = 0; jd<Md; jd++) {
			for (i = 0; i < N; i++) {
				value = X[i*Mp+jd];
				for (jm = 0; jm<SIZEUINT; jm++) {
					if (value % 2) {
						for (k1 = 0; k1 < K; k1++) 
							temp3[k1*N+i] += F[(jd*SIZEUINT+jm)*K+k1];
					}
					value >>= 1;
				}
			}
		}
	}

	for (i = 0; i < N; i++) {
		value = X[i*Mp+Md];
		for (jm = 0; jm<Mm; jm++) {
			if (value % 2) {
				for (k1 = 0; k1 < K; k1++) 
					temp3[k1*N+i] += F[(Md*SIZEUINT+jm)*K+k1];
			}
			value >>= 1;
		}
	}

	// solve Q
	nnlsm_blockpivot(temp1,temp3,N,K,tempQ,Y,mem);

	// update Q
	for(i = 0; i < N; i++) 
		for(k = 0; k < K; k++) 
			Q[i*K+k] = tempQ[k*N+i];

	// ouptput criteria
	res = 0.0;
	for (j = 0; j < N*K; j++) {
		res += fabs(Y[j]);
	}

	return res;
}

// normalize_F

void normalize_F(double *F, int M, int nc, int K)
{
	int j, k, c;
	double sum;

	for(j = 0; j < M; j++) {
		for(k = 0; k < K; k++) {
			// for stability
			sum = 0.0;
			for(c = 0; c < nc; c++) 
				sum += F[(nc*j+c)*K+k];
			for(c = 0; c < nc; c++) 
				F[(nc*j+c)*K+k]/= sum;
		}
	}
}

// diff_rel

double diff_rel(double *Q_prec, double *Q, int n)
{
	double mean = 0.0;
	double max = 0.0;
	int i;

	for (i = 0; i < n; i++) {
		if (fabs(Q_prec[i]) >= 0.000001) {
			mean += fabs(Q_prec[i]-Q[i])/fabs(Q_prec[i]);
			max = fmax(max,fabs(Q_prec[i]-Q[i])/fabs(Q_prec[i]));
		}
		Q_prec[i] = Q[i];
	}

	return mean/n;
}

// normalize_Q

void normalize_Q(double *Q, int N, int K)
{
	normalize_lines(Q, N, K);
}
