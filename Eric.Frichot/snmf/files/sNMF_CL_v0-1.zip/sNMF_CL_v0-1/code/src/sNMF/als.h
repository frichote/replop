/**
 * @file als.h
 *
 * @brief set of functions to compute SNMF with als algorithm
 */


#ifndef ALS_H
#define ALS_H

#include "../bituint/bituint.h"
#include "../nnlsm/blockpivot.h"

/** 
 * @brief Algorithm Alternative Least Square
 *
 * @param X 	genome matrice (of NxM elements)
 * @param Q	output matrix Q (of size NxK)
 * @param F	output matrix F (of size Kx(nc*M))
 * @param N 	number of individuals
 * @param M 	number of loci
 * @param nc	number of different values in X
 * @param Mp 	number of columns of X
 * @param K 	number of clusters
 * @param maxiter	maximum number of iterations
 * @param tol 	relative tolerance
 * @param num_thrd 	number of threads used
 * @param alpha 	sparsity parameter
 */
void ALS(bituint *X, double *Q, double *F, int N, int M, int nc, int Mp, int K,
	int maxiter, double tol, int num_thrd, double alpha);

/** 
 * @brief Update F
 *
 * @param F 	ancestral frequencies (of size KxM)
 * @param Q 	admixture coefficients (of size NxK)
 * @param X 	genome matrice (of size NxM)
 * @param N 	number of individuals
 * @param M 	number of loci
 * @param nc	number of different values in X
 * @param Mp 	number of columns of X
 * @param K 	number of clusters
 * @param num_thrd 	number of threads used
 */
void update_F(double *F, double *Q, bituint *X, int N, int M, int nc, int Mp, 
	int K, int num_thrd, Memory mem);

/** 
 * @brief Update F
 *
 * @param F 	ancestral frequencies (of size KxM)
 * @param Q 	admixture coefficients (of size NxK)
 * @param X 	genome matrice (of size NxM)
 * @param N 	number of individuals
 * @param M 	number of loci
 * @param nc	number of different values in X
 * @param Mp 	number of columns of X
 * @param K 	number of clusters
 * @param num_thrd 	number of threads used
 */
double update_nnlsm_F(double *F, double *Q, bituint *X, int N, int M, int nc, 
	int Mp, int K, int num_thrd, Memory mem);

/** @brief Update Q
 *
 * @param Q 	admixture coefficients (of size NxK)
 * @param F 	ancestral frequencies (of size KxM)
 * @param X 	genome matrice (of size NxM)
 * @param N 	number of individuals
 * @param M 	number of loci
 * @param nc	number of different values in X
 * @param Mp 	number of columns of X
 * @param K	number of clusters
 * @param alpha parameter of the algorithm
 */
void update_Q(double *Q, double *F, bituint *X, int N, int M, int nc, int Mp, 
			int K, double alpha, Memory mem);

/** @brief Update Q 
 *
 * @param Q 	admixture coefficients (of size NxK)
 * @param F 	ancestral frequencies (of size KxM)
 * @param X 	genome matrice (of size NxM)
 * @param N 	number of individuals
 * @param M 	number of loci
 * @param nc	number of different values in X
 * @param Mp 	number of columns of X
 * @param K	number of clusters
 * @param alpha parameter of the algorithm
 */
double update_nnlsm_Q(double *Q, double *F, bituint *X, int N, int M, int nc,
	int Mp,	int K, double alpha, Memory mem, int num_thrd);

/** @brief normalize F 
 * 
 * @param F 	ancestral frequencies (of size KxM)
 * @param M 	number of loci
 * @param nc	number of different values in X
 * @param K	number of clusters
 */
void normalize_F(double *F, int M, int nc, int K);

/** @brief normalize Q
 * 
 * @param Q 	ancestral frequencies (of size NxK)
 * @param N 	number of individuals
 * @param K	number of clusters
 */
void normalize_Q(double *Q, int N, int K);

/** @brief mean relative difference between Q_prec and Q
 *
 * @param Q_prec	matrix of size n
 * @param Q	matrix of size n
 * @param n	size of Q
 */
double diff_rel(double *Q_prec, double *Q, int n);

#endif // ALS_H
