/*
    NMF, file: mult.c
    Copyright (C) 2013 François Mathieu, Eric Frichot

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include <stdlib.h>
#include "mult.h"
#include "thread.h"

/*
void thrd_error(double *A, double *B, float *C, double *sum, int M, int N, int K, int num_thrd) 
{
	thread_fct_error(A, B, C, sum, M, N, K, slice_error, num_thrd);
}

void thrd_mult_update_temp3(double *A, bituint *B, double *C, int M, int N, int K, int num_thrd) {

	thread_fct(A, B, C, M, N, K, slice_mult_update_temp3, num_thrd);
}
*/
void basic_mult(double *A, double *B, double *C, int M, int N, int K) {

	int i,j,k;

	for(i=0; i<N; i++) {
		for (j=0; j<M; j++) {
			C[i*M+j] = 0;
			for (k=0; k<K; k++) {
				C[i*M+j] += A[i*K+k]*B[k*M+j];
			}
			//C[i*M+j] = tmp;
		}
	}
}

void optim_mem_mult(double *A, double *B, double *C, int M, int N, int K) {

	int i,j,k;
	double tmp;

	for(i=0; i<N; i++) {
		for (j=0; j<M; j++) {
			tmp = 0;
			for (k=0; k<K; k++) {
				tmp += A[i*K+k]*B[k*M+j];
			}
			C[i*M+j] = tmp;
		}
	}
}

/*
void optim_mult(double *A, double *B, double *C, int M, int N, int K) {

	int i,j,k,d;
	int D=10;
	int from; // note that this 'slicing' works fine
	int to; // even if SIZE is not divisible by num_thrd

	for(i=0; i<N; i++) {
		for (j=0; j<M; j++) {
			C[i*M+j] = 0;
		}
	}

	for(d=0; d<D; d++) {
		from = (d * K)/D; // note that this 'slicing' works fine
		to = ((d+1) * K)/D; // even if SIZE is not divisible by num_thrd
		for(i=0; i<N; i++) {
			for (j=0; j<M; j++) {
				//tmp = 0;
				for (k=from; k<to; k++) {
					C[i*M+j] += A[i*K+k]*B[k*M+j];
				}
				//C[i*M+j] += tmp;
			}
		}
	}
}
*/
