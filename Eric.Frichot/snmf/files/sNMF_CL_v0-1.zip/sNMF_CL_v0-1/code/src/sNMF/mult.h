/**
 * @file mult.h
 *
 * @brief functions to manage matrix multiplication
 */

#ifndef MULT_H
#define MULT_H

#include "../bituint/bituint.h"

// compute the mean square error
void thrd_error(double *A, double *B, float *C, double *sum, int M, int N, int K, int num_thrd);

// C(N,M) = A(N,K)*B(K,M)
void thrd_mult_update_temp3(double *A, bituint *B, double *C, int M, int N, int K, int num_thrd);

// C(N,M) = A(N,K)*B(K,M)
void basic_mult(double *A, double *B, double *C, int M, int N, int K);

// C(N,M) = A(N,K)*B(K,M)
//void optim_mult(double *A, double *B, double *C, int M, int N, int K);

// C(N,M) = A(N,K)*B(K,M)
void optim_mem_mult(double *A, double *B, double *C, int M, int N, int K);
#endif // MULT_H
