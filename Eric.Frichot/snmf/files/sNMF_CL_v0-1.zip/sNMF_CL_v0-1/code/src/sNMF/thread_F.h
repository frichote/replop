/**
 * @file thread_V.h
 *
 * @brief functions to compute new values for V from the conditional distribution 
 *        (possibly multithreaded) 
 */

#ifndef THREAD_F_H
#define THREAD_F_H

/**
 * compute a slice of conditional mean for V
 *
 * @param G     a specific structure for multi-threading
 */
void slice_temp3_X(void *G);

#endif // THREAD_LIKE_H
