#ifndef TITLE_H
#define TITLE_H

#define CMD_TITLE tr("LFMM")
#define GUI_TITLE tr("LFMM GUI")

#endif//TITLE_H
