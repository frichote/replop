#include "FortuneStructures.h"

ostream& operator<<(ostream& os, const SPosition& pos)
{
	os << pos.m_dX << ' ' << pos.m_dY;
	return os;
}

istream& operator>>(istream& is, SPosition& pos)
{
	is >> pos.m_dX >> pos.m_dY;
	return is;
}

ostream& operator<<(ostream& os, const SPoint& pt)
{
	os << pt.m_psXY << ' ' << pt.m_nIndex;
	return os;
}

istream& operator>>(istream& is, SPoint& pt)
{
	is >> pt.m_psXY >> pt.m_nIndex;
	return is;
}

ostream& operator<<(ostream& os, const CEdge& edge)
{
	os << edge.m_dA << ' ' << edge.m_dB << ' ' << edge.m_dC << ' ' 
		<< edge.m_ptEnd[0] << ' ' << edge.m_ptEnd[1] << ' ' 
		<< edge.m_ptReg[0] << ' ' << edge.m_ptReg[1] << ' ' 
		<< edge.m_nIndex;
	return os;
}

istream& operator>>(istream& is, CEdge& edge)
{
	is >> edge.m_dA >> edge.m_dB >> edge.m_dC 
		>> edge.m_ptEnd[0] >> edge.m_ptEnd[1] 
		>> edge.m_ptReg[0] >> edge.m_ptReg[1] 
		>> edge.m_nIndex;
	return is;
}

