#ifndef __FORTUNE_STRUCTURES__
#define __FORTUNE_STRUCTURES__

/*! \file FortuneStructures.h
 *  \brief Definetion of Structures/Classes Used in Fortune's Plane Sweep Algorithm
 */

#include <iostream>

using namespace std;

//! Left Edge
#define LE 0

//! Right Edge
#define RE 1

#ifndef NULL
#define NULL 0
#endif//NULL

//! Null SPosition Pointer
#define PS_NULL	static_cast<SPosition*>(NULL)

//! Null SPoint Pointer
#define PT_NULL static_cast<SPoint*>(NULL)

//! Null SEdge Pointer
#define EG_NULL static_cast<SEdge*>(NULL)

//! Null SHalfEdge Pointer
#define HE_NULL static_cast<SHalfEdge*>(NULL)

//! Representation of Deleted SEdge Pointer
#define EG_DELETED reinterpret_cast<SEdge*>(-2)

//! Default Free List Size
#define DF_SIZE 1024

//! Position
struct SPosition
{
	//! Default Constructor
	/*! \author Chibiao Chen
	 */
	SPosition()
	{
		m_dX = 0.0;
		m_dY = 0.0;
	}

	/*! \author Chibiao Chen
	 */
	bool operator==(const SPosition& rhs) const
	{
		return m_dX == rhs.m_dX && m_dY == rhs.m_dY;
	}

	/*! \author Chibiao Chen
	 */
	friend ostream& operator<<(ostream& os, const SPosition& pos);

	/*! \author Chibiao Chen
	 */
	friend istream& operator>>(istream& is, SPosition& pos);

	double m_dX;	//!< X Coordinate
	double m_dY;	//!< Y Coordinate
};

//! Point (Site or Vertex)
struct SPoint
{
	//! Default Constructor
	/*! \author Chibiao Chen
	 */
	SPoint()
	{
		m_nIndex = 0;
	}

	/*! \author Chibiao Chen
	 */
	bool operator==(const SPoint& rhs) const
	{
		return m_psXY == rhs.m_psXY && m_nIndex == rhs.m_nIndex;
	}

	/*! \author Chibiao Chen
	 */
	friend ostream& operator<<(ostream& os, const SPoint& pt);

	/*! \author Chibiao Chen
	 */
	friend istream& operator>>(istream& is, SPoint& pt);

	SPosition	m_psXY;		//!< Position
	int			m_nIndex;	//!< Index
};

//! Voronoi Edge
struct SEdge
{
	//! Default Constructor
	/*! \author Chibiao Chen
	 */
	SEdge()
	{
		m_dA = 0.0;
		m_dB = 0.0;
		m_dC = 0.0;
		for (int i = 0; i < 2; i++)
		{
			m_pptEnd[i] = PT_NULL;
			m_pptReg[i] = PT_NULL;
		}
		m_nIndex = 0;
	}

	double	m_dA;	//!< Parameter of Line Equation ax + by = c (a)
	double	m_dB;	//!< Parameter of Line Equation ax + by = c (b)
	double	m_dC;	//!< Parameter of Line Equation ax + by = c (c)

	SPoint*	m_pptEnd[2];	//!< Two End Points of Edge (Vertex)
	SPoint*	m_pptReg[2];	//!< Two Points Bisected by Edge (Site)
	int		m_nIndex;		//!< Index
};

// Voronoi Edge - Version without Pointers
class CEdge
{
public:
	//! Default Constructor
	/*! \author Chibiao Chen
	 */
	CEdge()
	{
		m_dA = 0.0;
		m_dB = 0.0;
		m_dC = 0.0;
		m_nIndex = 0;
	}

	/*! \author Chibiao Chen
	 */
	friend ostream& operator<<(ostream& os, const CEdge& edge);

	/*! \author Chibiao Chen
	 */
	friend istream& operator>>(istream& is, CEdge& edge);
	
	double	m_dA;	//!< Parameter of Line Equation ax + by = c (a)
	double	m_dB;	//!< Parameter of Line Equation ax + by = c (b)
	double	m_dC;	//!< Parameter of Line Equation ax + by = c (c)

	SPoint	m_ptEnd[2];	//!< Two End Points of Edge (Vertex)
	SPoint	m_ptReg[2];	//!< Two Points Bisected by Edge (Site)
	int		m_nIndex;	//!< Index
};

struct SHalfEdge
{
	//! Default Constructor
	/*! \author Chibiao Chen
	 */
	SHalfEdge()
	{
		m_pheLft = HE_NULL;
		m_pheRht = HE_NULL;
		m_peEdge = EG_NULL;
		m_nSide = 0;
		m_pptVertex = PT_NULL;
		m_dYStar = 0.0;
		m_phePQNext = HE_NULL;
	}

	SHalfEdge*	m_pheLft;		//!< Left Half Edge
	SHalfEdge*	m_pheRht;		//!< Right Half Edge
	SEdge*		m_peEdge;		//!< Edge
	int			m_nSide;		//!< Side of Half Edge
	SPoint*		m_pptVertex;	//!< Vertex
	double		m_dYStar;		//!< Y Position of the Event
	SHalfEdge*	m_phePQNext;	//!< Next Half Edge in the Priority Queue
};

#endif//__FORTUNE_STRUCTURES__

