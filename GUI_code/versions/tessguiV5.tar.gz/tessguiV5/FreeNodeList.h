#ifndef __FREE_NODE_LIST__
#define __FREE_NODE_LIST__

#include <deque>

using namespace std;

//! A Free Node List
template < typename T > class CFreeNodeList
{
public:
	/*! Default Constructor; Initialization
	 *  \author Chibiao Chen
	 */
	CFreeNodeList();

	/*! Destructor; Freeing Memory (Not Really Needed)
	 *  \author Chibiao Chen
	 */
	virtual ~CFreeNodeList();

	//! Returning One Free Node
	/*! \return The Free Node
	 *  \author Chibiao Chen
	 */
	T* GetFreeNode();

private:
	//! Initializing the Internal Container (deque) to a Given Size
	/*! \param nInitialSize The Initial Size of the Internal Container
	 *  \author Chibiao Chen
	 */
	void Initialize(int nInitialSize);

	int m_nInitialSize;			//!< Initial Size of Internal Container; Increasing Step Also
	deque< T > m_dqtFreeNode;	//!< Internal Container; vector will NOT work here.
	int m_nIndex;				//!< Node Index
};

template < typename T > CFreeNodeList< T >::CFreeNodeList()
{
	Initialize(DF_SIZE);
}

template < typename T > CFreeNodeList< T >::~CFreeNodeList()
{
	m_dqtFreeNode.clear();
}

template < typename T > T* CFreeNodeList< T >::GetFreeNode()
{
	if (m_nIndex == (m_dqtFreeNode.size()))
	{
		m_dqtFreeNode.resize(m_nIndex + m_nInitialSize);
	}

	return &m_dqtFreeNode[m_nIndex++];
}

template < typename T > void CFreeNodeList< T >::Initialize(int nInitialSize)
{
	m_nInitialSize = nInitialSize;
	m_dqtFreeNode.resize(m_nInitialSize);
	m_nIndex = 0;
}

#endif//__FREE_NODE_LIST__
