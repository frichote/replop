#include "HalfEdgeList.h"

CHalfEdgeList::CHalfEdgeList()
{
	Initialize(-8.0, 8.0, DF_SIZE);
}

CHalfEdgeList::CHalfEdgeList(double dXMin, double dXMax, int nSize)
{
	Initialize(dXMin, dXMax, nSize);
}

CHalfEdgeList::~CHalfEdgeList()
{
	m_vpheHash.clear();
}

SHalfEdge* CHalfEdgeList::Create(SEdge* peThis, int nSide)
{
	SHalfEdge* pheNew = m_fnlhePrivate.GetFreeNode();
	pheNew->m_peEdge = peThis;
	pheNew->m_nSide = nSide;
	pheNew->m_phePQNext = HE_NULL;
	pheNew->m_pptVertex = PT_NULL;

	return pheNew;
}

void CHalfEdgeList::Insert(SHalfEdge* pheLft, SHalfEdge* pheNew)
{
	pheNew->m_pheLft = pheLft;
	pheNew->m_pheRht = pheLft->m_pheRht;
	pheLft->m_pheRht->m_pheLft = pheNew;
	pheLft->m_pheRht = pheNew;
}

void CHalfEdgeList::Delete(SHalfEdge* pheThis)
{
	pheThis->m_pheLft->m_pheRht = pheThis->m_pheRht;
	pheThis->m_pheRht->m_pheLft = pheThis->m_pheLft;
	pheThis->m_peEdge = EG_DELETED;
}

SHalfEdge* CHalfEdgeList::GetLftBnd(SPosition* ppsThis)
{
	int nBucket = static_cast<int>((ppsThis->m_dX - m_dXMin) / m_dDX * m_nSize);
	if (nBucket < 0)
	{
		nBucket = 0;
	}
	if (nBucket > m_nSize - 1)
	{
		nBucket = m_nSize - 1;
	}
	SHalfEdge* pheThis = GetHash(nBucket);
	if (pheThis == HE_NULL)
	{
		for (int i = 1; true; i++)
		{
			if ((pheThis = GetHash(nBucket - i)) != HE_NULL)
			{
				break;
			}
			if ((pheThis = GetHash(nBucket + i)) != HE_NULL)
			{
				break;
			}
		}
	}

	if (pheThis == m_pheLftEnd || pheThis != m_pheRhtEnd && RightOf(pheThis, ppsThis))
	{
		do 
		{
			pheThis = pheThis->m_pheRht;	
		} 
		while(pheThis != m_pheRhtEnd && RightOf(pheThis, ppsThis));

		pheThis = pheThis->m_pheLft;
	}
	else
	{
		do 
		{
			pheThis = pheThis->m_pheLft;	
		} 
		while(pheThis != m_pheLftEnd && !RightOf(pheThis, ppsThis));
	}

	if (nBucket > 0 && nBucket < m_nSize - 1)
	{
		m_vpheHash[nBucket] = pheThis;
	}

	return pheThis;
}

SPoint* CHalfEdgeList::GetLftRegPnt(SHalfEdge* pheThis, SPoint* pptBotSite)
{
	if (pheThis->m_peEdge == EG_NULL)
	{
		return pptBotSite;
	}
	
	return pheThis->m_nSide == LE ? 
		pheThis->m_peEdge->m_pptReg[LE] : pheThis->m_peEdge->m_pptReg[RE];
}

SPoint* CHalfEdgeList::GetRhtRegPnt(SHalfEdge* pheThis, SPoint* pptBotSite)
{
	if (pheThis->m_peEdge == EG_NULL)
	{
		return pptBotSite;
	}

	return pheThis->m_nSide == LE ? 
		pheThis->m_peEdge->m_pptReg[RE] : pheThis->m_peEdge->m_pptReg[LE];
}

void CHalfEdgeList::Initialize(double dXMin, double dXMax, int nSize)
{
	m_dXMin = dXMin;
	m_dXMax = dXMax;
	m_dDX = m_dXMax - m_dXMin;
	m_nSize = nSize;
	for (int i = 0; i < m_nSize; i++)
	{
		m_vpheHash.push_back(HE_NULL);
	}
	m_pheLftEnd = Create(EG_NULL, 0);
	m_pheRhtEnd = Create(EG_NULL, 0);
	m_pheLftEnd->m_pheLft = HE_NULL;
	m_pheLftEnd->m_pheRht = m_pheRhtEnd;
	m_pheRhtEnd->m_pheLft = m_pheLftEnd;
	m_pheRhtEnd->m_pheRht = HE_NULL;
	m_vpheHash[0] = m_pheLftEnd;
	m_vpheHash[m_nSize - 1] = m_pheRhtEnd;
}

SHalfEdge* CHalfEdgeList::GetHash(int nIndex)
{
	if (nIndex < 0 || nIndex > m_nSize - 1)
	{
		return HE_NULL;
	}
	SHalfEdge* pheThis = m_vpheHash[nIndex];
	if (pheThis == HE_NULL || pheThis->m_peEdge != EG_DELETED)
	{
		return pheThis;
	}
	m_vpheHash[nIndex] = HE_NULL;

	return HE_NULL;
}

bool CHalfEdgeList::RightOf(SHalfEdge* pheThis, SPosition* ppsThis)
{
	SEdge* peThis = pheThis->m_peEdge;
	SPoint* pptTopSite = peThis->m_pptReg[1];
	bool bRightOfSite = ppsThis->m_dX > pptTopSite->m_psXY.m_dX;
	if (bRightOfSite && pheThis->m_nSide == LE)
	{
		return true;
	}
	if (!bRightOfSite && pheThis->m_nSide == RE)
	{
		return false;
	}

	bool bAbove;
	if (peThis->m_dA == 1.0)
	{
		double dDeltaX = ppsThis->m_dX - pptTopSite->m_psXY.m_dX;
		double dDeltaY = ppsThis->m_dY - pptTopSite->m_psXY.m_dY;
		bool bFast = false;
		if (!bRightOfSite && peThis->m_dB < 0.0 || bRightOfSite && peThis->m_dB >= 0.0)
		{
			bAbove = dDeltaY >= peThis->m_dB * dDeltaX;
			bFast = bAbove;
		}
		else
		{
			bAbove = ppsThis->m_dX + ppsThis->m_dY * peThis->m_dB > peThis->m_dC;
			if (peThis->m_dB < 0.0)
			{
				bAbove = !bAbove;
			}
			if (!bAbove)
			{
				bFast = true;
			}
		}
		if (!bFast)
		{
			double dDeltaX1 = pptTopSite->m_psXY.m_dX - peThis->m_pptReg[0]->m_psXY.m_dX;
			bAbove = peThis->m_dB * (dDeltaX * dDeltaX - dDeltaY * dDeltaY) < dDeltaX1 * 
				dDeltaY * (1.0 + 2.0 * dDeltaX / dDeltaX1 + peThis->m_dB * peThis->m_dB);
			if (peThis->m_dB < 0.0)
			{
				bAbove = !bAbove;
			}
		}
	}
	else  // peThis->m_dB == 1.0
	{
		double dT0 = peThis->m_dC - peThis->m_dA * ppsThis->m_dX;
		double dT1 = ppsThis->m_dY - dT0;
		double dT2 = ppsThis->m_dX - pptTopSite->m_psXY.m_dX;
		double dT3 = dT0 - pptTopSite->m_psXY.m_dY;
		bAbove = dT1 * dT1 > dT2 * dT2 + dT3 * dT3;
	}

	return pheThis->m_nSide == LE ? bAbove : !bAbove;
}
