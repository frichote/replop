#ifndef __HALF_EDGE_LIST__
#define __HALF_EDGE_LIST__

#include <vector>

#include "FortuneStructures.h"
#include "FreeNodeList.h"

using namespace std;

class CHalfEdgeList
{
public:
	CHalfEdgeList();
	CHalfEdgeList(double dXMin, double dXMax, int nSize);
	virtual ~CHalfEdgeList();
	SHalfEdge* Create(SEdge* peThis, int nSide);
	void Insert(SHalfEdge* pheLft, SHalfEdge* pheNew);
	void Delete(SHalfEdge* pheThis);
	SHalfEdge* GetLftBnd(SPosition* ppsThis);
	SHalfEdge* GetLft(SHalfEdge* pheThis);
	SHalfEdge* GetRht(SHalfEdge* pheThis);
	SHalfEdge* GetLftEnd();
	SHalfEdge* GetRhtEnd();
	SPoint* GetLftRegPnt(SHalfEdge* pheThis, SPoint* pptBotSite);
	SPoint* GetRhtRegPnt(SHalfEdge* pheThis, SPoint* pptBotSite);

private:
	void Initialize(double dXMin, double dXMax, int nSize);
	SHalfEdge* GetHash(int nIndex);
	bool RightOf(SHalfEdge* pheThis, SPosition* ppsThis);

	vector< SHalfEdge* > m_vpheHash;
	int m_nSize;
	SHalfEdge* m_pheLftEnd;
	SHalfEdge* m_pheRhtEnd;
	CFreeNodeList< SHalfEdge > m_fnlhePrivate;
	double m_dXMin;
	double m_dXMax;
	double m_dDX;
};

inline SHalfEdge* CHalfEdgeList::GetLft(SHalfEdge* pheThis)
{
	return pheThis->m_pheLft;
}

inline SHalfEdge* CHalfEdgeList::GetRht(SHalfEdge* pheThis)
{
	return pheThis->m_pheRht;
}

inline SHalfEdge* CHalfEdgeList::GetLftEnd()
{
	return m_pheLftEnd;
}

inline SHalfEdge* CHalfEdgeList::GetRhtEnd()
{
	return m_pheRhtEnd;
}

#endif//__HALF_EDGE_LIST__
