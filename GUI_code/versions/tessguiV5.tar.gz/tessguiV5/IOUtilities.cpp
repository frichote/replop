#include <cstdlib>
#include <fstream>
#include <iostream>
#include <QRegExp>
#include <QString>
#include "IOUtilities.h"

using namespace std;

bool SaveMatrixNN(const DBL_VCTR_2D& mat, const string& File)
{
	if (mat.size() == 0)
	{
		cerr << "Uninitialized mat - SaveMatrixNN" << endl;
		exit(EXIT_FAILURE);
	}
	int N = static_cast<int>(mat.size());
	int i,j;

	ofstream ofs(File.c_str());
	if (!ofs.good())
	{
		cerr << "Cannot open file " << File << " - SaveMatrixNN" << endl;
		exit(EXIT_FAILURE);
	}

	for (i=0;i<N;i++)
	{
		for (j=0;j<N;j++)
		{
			ofs << mat[i][j] << "\t" ;
		}
		ofs << endl;
	}

	ofs.close();

	return true;

}

bool SaveData(const DBL_VCTR_2D& C, const INT_VCTR_3D& X, const string& File, const bool specialFormat)
{
	if (C.size() == 0)
	{
		cerr << "Uninitialized C - SaveData" << endl;
		exit(EXIT_FAILURE);
	}

	if (X.size() == 0)
	{
		cerr << "Uninitialized X - SaveData" << endl;
		exit(EXIT_FAILURE);
	}

	if (C.size() < X.size())
	{
		cerr << "Mismatched C and X - SaveData" << endl;
		exit(EXIT_FAILURE);
	}

	int i, a, l;

	ofstream ofs(File.c_str());
	if (!ofs.good())
	{
		cerr << "Cannot open file " << File << " - SaveData" << endl;
		exit(EXIT_FAILURE);
	}

	int M = static_cast<int>(C.size());
	int N = static_cast<int>(X.size());
	int A = static_cast<int>(X[0].size());
	int L = static_cast<int>(X[0][0].size());
	
	if (!specialFormat)
	{
		for (i = 0; i < M; i++)
		{
			for (a = 0; a < A; a++)
			{
				ofs << C[i][0] << "\t" << C[i][1] << "\t";
				if (i < N)
				{
					for (l = 0; l < L; l++)
					{
						ofs << X[i][a][l] << "\t";
					}
				} else
				{
					for (l = 0; l < L; l++)
					{
						ofs << 0 << "\t";
					}
				}
				ofs << endl;
			}
		}
	}
	
	if (specialFormat)
	{
		for (i = 0; i < M; i++)
		{
			ofs << C[i][0] << "\t" << C[i][1] << "\t";
			if (i < N)
			{
				for (l = 0; l < L; l++)
				{
					for (a = 0; a < A; a ++)
					{
						ofs << X[i][a][l] << "\t";
					}
				}
			} else
			{
				for (l = 0; l < L; l++)
				{
					for (a = 0; a < A; a ++)
					{
						ofs << 0 << "\t";
					}
				}
			}
			ofs << endl;
		}
	}

	ofs.close();

	return true;
}

bool LoadData(DBL_VCTR_2D& C, INT_VCTR_3D& X, int ER, int EC, const string& File, const bool& specialFormat, const bool& isRecessive)
{
	if (C.size() == 0)
	{
		cerr << "Uninitialized C - LoadData" << endl;
		exit(EXIT_FAILURE);
	}

	if (X.size() == 0)
	{
		cerr << "Uninitialized X - LoadData" << endl;
		exit(EXIT_FAILURE);
	}

	if (C.size() < X.size())
	{
		cerr << "Mismatched C and X - LoadData" << endl;
		exit(EXIT_FAILURE);
	}

	int i, a, l;

	ifstream ifs(File.c_str());
	if (!ifs.good())
	{
		cerr << "Cannot open file " << File << " - LoadData" << endl;
		exit(EXIT_FAILURE);
	}

	int M = static_cast<int>(C.size());
	int N = static_cast<int>(X.size());
	int A = static_cast<int>(X[0].size());
	int L = static_cast<int>(X[0][0].size());

	// Load and discard the extra rows.
	char extraRow[10240];
	for (int er = 0; er < ER; er++)
	{
		ifs.getline(extraRow, 10240);
	}
	
	if (isRecessive)
	{
		//Not needed here
		ifs.getline(extraRow, 10240);
	}
	
	if (!specialFormat)
	{
		for (i = 0; i < M; i++)
		{
			for (a = 0; a < A; a++)
			{
                        	// Load and discard the extra columns.
				string discarded;
				for (int ec = 0; ec < EC; ec++)
				{
					ifs >> discarded;
				}
                        
				ifs >> C[i][0] >> C[i][1];
				if (i < N)
				{
					for (l = 0; l < L; l++)
					{
						ifs >> X[i][a][l];
					}
				} else
				{
					for (l = 0; l < L; l++)
					{
						ifs >> discarded;
					}
				}
			}
		}
	}
	if (specialFormat)
	{
		for (i = 0; i < M; i ++)
		{
			// Load and discard the extra columns.
			string discarded;
			for (int ec = 0; ec < EC; ec++)
			{
				ifs >> discarded;
			}
                        
			ifs >> C[i][0] >> C[i][1];
			if (i < N)
			{
				for (l = 0; l < L; l++)
				{
					for (a = 0; a < A; a ++)
					{
						ifs >> X[i][a][l];
					}
				}
			} else
			{
				for (l = 0; l < L; l++)
				{
					for (a = 0; a < A; a ++)
					{
						ifs >> discarded;
					}
				}
			}
		}
	}

	ifs.close();

	return true;
}

// bool GenepopToTess(const string &inFile, const int& ploidy, const string &outFile)
// {
// 	
// 	ifstream ifs(inFile.c_str());
// 	if (!ifs.good())
// 	{
// 		cerr << "Cannot open file " << inFile << " - GenepopToTess" << endl;
// 		exit(EXIT_FAILURE);
// 	}
// 	ofstream ofs(outFile.c_str());
// 	if (!ofs.good())
// 	{
// 		cerr << "Cannot open file " << outFile << " - GenepopToTess" << endl;
// 		exit(EXIT_FAILURE);
// 	}
// 	
// 	QRegExp rxData("(\\d+)");
// 	QRegExp rxPop("[pP][oO][pP]");
// 	QRegExp rxPopname("(\\S+)");
// 	string currLine,discarded;
// 	int al1,al2;
// 	QString QLine;
// 	
// 	int pos = 0;
// 	while (! ifs.eof() )
// 	{
// 		getline(ifs,currLine);
// 		QLine = QString::fromStdString(currLine);
// 		pos = 0;
// 		if (rxPop.exactMatch(QLine))
// 		{
// 			ifs >> discarded; //we discard the POP line
// 			getline(ifs,currLine);
// 			QLine = QString::fromStdString(currLine);
// 			while ((pos = rxData.indexIn(QLine, pos)) != -1) {
// 				ofs << rxData.cap(1).toStdString();
// 				pos += rxData.matchedLength();
// 			}
// 		}
// 	}
// 	ifs.close();
// 	ofs.close();
// }