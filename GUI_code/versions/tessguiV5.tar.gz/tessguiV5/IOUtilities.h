#ifndef __IO_UTILITIES__
#define __IO_UTILITIES__

#include <string>

#include "VectorUtilities.h"

using namespace std;
bool SaveMatrixNN(const DBL_VCTR_2D& mat, const string& File);
bool SaveData(const DBL_VCTR_2D& C, const INT_VCTR_3D& X, const string& File, const bool specialFormat);
bool LoadData(DBL_VCTR_2D& C, INT_VCTR_3D& X, int ER, int EC, const string& File, const bool& specialFormat, const bool& isRecessive);
// bool GenepopToTess(const string &inFile, const int& ploidy, const string &outFile);
#endif//__IO_UTILITIES__
