#include "PriorityQueue.h"

CPriorityQueue::CPriorityQueue()
{
	Initialize(-8.0, 8.0, DF_SIZE);
}

CPriorityQueue::CPriorityQueue(double dYMin, double dYMax, int nSize)
{
	Initialize(dYMin, dYMax, nSize);
}

CPriorityQueue::~CPriorityQueue()
{
	m_vheHash.clear();
}

void CPriorityQueue::Insert(SHalfEdge* pheThis, SPoint* pptVertex, double dOffset)
{
	pheThis->m_pptVertex = pptVertex;
	pheThis->m_dYStar = pptVertex->m_psXY.m_dY + dOffset;
	SHalfEdge* pheLast;
	SHalfEdge* pheNext;
	pheLast = &m_vheHash[Bucket(pheThis)];
	while (
		(pheNext = pheLast->m_phePQNext) != HE_NULL &&
			(pheThis->m_dYStar > pheNext->m_dYStar ||
				pheThis->m_dYStar == pheNext->m_dYStar && 
				pptVertex->m_psXY.m_dX > pheNext->m_pptVertex->m_psXY.m_dX)
	)
	{
		pheLast = pheNext;
	}
	pheThis->m_phePQNext = pheLast->m_phePQNext;
	pheLast->m_phePQNext = pheThis;
	m_nCount++;
}

void CPriorityQueue::Delete(SHalfEdge* pheThis)
{
	if(pheThis->m_pptVertex != PT_NULL)
	{	
		SHalfEdge* pheLast = &m_vheHash[Bucket(pheThis)];
		while (pheLast->m_phePQNext != pheThis)
		{
			pheLast = pheLast->m_phePQNext;
		}
		pheLast->m_phePQNext = pheThis->m_phePQNext;
		pheThis->m_pptVertex = PT_NULL;
		m_nCount--;
	}
}

SPosition CPriorityQueue::GetMinPosition()
{
	while(m_vheHash[m_nMin].m_phePQNext == HE_NULL) 
	{
		m_nMin++;
	}
	SPosition psXY;
	psXY.m_dX = m_vheHash[m_nMin].m_phePQNext->m_pptVertex->m_psXY.m_dX;
	psXY.m_dY = m_vheHash[m_nMin].m_phePQNext->m_dYStar;
	
	return psXY;
}

SHalfEdge* CPriorityQueue::ExtractMinHalfEdge()
{
	SHalfEdge* pheThis = m_vheHash[m_nMin].m_phePQNext;
	m_vheHash[m_nMin].m_phePQNext = pheThis->m_phePQNext;
	m_nCount--;

	return pheThis;
}

void CPriorityQueue::Initialize(double dYMin, double dYMax, int nSize)
{
	m_dYMin = dYMin;
	m_dYMax = dYMax;
	m_dDY = m_dYMax - m_dYMin;
	m_nSize = nSize;
	SHalfEdge pheThis;
	pheThis.m_phePQNext = HE_NULL;
	for (int i = 0; i < m_nSize; i++)
	{
		m_vheHash.push_back(pheThis);
	}
	m_nCount = 0;
	m_nMin = 0;
}

int CPriorityQueue::Bucket(SHalfEdge* pheThis)
{
	int nBucket = static_cast<int>((pheThis->m_dYStar - m_dYMin) / m_dDY * m_nSize);
	if (nBucket < 0)
	{
		nBucket = 0;
	}
	if (nBucket > m_nSize - 1)
	{
		nBucket = m_nSize - 1;
	}
	if (nBucket < m_nMin)
	{
		m_nMin = nBucket;
	}

	return nBucket;
}
