#ifndef __PRIORITY_QUEUE__
#define __PRIORITY_QUEUE__

#include <vector>

#include "FortuneStructures.h"

using namespace std;

class CPriorityQueue
{
public:
	CPriorityQueue();
	CPriorityQueue(double dYMin, double dYMax, int nSize);
	virtual ~CPriorityQueue();

	void Insert(SHalfEdge* pheThis, SPoint* pptVertex, double dOffset);
	void Delete(SHalfEdge* pheThis);
	bool Empty();
	SPosition GetMinPosition();
	SHalfEdge* ExtractMinHalfEdge();
private:
	void Initialize(double dYMin, double dYMax, int nSize);
	int Bucket(SHalfEdge* pheThis);
private:
	vector< SHalfEdge > m_vheHash;
	int m_nSize;
	int m_nCount;
	int m_nMin;
	double m_dYMin;
	double m_dYMax;
	double m_dDY;
};

inline bool CPriorityQueue::Empty()
{
	return m_nCount == 0;
}

#endif//__PRIORITY_QUEUE__
