#include <ctime>

#include "RNGUtilities.h"

void AllocRNG(gsl_rng*& rng, const gsl_rng_type* type)
{
	unsigned long ulSeed = static_cast<unsigned long>(time(NULL));

	rng = gsl_rng_alloc(type);
	gsl_rng_set(rng, ulSeed);
}

void FreeRNG(gsl_rng*& rng)
{
	if (rng)
	{
		gsl_rng_free(rng);
		rng = NULL;
	}
}
