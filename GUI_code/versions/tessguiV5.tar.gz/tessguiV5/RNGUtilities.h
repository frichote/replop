#ifndef __RNG_UTILITIES__
#define __RNG_UTILITIES__

#include <gsl/gsl_rng.h>

void AllocRNG(gsl_rng*& rng, const gsl_rng_type* type);
void FreeRNG(gsl_rng*& rng);

#endif//__RNG_UTILITIES__
