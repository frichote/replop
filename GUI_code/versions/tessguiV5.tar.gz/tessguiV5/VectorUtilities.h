#ifndef __VECTROR_UTILITIES__
#define __VECTROR_UTILITIES__

/*! \file VectorUtilities.h
 *  \brief Header File for Multi-Dimensional Vector Definitions
 *
 *  For all vectors defined in this file with dimension larger than one, you must 
 *  initialize them before using them and the initialization can be done exactly once!
 */

#include <vector>
#include <iostream>

using namespace std;

typedef vector< vector< vector< vector< int > > > >		INT_VCTR_4D;
typedef vector< vector< vector< int > > >		INT_VCTR_3D;
typedef vector< vector< int > >					INT_VCTR_2D;
typedef vector< int >							INT_VCTR_1D;
typedef vector< vector< int* > >				PINT_VCTR_2D;
typedef vector< int* >							PINT_VCTR_1D;

typedef vector< vector< vector< vector< bool > > > >	BOOL_VCTR_4D;
typedef vector< vector< vector< bool > > >		BOOL_VCTR_3D;
typedef vector< vector< bool > >				BOOL_VCTR_2D;
typedef vector< bool >							BOOL_VCTR_1D;
typedef vector< vector< bool* > >				PBOOL_VCTR_2D;
typedef vector< bool* >							PBOOL_VCTR_1D;

typedef vector< vector< vector< vector< float > > > >	FLT_VCTR_4D;
typedef vector< vector< vector< float > > >		FLT_VCTR_3D;
typedef vector< vector< float > >				FLT_VCTR_2D;
typedef vector< float >							FLT_VCTR_1D;
typedef vector< vector< float* > >				PFLT_VCTR_2D;
typedef vector< float* >						PFLT_VCTR_1D;

typedef vector< vector< vector< vector< double > > > >	DBL_VCTR_4D;
typedef vector< vector< vector< double > > >	DBL_VCTR_3D;
typedef vector< vector< double > >				DBL_VCTR_2D;
typedef vector< double >						DBL_VCTR_1D;
typedef vector< vector< double* > >				PDBL_VCTR_2D;
typedef vector< double* >						PDBL_VCTR_1D;

//! Initializing a One Dimensional Vector
/*! \param V One Dimensional Vector To Be Initialized
 *  \param D1 Size of Dimension 1
 *  \param Val The Initializing Value
 *  \author Chibiao Chen
 */
template < typename T > void InitVctr1D(vector< T >& V, 
					const int D1, 
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr1D" << endl;
		return;
	}

	for (int i = 0; i < D1; i++)
	{
		V.push_back(Val);
	}
}

//! Initializing a Two Dimensional Vector
/*! \param V Two Dimensional Vector To Be Initialized
 *  \param D1 Size of Dimension 1
 *  \param D2 Size of Dimension 2
 *  \param Val The Initializing Value
 *  \author Chibiao Chen
 */
template < typename T > void InitVctr2D(vector< vector< T > >& V, 
					const int D1, 
     const int D2, 
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr2D" << endl;
		return;
	}

	vector< T > Temp(D2, Val);
	for (int i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
}

//! Initializing a Two Dimensional Vector
/*! \param V Two Dimensional Vector To Be Initialized
 *  \param D1 Size of Dimension 1
 *  \param D2 Size of Dimension 2
 *  \param Val The Initializing Value
 *  \author Chibiao Chen
 */
template < typename T > void InitVctr2D(vector< vector< T > >& V, 
					const int D1, 
     const int D2[], 
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr2D" << endl;
		return;
	}

	for (int i = 0; i < D1; i++)
	{
		vector< T > Temp(D2[i], Val);
		V.push_back(Temp);
	}
}

//! Initializing a Two Dimensional Vector
/*! \param V Two Dimensional Vector To Be Initialized
 *  \param D1 Size of Dimension 1
 *  \param D2 Size of Dimension 2
 *  \param Val The Initializing Value
 *  \author Chibiao Chen
 */
template < typename T > void InitVctr2D(vector< vector< T > >& V, 
					const int D1, 
     const INT_VCTR_1D& D2, 
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr2D" << endl;
		return;
	}

	for (int i = 0; i < D1; i++)
	{
		vector< T > Temp(D2[i], Val);
		V.push_back(Temp);
	}
}

//! Initializing a Three Dimensional Vector
/*! \param V Three Dimensional Vector To Be Initialized
 *  \param D1 Size of Dimension 1
 *  \param D2 Size of Dimension 2
 *  \param D3 Size of Dimension 3
 *  \param Val The Initializing Value
 *  \author Chibiao Chen
 */
template < typename T > void InitVctr3D(vector< vector< vector< T > > >& V, 
					const int D1, 
     const int D2, 
     const int D3, 
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr3D" << endl;
		return;
	}

	vector< vector< T > > Temp;
	InitVctr2D(Temp, D2, D3, Val);
	for (int i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
}

//! Initializing a Three Dimensional Vector
/*! \param V Three Dimensional Vector To Be Initialized
 *  \param D1 Size of Dimension 1
 *  \param D2 Size of Dimension 2
 *  \param D3 Size of Dimension 3
 *  \param Val The Initializing Value
 *  \author Chibiao Chen
 */
template < typename T > void InitVctr3D(vector< vector< vector< T > > >& V, 
					const int D1, 
     const int D2, 
     const int D3[], 
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr3D" << endl;
		return;
	}

	vector< vector< T > > Temp;
	InitVctr2D(Temp, D2, D3, Val);
	for (int i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
}

//! Initializing a Three Dimensional Vector
/*! \param V Three Dimensional Vector To Be Initialized
 *  \param D1 Size of Dimension 1
 *  \param D2 Size of Dimension 2
 *  \param D3 Size of Dimension 3
 *  \param Val The Initializing Value
 *  \author Chibiao Chen
 */
template < typename T > void InitVctr3D(vector< vector< vector< T > > >& V, 
					const int D1, 
     const int D2, 
     const INT_VCTR_1D& D3, 
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr3D" << endl;
		return;
	}

	vector< vector< T > > Temp;
	InitVctr2D(Temp, D2, D3, Val);
	for (int i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
}

//! Not In Use
/*! \author Chibiao Chen
 */
template < typename T > void InitPtrVctr1D(vector< T* >& V, 
					   const int D1, 
	const int D2[], 
 const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitPtrVctr1D" << endl;
		return;
	}

	int i, j;
	for (i = 0; i < D1; i++)
	{
		V.push_back(reinterpret_cast<T*>(NULL));
	}
	for (i = 0; i < D1; i++)
	{
		V[i] = new T[D2[i]];
	}
	for (i = 0; i < D1; i++)
	{
		for (j = 0; j < D2[i]; j++)
		{
			V[i][j] = Val;
		}
	}
}

//! Not In Use
/*! \author Chibiao Chen
 */
template < typename T > void InitPtrVctr1D(vector< T* >& V, 
					   const int D1, 
	const INT_VCTR_1D& D2, 
 const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitPtrVctr1D" << endl;
		return;
	}

	int i, j;
	for (i = 0; i < D1; i++)
	{
		V.push_back(reinterpret_cast<T*>(NULL));
	}
	for (i = 0; i < D1; i++)
	{
		V[i] = new T[D2[i]];
	}
	for (i = 0; i < D1; i++)
	{
		for (j = 0; j < D2[i]; j++)
		{
			V[i][j] = Val;
		}
	}
}

//! Not In Use
/*! \author Chibiao Chen
 */
template < typename T > void FinaPtrVctr1D(vector< T* >& V, 
					   const int D1)
{
	if (V.size() == 0)
	{
		cerr << "V Not Initialized - FinaPtrVctr1D" << endl;
		return;
	}

	for (int i = 0; i < D1; i++)
	{
		if (V[i])
		{
			delete [] V[i];
			V[i] = NULL;
		}
	}
}

//! Not In Use
/*! \author Chibiao Chen
 */
template < typename T > void InitPtrVctr2D(vector< vector< T* > >& V, 
					   const int D1, 
	const int D2, 
 const int D3[], 
 const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitPtrVctr2D" << endl;
		return;
	}

	int i, j, k;
	vector< T* > Temp(D2, reinterpret_cast<T*>(NULL));
	for (i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
	for (i = 0; i < D1; i++)
	{
		for (j = 0; j < D2; j++)
		{
			V[i][j] = new T[D3[j]];
		}
	}
	for (i = 0; i < D1; i++)
	{
		for (j = 0; j < D2; j++)
		{
			for (k = 0; k < D3[j]; k++)
			{
				V[i][j][k] = Val;
			}
		}
	}
}

//! Not In Use
/*! \author Chibiao Chen
 */
template < typename T > void InitPtrVctr2D(vector< vector< T* > >& V, 
					   const int D1, 
	const int D2, 
 const INT_VCTR_1D& D3, 
 const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitPtrVctr2D" << endl;
		return;
	}

	int i, j, k;
	vector< T* > Temp(D2, reinterpret_cast<T*>(NULL));
	for (i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
	for (i = 0; i < D1; i++)
	{
		for (j = 0; j < D2; j++)
		{
			V[i][j] = new T[D3[j]];
		}
	}
	for (i = 0; i < D1; i++)
	{
		for (j = 0; j < D2; j++)
		{
			for (k = 0; k < D3[j]; k++)
			{
				V[i][j][k] = Val;
			}
		}
	}
}

//! Not In Use
/*! \author Chibiao Chen
 */
template < typename T > void FinaPtrVctr2D(vector< vector< T* > >& V, 
					   const int D1, 
	const int D2)
{
	if (V.size() == 0)
	{
		cerr << "V Not Initialized - FinaPtrVctr2D" << endl;
		return;
	}

	int i, j;
	for (i = 0; i < D1; i++)
	{
		for (j = 0; j < D2; j++)
		{
			if (V[i][j])
			{
				delete [] V[i][j];
				V[i][j] = NULL;
			}
		}
	}
}

template < typename T > void InitVctr4D(vector< vector< vector< vector< T > > > >& V, 
					const int D1, 
     const int D2, 
     const int D3,
     const int D4[],
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr4D" << endl;
		return;
	}

	vector< vector< vector< T > > > Temp;
	InitVctr3D(Temp, D2, D3, D4, Val);
	for (int i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
}

template < typename T > void InitVctr4D(vector< vector< vector< vector< T > > > >& V, 
					const int D1, 
     const int D2, 
     const int D3,
     const int D4,
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr4D" << endl;
		return;
	}

	vector< vector< vector< T > > > Temp;
	InitVctr3D(Temp, D2, D3, D4, Val);
	for (int i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
}

template < typename T > void InitVctr4D(vector< vector< vector< vector< T > > > >& V, 
					const int D1, 
     const int D2, 
     const int D3,
     const INT_VCTR_1D& D4,
     const T& Val)
{
	if (V.size() > 0)
	{
		cerr << "V Already Initialized - InitVctr4D" << endl;
		return;
	}

	vector< vector< vector< T > > > Temp;
	InitVctr3D(Temp, D2, D3, D4, Val);
	for (int i = 0; i < D1; i++)
	{
		V.push_back(Temp);
	}
}


#endif//__VECTROR_UTILITIES__
