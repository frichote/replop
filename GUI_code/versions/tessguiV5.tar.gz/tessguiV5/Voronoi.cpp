#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <chartdir.h>
#include <fstream>
#include <iostream>
#include <set>
#include <vector>

#include "PriorityQueue.h"
#include "FreeNodeList.h"
#include "HalfEdgeList.h"
#include "VoronoiGeometry.h"
#include "Voronoi.h"

using namespace std;

int CVoronoi::m_nIndex;

bool CVoronoi::GetVoronoi(vector< SPoint > vptX, 
						  vector< bool >& vbKeep, 
						  vector< double >& vdDataMinMax, 
						  vector< double >& vdDataScale, 
						  vector< CEdge >& veResult)
{
	if (vptX.size() == 0)
	{
		cerr << "No Voronoi Points - CVoronoi::GetVoronoi" << endl;
		return false;
	}
	if (vptX.size() == 1)
	{
		// Only One Site
		return true;
	}
	if (vbKeep.size() > 0)
	{
		vbKeep.clear();
	}
	if (vdDataMinMax.size() > 0)
	{
		vdDataMinMax.clear();
	}
	if (vdDataScale.size() > 0)
	{
		vdDataScale.clear();
	}
	if (veResult.size() > 0)
	{
		veResult.clear();
	}

	sort(vptX.begin(), vptX.end(), PointLess);

	int nNoS = (int) vptX.size();  // Number of Sites (Original)
	double dXMin = vptX[0].m_psXY.m_dX;
	double dXMax = vptX[0].m_psXY.m_dX;
	int i;
	for (i = 1; i < nNoS; i++)
	{
		if (vptX[i].m_psXY.m_dX < dXMin)
		{
			dXMin = vptX[i].m_psXY.m_dX;
		}
		if (vptX[i].m_psXY.m_dX > dXMax)
		{
			dXMax = vptX[i].m_psXY.m_dX;
		}
	}
	double dYMin = vptX[0].m_psXY.m_dY;
	double dYMax = vptX[nNoS - 1].m_psXY.m_dY;

	vdDataMinMax.push_back(dXMin);
	vdDataMinMax.push_back(dXMax);
	vdDataMinMax.push_back(dYMin);
	vdDataMinMax.push_back(dYMax);

	// Delete duplicate points.
	///////////////////////////////////////////////////////////////////////////////////
	const double dFactor = 0.0000001;
	const double dXE = (dXMax - dXMin) * dFactor;
	const double dYE = (dYMax - dYMin) * dFactor;
	vbKeep.resize(vptX.size(), true);
	vector< bool > vbSortedKeep(vptX.size(), true);
	int j;
	for (i = 0; i < nNoS - 1; i++)
	{
		for (j = i + 1; j < nNoS; j++)
		{
			if (vbSortedKeep[j] && 
				fabs(vptX[i].m_psXY.m_dX - vptX[j].m_psXY.m_dX) < dXE && 
				fabs(vptX[i].m_psXY.m_dY - vptX[j].m_psXY.m_dY) < dYE)
			{
				vbSortedKeep[j] = false;
				vbKeep[vptX[j].m_nIndex] = false;
			}
		}
	}
	vector< SPoint >::iterator iptB = vptX.begin();
	vector< SPoint >::iterator iptE = vptX.end();
	for (i = nNoS; i > -1; i--)
	{
		if (!vbSortedKeep[i])
		{
			iptE = remove(iptB, iptE, vptX[i]);
		}
	}
	vptX.erase(iptE, vptX.end());
	///////////////////////////////////////////////////////////////////////////////////

	nNoS = (int) vptX.size();  // Number of Sites (New)
	int nSqrtNoS = static_cast<int>(sqrt(nNoS + 4.0));
	CHalfEdgeList helThis(dXMin, dXMax, nSqrtNoS * 2);
	CPriorityQueue pqThis(dYMin, dYMax, nSqrtNoS * 4);
	CVoronoiGeometry vgThis(dXMin, dXMax, dYMin, dYMax);

	vdDataScale.push_back(vgThis.GetXMinLmt());
	vdDataScale.push_back(vgThis.GetXMaxLmt());
	vdDataScale.push_back(vgThis.GetYMinLmt());
	vdDataScale.push_back(vgThis.GetYMaxLmt());

	m_nIndex = 0;

	SPoint* pptBotSite = NextSite(vptX);
	SPoint* pptNewSite = NextSite(vptX);

	for(; ;)
	{
		SPosition psNewStar;
		if (!pqThis.Empty())
		{
			psNewStar = pqThis.GetMinPosition();
		}
		if (pptNewSite != PT_NULL && (pqThis.Empty() || pptNewSite->m_psXY.m_dY <
			psNewStar.m_dY || pptNewSite->m_psXY.m_dY == psNewStar.m_dY &&
			pptNewSite->m_psXY.m_dX < psNewStar.m_dX)
		)
		{
			// Site Event
			SHalfEdge* pheLBnd = helThis.GetLftBnd(&pptNewSite->m_psXY);
			SHalfEdge* pheRBnd = helThis.GetRht(pheLBnd);
			SPoint* pptBot = helThis.GetRhtRegPnt(pheLBnd, pptBotSite);
			SEdge* peNew = vgThis.Bisect(pptBot, pptNewSite);
			SHalfEdge* pheBisector = helThis.Create(peNew, LE);
			helThis.Insert(pheLBnd, pheBisector);
			SPoint* pptIS;
			if ((pptIS = vgThis.Intersect(pheLBnd, pheBisector)) != PT_NULL)
			{
				pqThis.Delete(pheLBnd);
				pqThis.Insert(pheLBnd, pptIS, vgThis.Distance(pptIS, pptNewSite));
			}
			pheLBnd = pheBisector;
			pheBisector = helThis.Create(peNew, RE);
			helThis.Insert(pheLBnd, pheBisector);
			if ((pptIS = vgThis.Intersect(pheBisector, pheRBnd)) != PT_NULL)
			{
				pqThis.Insert(pheBisector, pptIS, vgThis.Distance(pptIS, pptNewSite));
			}
			pptNewSite = NextSite(vptX);
		}
		else if (!pqThis.Empty())
		{
			// Circle Event
			SHalfEdge* pheLBnd = pqThis.ExtractMinHalfEdge();
			SHalfEdge* pheLLBnd = helThis.GetLft(pheLBnd);
			SHalfEdge* pheRBnd = helThis.GetRht(pheLBnd);
			SHalfEdge* pheRRBnd = helThis.GetRht(pheRBnd);
			SPoint* pptBot = helThis.GetLftRegPnt(pheLBnd, pptBotSite);
			SPoint* pptTop = helThis.GetRhtRegPnt(pheRBnd, pptBotSite);
			SPoint* pptV = pheLBnd->m_pptVertex;
			vgThis.MakeVertex(pptV);
			bool bBEdge;
			bBEdge = vgThis.EndPoint(pheLBnd->m_peEdge, pheLBnd->m_nSide, pptV);
			if (bBEdge)
			{
				CEdge eNew;
				CopyEdge(pheLBnd->m_peEdge, &eNew);
				veResult.push_back(eNew);
			}
			bBEdge = vgThis.EndPoint(pheRBnd->m_peEdge, pheRBnd->m_nSide, pptV);
			if (bBEdge)
			{
				CEdge eNew;
				CopyEdge(pheRBnd->m_peEdge, &eNew);
				veResult.push_back(eNew);
			}
			helThis.Delete(pheLBnd);
			pqThis.Delete(pheRBnd);
			helThis.Delete(pheRBnd);
			int nSide = LE;
			if (pptBot->m_psXY.m_dY > pptTop->m_psXY.m_dY)
			{
				SPoint* pptTmp = pptBot;
				pptBot = pptTop;
				pptTop = pptTmp;
				nSide = RE;
			}
			SEdge* peNew = vgThis.Bisect(pptBot, pptTop);
			SHalfEdge* pheBisector = helThis.Create(peNew, nSide);
			helThis.Insert(pheLLBnd, pheBisector);
			bBEdge = vgThis.EndPoint(peNew, RE - nSide, pptV);
			if (bBEdge)
			{
				CEdge eNew;
				CopyEdge(peNew, &eNew);
				veResult.push_back(eNew);
			}
			SPoint* pptIS;
			if ((pptIS = vgThis.Intersect(pheLLBnd, pheBisector)) != PT_NULL)
			{
				pqThis.Delete(pheLLBnd);
				pqThis.Insert(pheLLBnd, pptIS, vgThis.Distance(pptIS, pptBot));
			}
			if ((pptIS = vgThis.Intersect(pheBisector, pheRRBnd)) != PT_NULL)
			{
				pqThis.Insert(pheBisector, pptIS, vgThis.Distance(pptIS, pptBot));
			}
		}
		else
		{
			break;
		}
	}
	for (SHalfEdge* pheI = helThis.GetRht(helThis.GetLftEnd());
		pheI != helThis.GetRhtEnd();
		pheI = helThis.GetRht(pheI))
	{
		CEdge eNew;
		CopyEdge(pheI->m_peEdge, &eNew);
		veResult.push_back(eNew);
	}
	if (veResult.size() == 0)
	{
		cerr << "Failed to find any Voronoi edge - CVoronoi::GetVoronoi" << endl;
		return false;
	}

	return true;
}

bool CVoronoi::DrawVoronoi(const vector< SPoint >& vptX, 
						   int N, 
						   const vector< bool >& vbKeep, 
						   const vector< double >& vdDataMinMax, 
						   vector< CEdge >& veResult, 
						   bool bDrawLabel /* = false */, 
						   string strFigName /* = "Voronoi.png" */)
{
	int NT = (int) vptX.size();  // Total Number of Points
	if (NT == 0)
	{
		cerr << "No Voronoi Points - CVoronoi::DrawVoronoi" << endl;
		return false;
	}
	if (NT < N)
	{
		cerr << "Wrong Number of Voronoi Points - CVoronoi::DrawVoronoi" << endl;
		return false;
	}
	if (vbKeep.size() != vptX.size())
	{
		cerr << "Wrong Keep Flags - CVoronoi::DrawVoronoi" << endl;
		return false;
	}
	if (vdDataMinMax.size() != 4)
	{
		cerr << "Wrong Data Min Max - CVoronoi::DrawVoronoi" << endl;
		return false;	
	}
	if (veResult.size() == 0)
	{
		cerr << "No Voronoi Edges - CVoronoi::DrawVoronoi" << endl;
		return false;
	}

	CVoronoiGeometry vgThis(vdDataMinMax[0], vdDataMinMax[1], 
		vdDataMinMax[2], vdDataMinMax[3]);
	double dW = vgThis.GetXMaxLmt() - vgThis.GetXMinLmt();
	double dH = vgThis.GetYMaxLmt() - vgThis.GetYMinLmt();
	int nW;
	int nH;
	int nShortSide = 500;
	if (dW > dH)
	{
		nH = nShortSide;
		nW = int(nH * dW / dH + 0.5);
	}
	else
	{
		nW = nShortSide;
		nH = int(nW * dH / dW + 0.5);
	}
	int nXE = 50;
	int nYE = 50;
	XYChart* c = new XYChart(nW + 2 * nXE, nH + 2 * nYE, 0xFFFFCC, 0, 1);
	c->addTitle("Voronoi Diagram", "timesbi.ttf", 14, 0xFFFFFF)->setBackground(0x804020);
	c->setPlotArea(nXE, nYE, nW, nH, 0xFFFFFF, -1, -1, Transparent, Transparent);
	c->setClipping();
	c->xAxis()->setDateScale(vgThis.GetXMinLmt(), vgThis.GetXMaxLmt());
	c->xAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->xAxis()->setTickDensity(nShortSide / 10);
	c->xAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
	c->yAxis()->setDateScale(vgThis.GetYMinLmt(), vgThis.GetYMaxLmt());
	c->yAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->yAxis()->setTickDensity(nShortSide / 10);
	c->yAxis()->setColors(LineColor, Transparent, Transparent, Transparent);

	// Data Points
	///////////////////////////////////////////////////////////////////////////////////
	vector< double > vdXC;
	vector< double > vdYC;
	vector< double > vdIndex;
	int i;
	for (i = 0; i < N; i++)
	{
		if (vbKeep[i])
		{
			vdXC.push_back(vptX[i].m_psXY.m_dX);
			vdYC.push_back(vptX[i].m_psXY.m_dY);
			// Make sure the first index is 1 not 0.
			vdIndex.push_back(vptX[i].m_nIndex + 1);
		}
	}
	ScatterLayer* pslPoints = c->addScatterLayer(
		DoubleArray(&vdXC[0], N),
		DoubleArray(&vdYC[0], N),
		"Data Points", Chart::CircleSymbol, 5, 0xFF0000, 0x000000);
	if (bDrawLabel)
	{
		pslPoints->addExtraField(DoubleArray(&vdIndex[0], N));
		pslPoints->setDataLabelFormat("{field0}");
		TextBox* ptbLabel = pslPoints->setDataLabelStyle();
		ptbLabel->setBackground(Transparent);
		ptbLabel->setAlignment(Chart::Left);
		ptbLabel->setPos(1, 0);
	}
	///////////////////////////////////////////////////////////////////////////////////

	// Dummy Data Points
	///////////////////////////////////////////////////////////////////////////////////
	if (NT > N)
	{
		vdXC.clear();
		vdYC.clear();
		vdIndex.clear();
		for (i = N; i < NT; i++)
		{
			if (vbKeep[i])
			{
				vdXC.push_back(vptX[i].m_psXY.m_dX);
				vdYC.push_back(vptX[i].m_psXY.m_dY);
				// Make sure the first index is 1 not 0.
				vdIndex.push_back(vptX[i].m_nIndex + 1);
			}
		}
		ScatterLayer* pslDPs = c->addScatterLayer(
			DoubleArray(&vdXC[0], NT - N),
			DoubleArray(&vdYC[0], NT - N),
			"Dummy Points", Chart::CircleSymbol, 5, 0xFFFFFF, 0x000000);
		if (bDrawLabel)
		{
			pslDPs->addExtraField(DoubleArray(&vdIndex[0], NT - N));
			pslDPs->setDataLabelFormat("{field0}");
			TextBox* ptbLabel = pslDPs->setDataLabelStyle();
			ptbLabel->setBackground(Transparent);
			ptbLabel->setAlignment(Chart::Left);
			ptbLabel->setPos(1, 0);
		}
	}
	///////////////////////////////////////////////////////////////////////////////////

	// Edges
	///////////////////////////////////////////////////////////////////////////////////
	SPosition psOne;
	SPosition psTwo;
	double daX[2];
	double daY[2];
	for (i = 0; i < (int) veResult.size(); i++)
	{
		SEdge eThis;
		CopyEdge(&veResult[i], &eThis);
		vgThis.ClipEdge(&eThis, psOne, psTwo);
		daX[0] = psOne.m_dX;
		daY[0] = psOne.m_dY;
		daX[1] = psTwo.m_dX;
		daY[1] = psTwo.m_dY;
		if (daX[0] != INF && daY[0] != INF && daX[1] != INF && daY[1] != INF)
		{
			LineLayer* pll = c->addLineLayer(DoubleArray(daY, 2), 0xC0C0C0);
			pll->setXData(DoubleArray(daX, 2));
		}
	}
	///////////////////////////////////////////////////////////////////////////////////
	c->makeChart(strFigName.c_str());
	delete c;

	return true;
}

bool CVoronoi::GetNeighborhoodSystem(const vector< SPoint >& vptX, 
									 const vector< double >& vdDataMinMax, 
									 int N, 
									 const vector< CEdge >& veVoronoi, 
									 vector< vector< CNeighbor > >& vvnNS, 
									 bool bUseWeight /* = false */)
{
	int NoTP = (int) vptX.size();  // Number of Total Points
	if (NoTP == 0)
	{
		cerr << "No Voronoi Points - CVoronoi::GetNeighborhoodSystem" << endl;
		return false;
	}
	if (N > NoTP)
	{
		cerr << "Wrong Number of Data Points - CVoronoi::GetNeighborhoodSystem" << endl;
		return false;
	}
	int nNoE = (int) veVoronoi.size();
	if (nNoE == 0)
	{
		cerr << "No Voronoi Edges - CVoronoi::GetNeighborhoodSystem" << endl;
		return false;
	}
	int i;
	if (vvnNS.size() != 0)
	{
		for (i = 0; i < (int) vvnNS.size(); i++)
		{
			vvnNS[i].clear();
		}
		vvnNS.clear();
	}
	vector< CNeighbor > vnEmpty;
	for (i = 0; i < N; i++)
	{
		vvnNS.push_back(vnEmpty);
	}
	int j, k;
	if (bUseWeight)
	{
		double dDeltaX = vdDataMinMax[1] - vdDataMinMax[0];
		double dDeltaY = vdDataMinMax[3] - vdDataMinMax[2];
		double dDelta = dDeltaX > dDeltaY ? dDeltaX : dDeltaY;
		for (i = 0; i < N; i++)
		{
			for (j = 0; j < nNoE; j++)
			{
				for (k = 0; k < 2; k++)
				{
					if (veVoronoi[j].m_ptReg[k].m_nIndex == i)
					{
						int nIndex = veVoronoi[j].m_ptReg[1 - k].m_nIndex;
						if (nIndex < N)
						{
							double dDX = vptX[nIndex].m_psXY.m_dX - vptX[i].m_psXY.m_dX;
							double dDY = vptX[nIndex].m_psXY.m_dY - vptX[i].m_psXY.m_dY;
							double dDistance = sqrt(dDX * dDX + dDY * dDY);
							double dWeight;
							if (dDistance < 0.05 * dDelta)
							{
								dWeight = 1.0;
							}
							else if (dDistance > 0.5 * dDelta)
							{
								dWeight = 0.1;
							}
							else
							{
								dWeight = 0.05 * dDelta / dDistance;
							}
							CNeighbor nTmp(nIndex, dWeight);
							vvnNS[i].push_back(nTmp);
						}
					}
				}
			}
		}
	}
	else
	{
		for (i = 0; i < N; i++)
		{
			for (j = 0; j < nNoE; j++)
			{
				for (k = 0; k < 2; k++)
				{
					if (veVoronoi[j].m_ptReg[k].m_nIndex == i)
					{
						int nIndex = veVoronoi[j].m_ptReg[1 - k].m_nIndex;
						if (nIndex < N)
						{
							CNeighbor nTmp(nIndex, 1.0);
							vvnNS[i].push_back(nTmp);
						}
					}
				}
			}
		}
	}

	return true;
}

bool CVoronoi::DrawNeighborhoodSystem(const vector< SPoint >& vptX, 
									  const vector< double >& vdDataScale, 
									  const vector< vector < CNeighbor > >& vvnNS, 
									  bool bDrawLabel /* = true */, 
									  string strFigName /* = "Neighborhood.png" */)
{
	int NoTP = (int) vptX.size();  // Number of Total Points
	if (NoTP == 0)
	{
		cerr << "No Voronoi Points - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}
	if (vdDataScale.size() != 4)
	{
		cerr << "Wrong Data Scale - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}
	int NoP = (int) vvnNS.size();  // Number of Data Points
	if (NoP > NoTP)
	{
		cerr << "Wrong Neighborhood System - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}

	double dW = vdDataScale[1] - vdDataScale[0];
	double dH = vdDataScale[3] - vdDataScale[2];
	int nW;
	int nH;
	int nShortSide = 500;
	if (dW > dH)
	{
		nH = nShortSide;
		nW = int(nH * dW / dH + 0.5);
	}
	else
	{
		nW = nShortSide;
		nH = int(nW * dH / dW + 0.5);
	}
	int nXE = 50;
	int nYE = 50;
	XYChart* c = new XYChart(nW + 2 * nXE, nH + 2 * nYE, 0xFFFFCC, 0, 1);
	c->addTitle("Neighborhood Diagram", "timesbi.ttf", 14, 0xFFFFFF
		)->setBackground(0x804020);
	c->setPlotArea(nXE, nYE, nW, nH, 0xFFFFFF, -1, -1, Transparent, Transparent);
	c->setClipping();
	c->xAxis()->setDateScale(vdDataScale[0], vdDataScale[1]);
	c->xAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->xAxis()->setTickDensity(nShortSide / 10);
	c->xAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
	c->yAxis()->setDateScale(vdDataScale[2], vdDataScale[3]);
	c->yAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->yAxis()->setTickDensity(nShortSide / 10);
	c->yAxis()->setColors(LineColor, Transparent, Transparent, Transparent);

	// Data Points
	///////////////////////////////////////////////////////////////////////////////////
	vector< double > vdXC;
	vector< double > vdYC;
	vector< double > vdIndex;
	int i;
	for (i = 0; i < NoP; i++)
	{
		vdXC.push_back(vptX[i].m_psXY.m_dX);
		vdYC.push_back(vptX[i].m_psXY.m_dY);
		// Make sure the first index is 1 not 0.
		vdIndex.push_back(vptX[i].m_nIndex + 1);
	}
	ScatterLayer* pslPoints = c->addScatterLayer(
		DoubleArray(&vdXC[0], (int) vdXC.size()),
		DoubleArray(&vdYC[0], (int) vdYC.size()),
		"Data Points", Chart::CircleSymbol, 5, 0xFF0000, 0x000000);
	if (bDrawLabel)
	{
		pslPoints->addExtraField(DoubleArray(&vdIndex[0], (int) vdIndex.size()));
		pslPoints->setDataLabelFormat("{field0}");
		TextBox* ptbLabel = pslPoints->setDataLabelStyle();
		ptbLabel->setBackground(Transparent);
		ptbLabel->setAlignment(Chart::Left);
		ptbLabel->setPos(1, 0);
	}
	///////////////////////////////////////////////////////////////////////////////////

	// Links
	///////////////////////////////////////////////////////////////////////////////////
	double daX[2];
	double daY[2];
	int j;
	for (i = 0; i < NoP; i++)
	{
		for (j = 0; j < (int) vvnNS[i].size(); j++)
		{
			daX[0] = vptX[i].m_psXY.m_dX;
			daY[0] = vptX[i].m_psXY.m_dY;
			daX[1] = vptX[vvnNS[i][j].m_nIndex].m_psXY.m_dX;
			daY[1] = vptX[vvnNS[i][j].m_nIndex].m_psXY.m_dY;
			LineLayer* pll = c->addLineLayer(DoubleArray(daY, 2), 0xC0C0C0);
			pll->setXData(DoubleArray(daX, 2));
		}
	}
	///////////////////////////////////////////////////////////////////////////////////
	c->makeChart(strFigName.c_str());
	delete c;

	return true;
}

bool CVoronoi::DrawNeighborhoodSystem(int nPtIndex, 
									  const vector< SPoint >& vptX, 
									  const vector< vector < CNeighbor > >& vvnNS, 
									  bool bDrawLabel /* = true */, 
									  string strFigName /* = "Neighborhood.png" */)
{
	int NoTP = (int) vptX.size();  // Number of Total Points
	if (NoTP == 0)
	{
		cerr << "No Voronoi Points - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}
	int NoP = (int) vvnNS.size();  // Number of Data Points
	if (NoP > NoTP)
	{
		cerr << "Wrong Neighborhood System - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}
	if (nPtIndex < 0 || nPtIndex > NoP - 1)
	{
		cerr << "Invalid Point Index - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}

	double dXMin = vptX[nPtIndex].m_psXY.m_dX;
	double dXMax = vptX[nPtIndex].m_psXY.m_dX;
	double dYMin = vptX[nPtIndex].m_psXY.m_dY;
	double dYMax = vptX[nPtIndex].m_psXY.m_dY;
	vector< double > vdXC;
	vector< double > vdYC;
	vector< double > vdIndex;
	int i;
	for (i = 0; i < (int) vvnNS[nPtIndex].size(); i++)
	{
		if (dXMin > vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dX)
		{
			dXMin = vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dX;
		}
		if (dXMax < vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dX)
		{
			dXMax = vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dX;
		}
		if (dYMin > vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dY)
		{
			dYMin = vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dY;
		}
		if (dYMax < vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dY)
		{
			dYMax = vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dY;
		}
		vdXC.push_back(vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dX);
		vdYC.push_back(vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dY);
		// Make sure the first index is 1 not 0.
		vdIndex.push_back(vptX[vvnNS[nPtIndex][i].m_nIndex].m_nIndex + 1);
	}
	double dDeltaX = dXMax - dXMin;
	double dDeltaY = dYMax - dYMin;
	double dW = dDeltaX * 1.2;
	double dH = dDeltaY * 1.2;
	int nW;
	int nH;
	int nShortSide = 200;
	if (dW > dH)
	{
		nH = nShortSide;
		nW = int(nH * dW / dH + 0.5);
	}
	else
	{
		nW = nShortSide;
		nH = int(nW * dH / dW + 0.5);
	}
	int nXE = 50;
	int nYE = 50;
	XYChart* c = new XYChart(nW + 2 * nXE, nH + 2 * nYE, 0xFFFFCC, 0, 1);
	c->addTitle("Neighborhood Diagram of Single Point", "timesbi.ttf", 14, 0xFFFFFF
		)->setBackground(0x804020);
	c->setPlotArea(nXE, nYE, nW, nH, 0xFFFFFF, -1, -1, Transparent, Transparent);
	c->setClipping();
	c->xAxis()->setDateScale(dXMin - dDeltaX * 0.1, dXMax + dDeltaX * 0.1);
	c->xAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->xAxis()->setTickDensity(nShortSide / 10);
	c->xAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
	c->yAxis()->setDateScale(dYMin - dDeltaY * 0.1, dYMax + dDeltaY * 0.1);
	c->yAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->yAxis()->setTickDensity(nShortSide / 10);
	c->yAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
	ScatterLayer* pslPoint = c->addScatterLayer(
		DoubleArray(&vptX[nPtIndex].m_psXY.m_dX, 1),
		DoubleArray(&vptX[nPtIndex].m_psXY.m_dY, 1),
		"The Point", Chart::CircleSymbol, 7, 0xFF0000, 0x000000);
	ScatterLayer* pslNeighbors = c->addScatterLayer(
		DoubleArray(&vdXC[0], (int) vdXC.size()),
		DoubleArray(&vdYC[0], (int) vdYC.size()),
		"Neighbors", Chart::CircleSymbol, 5, 0xFF0000, 0x000000);
	if (bDrawLabel)
	{
		// Make sure the first index is 1 not 0.
		double dPtIndex = nPtIndex + 1;
		pslPoint->addExtraField(DoubleArray(&dPtIndex, 1));
		pslPoint->setDataLabelFormat("{field0}");
		TextBox* ptbPLabel = pslPoint->setDataLabelStyle();
		ptbPLabel->setBackground(Transparent);
		ptbPLabel->setAlignment(Chart::Left);
		ptbPLabel->setPos(1, 0);

		pslNeighbors->addExtraField(DoubleArray(&vdIndex[0], (int) vdIndex.size()));
		pslNeighbors->setDataLabelFormat("{field0}");
		TextBox* ptbNLabel = pslNeighbors->setDataLabelStyle();
		ptbNLabel->setBackground(Transparent);
		ptbNLabel->setAlignment(Chart::Left);
		ptbNLabel->setPos(1, 0);
	}

	double daX[2];
	double daY[2];
	daX[0] = vptX[nPtIndex].m_psXY.m_dX;
	daY[0] = vptX[nPtIndex].m_psXY.m_dY;
	for (i = 0; i < (int) vvnNS[nPtIndex].size(); i++)
	{
		daX[1] = vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dX;
		daY[1] = vptX[vvnNS[nPtIndex][i].m_nIndex].m_psXY.m_dY;
		LineLayer* pll = c->addLineLayer(DoubleArray(daY, 2), 0xC0C0C0);
		pll->setXData(DoubleArray(daX, 2));
	}
	c->makeChart(strFigName.c_str());
	delete c;

	return true;
}

bool CVoronoi::GetNeighborhoodSystem(int nNoP, 
									 const vector< CEdge >& veVoronoi, 
									 vector< vector< int > >& vvnNS)
{
	int nNoE = (int) veVoronoi.size();
	if (nNoE == 0)
	{
		cerr << "No Voronoi Edges - CVoronoi::GetNeighborhoodSystem";
		return false;
	}
	int i;
	if (vvnNS.size() != 0)
	{
		for (i = 0; i < (int) vvnNS.size(); i++)
		{
			vvnNS[i].clear();
		}
		vvnNS.clear();
	}
	vector< int > vnEmpty;
	for (i = 0; i < nNoP; i++)
	{
		vvnNS.push_back(vnEmpty);
	}
	int j, k;
	for (i = 0; i < nNoP; i++)
	{
		for (j = 0; j < nNoE; j++)
		{
			for (k = 0; k < 2; k++)
			{
				if (veVoronoi[j].m_ptReg[k].m_nIndex == i)
				{
					int nNeighbor = veVoronoi[j].m_ptReg[1 - k].m_nIndex;
					if (nNeighbor < nNoP)
					{
						vvnNS[i].push_back(nNeighbor);
					}
				}
			}
		}
	}

	return true;
}

bool CVoronoi::DrawNeighborhoodSystem(const vector< SPoint >& vptX, 
									  const vector< double >& vdDataScale, 
									  const vector< vector < int > >& vvnNS, 
									  bool bDrawLabel /* = true */, 
									  string strFigName /* = "Neighborhood.png" */)
{
	int NoTP = (int) vptX.size();  // Number of Total Points
	if (NoTP == 0)
	{
		cerr << "No Voronoi Points - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}
	if (vdDataScale.size() != 4)
	{
		cerr << "Wrong Data Scale - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}
	int NoP = (int) vvnNS.size();  // Number of Data Points
	if (NoP > NoTP)
	{
		cerr << "Wrong Neighborhood System - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}

	double dW = vdDataScale[1] - vdDataScale[0];
	double dH = vdDataScale[3] - vdDataScale[2];
	int nW;
	int nH;
	int nShortSide = 500;
	if (dW > dH)
	{
		nH = nShortSide;
		nW = int(nH * dW / dH + 0.5);
	}
	else
	{
		nW = nShortSide;
		nH = int(nW * dH / dW + 0.5);
	}
	int nXE = 50;
	int nYE = 50;
	XYChart* c = new XYChart(nW + 2 * nXE, nH + 2 * nYE, 0xFFFFCC, 0, 1);
	c->addTitle("Neighborhood Diagram", "timesbi.ttf", 14, 0xFFFFFF
		)->setBackground(0x804020);
	c->setPlotArea(nXE, nYE, nW, nH, 0xFFFFFF, -1, -1, Transparent, Transparent);
	c->setClipping();
	c->xAxis()->setDateScale(vdDataScale[0], vdDataScale[1]);
	c->xAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->xAxis()->setTickDensity(nShortSide / 10);
	c->xAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
	c->yAxis()->setDateScale(vdDataScale[2], vdDataScale[3]);
	c->yAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->yAxis()->setTickDensity(nShortSide / 10);
	c->yAxis()->setColors(LineColor, Transparent, Transparent, Transparent);

	// Data Points
	///////////////////////////////////////////////////////////////////////////////////
	vector< double > vdXC;
	vector< double > vdYC;
	vector< double > vdIndex;
	int i;
	for (i = 0; i < NoP; i++)
	{
		vdXC.push_back(vptX[i].m_psXY.m_dX);
		vdYC.push_back(vptX[i].m_psXY.m_dY);
		// Make sure the first index is 1 not 0.
		vdIndex.push_back(vptX[i].m_nIndex + 1);
	}
	ScatterLayer* pslPoints = c->addScatterLayer(
		DoubleArray(&vdXC[0], (int) vdXC.size()),
		DoubleArray(&vdYC[0], (int) vdYC.size()),
		"Data Points", Chart::CircleSymbol, 5, 0xFF0000, 0x000000);
	if (bDrawLabel)
	{
		pslPoints->addExtraField(DoubleArray(&vdIndex[0], (int) vdIndex.size()));
		pslPoints->setDataLabelFormat("{field0}");
		TextBox* ptbLabel = pslPoints->setDataLabelStyle();
		ptbLabel->setBackground(Transparent);
		ptbLabel->setAlignment(Chart::Left);
		ptbLabel->setPos(1, 0);
	}
	///////////////////////////////////////////////////////////////////////////////////

	// Links
	///////////////////////////////////////////////////////////////////////////////////
	double daX[2];
	double daY[2];
	int j;
	for (i = 0; i < NoP; i++)
	{
		for (j = 0; j < (int) vvnNS[i].size(); j++)
		{
			daX[0] = vptX[i].m_psXY.m_dX;
			daY[0] = vptX[i].m_psXY.m_dY;
			daX[1] = vptX[vvnNS[i][j]].m_psXY.m_dX;
			daY[1] = vptX[vvnNS[i][j]].m_psXY.m_dY;
			LineLayer* pll = c->addLineLayer(DoubleArray(daY, 2), 0xC0C0C0);
			pll->setXData(DoubleArray(daX, 2));
		}
	}
	///////////////////////////////////////////////////////////////////////////////////
	c->makeChart(strFigName.c_str());
	delete c;

	return true;
}

bool CVoronoi::DrawNeighborhoodSystem(int nPtIndex, 
									  const vector< SPoint >& vptX, 
									  const vector< vector < int > >& vvnNS, 
									  bool bDrawLabel /* = true */, 
									  string strFigName /* = "Neighborhood.png" */)
{
	int NoTP = (int) vptX.size();  // Number of Total Points
	if (NoTP == 0)
	{
		cerr << "No Voronoi Points - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}
	int NoP = (int) vvnNS.size();  // Number of Data Points
	if (NoP > NoTP)
	{
		cerr << "Wrong Neighborhood System - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}
	if (nPtIndex < 0 || nPtIndex > NoP - 1)
	{
		cerr << "Invalid Point Index - CVoronoi::DrawNeighborhoodSystem" << endl;
		return false;
	}

	double dXMin = vptX[nPtIndex].m_psXY.m_dX;
	double dXMax = vptX[nPtIndex].m_psXY.m_dX;
	double dYMin = vptX[nPtIndex].m_psXY.m_dY;
	double dYMax = vptX[nPtIndex].m_psXY.m_dY;
	vector< double > vdXC;
	vector< double > vdYC;
	vector< double > vdIndex;
	int i;
	for (i = 0; i < (int) vvnNS[nPtIndex].size(); i++)
	{
		if (dXMin > vptX[vvnNS[nPtIndex][i]].m_psXY.m_dX)
		{
			dXMin = vptX[vvnNS[nPtIndex][i]].m_psXY.m_dX;
		}
		if (dXMax < vptX[vvnNS[nPtIndex][i]].m_psXY.m_dX)
		{
			dXMax = vptX[vvnNS[nPtIndex][i]].m_psXY.m_dX;
		}
		if (dYMin > vptX[vvnNS[nPtIndex][i]].m_psXY.m_dY)
		{
			dYMin = vptX[vvnNS[nPtIndex][i]].m_psXY.m_dY;
		}
		if (dYMax < vptX[vvnNS[nPtIndex][i]].m_psXY.m_dY)
		{
			dYMax = vptX[vvnNS[nPtIndex][i]].m_psXY.m_dY;
		}
		vdXC.push_back(vptX[vvnNS[nPtIndex][i]].m_psXY.m_dX);
		vdYC.push_back(vptX[vvnNS[nPtIndex][i]].m_psXY.m_dY);
		// Make sure the first index is 1 not 0.
		vdIndex.push_back(vptX[vvnNS[nPtIndex][i]].m_nIndex + 1);
	}
	double dDeltaX = dXMax - dXMin;
	double dDeltaY = dYMax - dYMin;
	double dW = dDeltaX * 1.2;
	double dH = dDeltaY * 1.2;
	int nW;
	int nH;
	int nShortSide = 200;
	if (dW > dH)
	{
		nH = nShortSide;
		nW = int(nH * dW / dH + 0.5);
	}
	else
	{
		nW = nShortSide;
		nH = int(nW * dH / dW + 0.5);
	}
	int nXE = 50;
	int nYE = 50;
	XYChart* c = new XYChart(nW + 2 * nXE, nH + 2 * nYE, 0xFFFFCC, 0, 1);
	c->addTitle("Neighborhood Diagram of Single Point", "timesbi.ttf", 14, 0xFFFFFF
		)->setBackground(0x804020);
	c->setPlotArea(nXE, nYE, nW, nH, 0xFFFFFF, -1, -1, Transparent, Transparent);
	c->setClipping();
	c->xAxis()->setDateScale(dXMin - dDeltaX * 0.1, dXMax + dDeltaX * 0.1);
	c->xAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->xAxis()->setTickDensity(nShortSide / 10);
	c->xAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
	c->yAxis()->setDateScale(dYMin - dDeltaY * 0.1, dYMax + dDeltaY * 0.1);
	c->yAxis()->setAutoScale(0.0, 0.0, 0.0);
	c->yAxis()->setTickDensity(nShortSide / 10);
	c->yAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
	ScatterLayer* pslPoint = c->addScatterLayer(
		DoubleArray(&vptX[nPtIndex].m_psXY.m_dX, 1),
		DoubleArray(&vptX[nPtIndex].m_psXY.m_dY, 1),
		"The Point", Chart::CircleSymbol, 7, 0xFF0000, 0x000000);
	ScatterLayer* pslNeighbors = c->addScatterLayer(
		DoubleArray(&vdXC[0], (int) vdXC.size()),
		DoubleArray(&vdYC[0], (int) vdYC.size()),
		"Neighbors", Chart::CircleSymbol, 5, 0xFF0000, 0x000000);
	if (bDrawLabel)
	{
		// Make sure the first index is 1 not 0.
		double dPtIndex = nPtIndex + 1;
		pslPoint->addExtraField(DoubleArray(&dPtIndex, 1));
		pslPoint->setDataLabelFormat("{field0}");
		TextBox* ptbPLabel = pslPoint->setDataLabelStyle();
		ptbPLabel->setBackground(Transparent);
		ptbPLabel->setAlignment(Chart::Left);
		ptbPLabel->setPos(1, 0);

		pslNeighbors->addExtraField(DoubleArray(&vdIndex[0], (int) vdIndex.size()));
		pslNeighbors->setDataLabelFormat("{field0}");
		TextBox* ptbNLabel = pslNeighbors->setDataLabelStyle();
		ptbNLabel->setBackground(Transparent);
		ptbNLabel->setAlignment(Chart::Left);
		ptbNLabel->setPos(1, 0);
	}

	double daX[2];
	double daY[2];
	daX[0] = vptX[nPtIndex].m_psXY.m_dX;
	daY[0] = vptX[nPtIndex].m_psXY.m_dY;
	for (i = 0; i < (int) vvnNS[nPtIndex].size(); i++)
	{
		daX[1] = vptX[vvnNS[nPtIndex][i]].m_psXY.m_dX;
		daY[1] = vptX[vvnNS[nPtIndex][i]].m_psXY.m_dY;
		LineLayer* pll = c->addLineLayer(DoubleArray(daY, 2), 0xC0C0C0);
		pll->setXData(DoubleArray(daX, 2));
	}
	c->makeChart(strFigName.c_str());
	delete c;

	return true;
}

bool CVoronoi::SaveVoronoi(const vector< SPoint >& vptX, 
						   const vector< bool >& vbKeep, 
						   const vector< double >& vdDataMinMax, 
						   const vector< double >& vdDataScale, 
						   const vector< CEdge >& veVoronoi, 
						   const vector< vector < int > >& vvnNS, 
						   const string& File)
{
	if (vptX.size() == 0)
	{
		cerr << "No Voronoi Points - CVoronoi::SaveVoronoi" << endl;
		return false;
	}
	if (vbKeep.size() == 0)
	{
		cerr << "No Keep Flags - CVoronoi::SaveVoronoi" << endl;
		return false;
	}
	if (vdDataMinMax.size() != 4)
	{
		cerr << "Wrong Data Min Max - CVoronoi::SaveVoronoi" << endl;
		return false;	
	}
	if (vdDataScale.size() != 4)
	{
		cerr << "Wrong Data Scale - CVoronoi::SaveVoronoi" << endl;
		return false;
	}
	if (veVoronoi.size() == 0)
	{
		cerr << "No Voronoi Edges - CVoronoi::SaveVoronoi" << endl;
		return false;
	}
	if (vvnNS.size() == 0)
	{
		cerr << "No Voronoi Neighborhood System - CVoronoi::SaveVoronoi" << endl;
		return false;
	}

	ofstream ofs(File.c_str());
	if (!ofs.good())
	{
		cerr << "Cannot open file " << File << " - CVoronoi::SaveVoronoi" << endl;
		return false;
	}

	ofs << VV << ' ';

	int N = static_cast<int>(vptX.size());  // Number of Total Points
	ofs << N << ' ';
	int i;
	for (i = 0; i < N; i++)
	{
		ofs << vptX[i] << ' ';
	}
	for (i = 0; i < N; i++)
	{
		ofs << vbKeep[i] << ' ';
	}

	for (i = 0; i < 4; i++)
	{
		ofs << vdDataMinMax[i] << ' ';
	}

	for (i = 0; i < 4; i++)
	{
		ofs << vdDataScale[i] << ' ';
	}

	int M = static_cast<int>(veVoronoi.size());
	ofs << M << ' ';
	for (i = 0; i < M; i++)
	{
		ofs << veVoronoi[i] << ' ';
	}

	N = static_cast<int>(vvnNS.size());  // Number of Data Points
	ofs << N << ' ';
	int j;
	for (i = 0; i < N; i++)
	{
		int J = static_cast<int>(vvnNS[i].size()); 
		ofs << J << ' ';
		for (j = 0; j < J; j++)
		{
			ofs << vvnNS[i][j] << ' ';
		}
	}

	ofs.close();

	return true;
}

bool CVoronoi::LoadVoronoi(vector< SPoint >& vptX, 
						   vector< bool >& vbKeep, 
						   vector< double >& vdDataMinMax, 
						   vector< double >& vdDataScale, 
						   vector< CEdge >& veVoronoi, 
						   vector< vector < int > >& vvnNS, 
						   const string& File)
{
	if (vptX.size() > 0)
	{
		vptX.clear();
	}
	if (vbKeep.size() > 0)
	{
		vbKeep.clear();
	}
	if (vdDataMinMax.size() > 0)
	{
		vdDataMinMax.clear();	
	}
	if (vdDataScale.size() > 0)
	{
		vdDataScale.clear();
	}
	if (veVoronoi.size() > 0)
	{
		veVoronoi.clear();
	}
	int i;
	if (vvnNS.size() > 0)
	{
		for (i = 0; i < static_cast<int>(vvnNS.size()); i++)
		{
			vvnNS[i].clear();
		}
		vvnNS.clear();
	}

	ifstream ifs(File.c_str());
	if (!ifs.good())
	{
		cerr << "Cannot open file " << File << " - CVoronoi::LoadVoronoi" << endl;
		return false;
	}

	string strVV;
	ifs >> strVV;
	if (strVV != string(VV))
	{
		cerr << "Unknown or Old Version Voronoi File - CVoronoi::LoadVoronoi" << endl;
		return false;
	}

	int N;
	ifs >> N;  // Number of Total Points
	SPoint ptThis;
	for (i = 0; i < N; i++)
	{
		ifs >> ptThis;
		vptX.push_back(ptThis);
	}
	bool bThis;
	for (i = 0; i < N; i++)
	{
		ifs >> bThis;
		vbKeep.push_back(bThis);
	}

	double d;
	for (i = 0; i < 4; i++)
	{
		ifs >> d;
		vdDataMinMax.push_back(d);
	}

	for (i = 0; i < 4; i++)
	{
		ifs >> d;
		vdDataScale.push_back(d);
	}

	int M;
	ifs >> M;
	CEdge eThis;
	for (i = 0; i < M; i++)
	{
		ifs >> eThis;
		veVoronoi.push_back(eThis);
	}

	ifs >> N;  // Number of Data Points
	vector < int > vnEmpty;
	int j;
	for (i = 0; i < N; i++)
	{
		vvnNS.push_back(vnEmpty);
		int J;
		ifs >> J;
		for (j = 0; j < J; j++)
		{
			int n;
			ifs >> n;
			vvnNS[i].push_back(n);
		}
	}

	ifs.close();

	return true;
}

bool CVoronoi::CopyEdge(SEdge* peSrc, CEdge* peDst)
{
	if (!peSrc || !peDst)
	{
		return false;
	}
	peDst->m_dA = peSrc->m_dA;
	peDst->m_dB = peSrc->m_dB;
	peDst->m_dC = peSrc->m_dC;
	for (int i = 0; i < 2; i++)
	{
		if (peSrc->m_pptEnd[i])
		{
			peDst->m_ptEnd[i] = *peSrc->m_pptEnd[i];
		}
		else
		{
			peDst->m_ptEnd[i].m_psXY.m_dX = INF;
			peDst->m_ptEnd[i].m_psXY.m_dY = INF;
			peDst->m_ptEnd[i].m_nIndex = 0;
		}
		if (peSrc->m_pptReg[i])
		{
			peDst->m_ptReg[i] = *peSrc->m_pptReg[i];
		}
		else
		{
			peDst->m_ptReg[i].m_psXY.m_dX = INF;
			peDst->m_ptReg[i].m_psXY.m_dY = INF;
			peDst->m_ptReg[i].m_nIndex = 0;
		}
	}
	peDst->m_nIndex = peSrc->m_nIndex;

	return true;
}

bool CVoronoi::CopyEdge(CEdge* peSrc, SEdge* peDst)
{
	if (!peSrc || !peDst)
	{
		return false;
	}
	peDst->m_dA = peSrc->m_dA;
	peDst->m_dB = peSrc->m_dB;
	peDst->m_dC = peSrc->m_dC;
	for (int i = 0; i < 2; i++)
	{
		peDst->m_pptEnd[i] = &peSrc->m_ptEnd[i];
		if (peSrc->m_ptEnd[i].m_psXY.m_dX == INF || peSrc->m_ptEnd[i].m_psXY.m_dY == INF)
		{
			peDst->m_pptEnd[i] = PT_NULL;
		}
		peDst->m_pptReg[i] = &peSrc->m_ptReg[i];
		if (peSrc->m_ptReg[i].m_psXY.m_dX == INF || peSrc->m_ptReg[i].m_psXY.m_dY == INF)
		{
			peDst->m_pptReg[i] = PT_NULL;
		}
	}
	peDst->m_nIndex = peSrc->m_nIndex;

	return true;
}

bool CVoronoi::PointLess(const SPoint& ptA, const SPoint& ptB)
{
	return ptA.m_psXY.m_dY < ptB.m_psXY.m_dY ||
		ptA.m_psXY.m_dY == ptB.m_psXY.m_dY && ptA.m_psXY.m_dX < ptB.m_psXY.m_dX;
}

SPoint* CVoronoi::NextSite(vector< SPoint >& vptX)
{
	if (m_nIndex < (int) vptX.size())
	{
		return &vptX[m_nIndex++];
	}
	else
	{
		return PT_NULL;
	}
}
