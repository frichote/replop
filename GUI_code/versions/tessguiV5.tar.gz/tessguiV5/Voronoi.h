#ifndef __VORONOI__
#define __VORONOI__

/*! \file Voronoi.h
 *  \brief Fortune's Plane Sweep Algorithm for Voronoi Diagram Generation
 *
 *  Some utility routines for neighborhood generation and others have also been added.
 */

#include <vector>
#include <string>

#include "FortuneStructures.h"

using namespace std;

//! Version Control for Saving and Loading Voronoi Related Information
#define VV "Voronoi-1.0"  // Voronoi Version

//! Voronoi Diagram Based Neighbor
class CNeighbor
{
public:
	//! Constructor
	/*! \author Chibiao Chen
	 */
	CNeighbor(int nIndex = 0, double dWeight = 0.0) : m_nIndex(nIndex), m_dWeight(dWeight)
	{
	}
	int	m_nIndex;		//!< Index of the Neighbor
	double m_dWeight;	//!< Weight of the Neighbor
};

class CVoronoi
{
public:
	//! Getting the Voronoi Edges Using Fortune's Plane Sweep Algorithm
	/*! To understand the implementation, refer to the book 
	 *  "Computational Geometry: Algorithms and Applications" (Chapter 7).
	 *  \param vptX The Data Points (Coordinates)
	 *  \param vbKeep Individuals Kept for Drawing (Output)
	 *  \param vdDataMinMax Limits of X, Y Data (Output)
	 *  \param vdDataScale Scales of X, Y Data (Output)
	 *  \param veResult The Generated Voronoi Edges (Output)
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool GetVoronoi(vector< SPoint > vptX, 
						   vector< bool >& vbKeep, 
						   vector< double >& vdDataMinMax, 
						   vector< double >& vdDataScale, 
						   vector< CEdge >& veResult);

	//! Drawing the Voronoi Diagram
	/*! \param vptX The Data Points (Coordinates)
	 *  \param N Number of Data Points (Individuals)
	 *  \param vbKeep Individuals Kept for Drawing
	 *  \param vdDataMinMax Limits of X, Y Data
	 *  \param veResult The Generated Voronoi Edges
	 *  \param bDrawLabel Drawing Labels for Data Points?
	 *  \param strFigName The Output Chart File Name
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool DrawVoronoi(const vector< SPoint >& vptX, 
							int N, 
							const vector< bool >& vbKeep, 
							const vector< double >& vdDataMinMax, 
							vector< CEdge >& veResult, 
							bool bDrawLabel = false, 
							string strFigName = "Voronoi.png");

	//! Getting the Neighborhood System from the Voronoi Edges
	/*! \param vptX The Data Points (Coordinates)
	 *  \param vdDataMinMax Limits of X, Y Data
	 *  \param N Number of Data Points (Individuals)
	 *  \param veVoronoi The Voronoi Edges
	 *  \param vvnNS The Generated Neighborhood System (Output)
	 *  \param bUseWeight Using Weight for Neighbors?
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool GetNeighborhoodSystem(const vector< SPoint >& vptX, 
									  const vector< double >& vdDataMinMax, 
									  int N, 
									  const vector< CEdge >& veVoronoi, 
									  vector< vector< CNeighbor > >& vvnNS, 
									  bool bUseWeight = false);

	//! Drawing the Whole Neighborhood System
	/*! \param vptX The Data Points (Coordinates)
	 *  \param vdDataScale Scales of X, Y Data
	 *  \param vvnNS The Neighborhood System
	 *  \param bDrawLabel Drawing Individual Labels?
	 *  \param strFigName The Output Chart File Name
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool DrawNeighborhoodSystem(const vector< SPoint >& vptX, 
									   const vector< double >& vdDataScale, 
									   const vector< vector < CNeighbor > >& vvnNS, 
									   bool bDrawLabel = true, 
									   string strFigName = "Neighborhood.png");

	//! Drawing the Neighborhood System of a Given Site
	/*! \param nPtIndex Index of the Given Site
	 *  \param vptX The Data Points (Coordinates)
	 *  \param vvnNS The Neighborhood System
	 *  \param bDrawLabel Drawing Individual Labels?
	 *  \param strFigName The Output Chart File Name
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool DrawNeighborhoodSystem(int nPtIndex, 
									   const vector< SPoint >& vptX, 
									   const vector< vector < CNeighbor > >& vvnNS, 
									   bool bDrawLabel = true, 
									   string strFigName = "Neighborhood.png");

	//! Getting the Neighborhood System from the Voronoi Edges
	/*! \param NoP Number of Data Points (Individuals)
	 *  \param veVoronoi The Voronoi Edges
	 *  \param vvnNS The Generated Neighborhood System (Output)
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool GetNeighborhoodSystem(int nNoP, 
									  const vector< CEdge >& veVoronoi, 
									  vector< vector< int > >& vvnNS);

	//! Drawing the Whole Neighborhood System
	/*! \param vptX The Data Points (Coordinates)
	 *  \param vdDataScale Scales of X, Y Data
	 *  \param vvnNS The Neighborhood System
	 *  \param bDrawLabel Drawing Individual Labels?
	 *  \param strFigName The Output Chart File Name
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool DrawNeighborhoodSystem(const vector< SPoint >& vptX, 
									   const vector< double >& vdDataScale, 
									   const vector< vector < int > >& vvnNS, 
									   bool bDrawLabel = true, 
									   string strFigName = "Neighborhood.png");

	//! Drawing the Neighborhood System of a Given Site
	/*! \param nPtIndex Index of the Given Site
	 *  \param vptX The Data Points (Coordinates)
	 *  \param vvnNS The Neighborhood System
	 *  \param bDrawLabel Drawing Individual Labels?
	 *  \param strFigName The Output Chart File Name
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool DrawNeighborhoodSystem(int nPtIndex, 
									   const vector< SPoint >& vptX, 
									   const vector< vector < int > >& vvnNS, 
									   bool bDrawLabel = true, 
									   string strFigName = "Neighborhood.png");

	//! Saving Voronoi Related Information
	/*! \param vptX The Data Points (Coordinates)
	 *  \param vbKeep Individuals Kept for Drawing
	 *  \param vdDataMinMax Limits of X, Y Data
	 *  \param vdDataScale Scales of X, Y Data
	 *  \param veVoronoi The Voronoi Edges
	 *  \param vvnNS The Neighborhood System
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool SaveVoronoi(const vector< SPoint >& vptX, 
							const vector< bool >& vbKeep, 
							const vector< double >& vdDataMinMax, 
							const vector< double >& vdDataScale, 
							const vector< CEdge >& veVoronoi, 
							const vector< vector < int > >& vvnNS, 
							const string& File);

	//! Loading Voronoi Related Information
	/*! \param vptX The Data Points (Coordinates) (Output)
	 *  \param vbKeep Individuals Kept for Drawing (Output)
	 *  \param vdDataMinMax Limits of X, Y Data (Output)
	 *  \param vdDataScale Scales of X, Y Data (Output)
	 *  \param veVoronoi The Voronoi Edges (Output)
	 *  \param vvnNS The Neighborhood System (Output)
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool LoadVoronoi(vector< SPoint >& vptX, 
							vector< bool >& vbKeep, 
							vector< double >& vdDataMinMax, 
							vector< double >& vdDataScale, 
							vector< CEdge >& veVoronoi, 
							vector< vector < int > >& vvnNS, 
							const string& File);

	//! Copying a SEdge Object to a CEdge Object
	/*! \param peSrc The SEdge Object
	 *  \param peDst The CEdge Object
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool CopyEdge(SEdge* peSrc, CEdge* peDst);

	//! Copying a CEdge Object to a SEdge Object
	/*! \param peSrc The CEdge Object
	 *  \param peDst The SEdge Object
	 *  \return Result of the Action (Success/Failure)
	 *  \author Chibiao Chen
	 */
	static bool CopyEdge(CEdge* peSrc, SEdge* peDst);
		
private:
	//! SPoint Object Comparison Function (Less Then)
	/*! \param ptA SPoint Object A
	 *  \param ptB SPoint Object B
	 *  \return Result of the Comparison
	 *  \author Chibiao Chen
	 */
	static bool PointLess(const SPoint& ptA, const SPoint& ptB);

	//! Getting the Next Site (Data Point)
	/*! \param vptX The Data Points 
	 *  \return The Next Site
	 *  \author Chibiao Chen
	 */
	static SPoint* NextSite(vector< SPoint >& vptX);

	static int m_nIndex;  //!< The Index of Data Points; Used in NextSite()
};

#endif//__VORONOI__
