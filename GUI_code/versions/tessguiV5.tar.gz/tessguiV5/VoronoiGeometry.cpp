#include <cmath>

#include "VoronoiGeometry.h"

CVoronoiGeometry::CVoronoiGeometry()
{
	m_dXMin = -8.0;
	m_dXMax = +8.0;
	double dDeltaX = m_dXMax - m_dXMin;
	m_dYMin = -8.0;
	m_dYMax = +8.0;
	double dDeltaY = m_dYMax - m_dYMin;

	m_dXMinLmt = m_dXMin - dDeltaX * 0.1;
	m_dXMaxLmt = m_dXMax + dDeltaX * 0.1;
	m_dYMinLmt = m_dYMin - dDeltaY * 0.1;
	m_dYMaxLmt = m_dYMax + dDeltaY * 0.1;

	m_nNoE = 0;
	m_nNoV = 0;
}

CVoronoiGeometry::CVoronoiGeometry(double dXMin, double dXMax,
								   double dYMin, double dYMax)
{
	m_dXMin = dXMin;
	m_dXMax = dXMax;
	double dDeltaX = m_dXMax - m_dXMin;
	m_dYMin = dYMin;
	m_dYMax = dYMax;
	double dDeltaY = m_dYMax - m_dYMin;

	m_dXMinLmt = m_dXMin - dDeltaX * 0.1;
	m_dXMaxLmt = m_dXMax + dDeltaX * 0.1;
	m_dYMinLmt = m_dYMin - dDeltaY * 0.1;
	m_dYMaxLmt = m_dYMax + dDeltaY * 0.1;

	m_nNoE = 0;
	m_nNoV = 0;
}

CVoronoiGeometry::~CVoronoiGeometry()
{
}

SEdge* CVoronoiGeometry::Bisect(SPoint* pptOne, SPoint* pptTwo)
{
	SEdge* peNew = m_fnlePrivate.GetFreeNode();
	peNew->m_pptReg[0] = pptOne;
	peNew->m_pptReg[1] = pptTwo;
	peNew->m_pptEnd[0] = PT_NULL;
	peNew->m_pptEnd[1] = PT_NULL;

	double dDX = pptTwo->m_psXY.m_dX - pptOne->m_psXY.m_dX;
	double dDY = pptTwo->m_psXY.m_dY - pptOne->m_psXY.m_dY;
	double dADX = dDX > 0 ? dDX : -dDX;
	double dADY = dDY > 0 ? dDY : -dDY;
	peNew->m_dC = pptOne->m_psXY.m_dX * dDX + pptOne->m_psXY.m_dY * dDY +
		0.5 * (dDX * dDX + dDY * dDY);
	if (dADX > dADY)
	{
		peNew->m_dA = 1.0;
		peNew->m_dB = dDY / dDX;
		peNew->m_dC /= dDX;
	}
	else
	{
		peNew->m_dB = 1.0;
		peNew->m_dA = dDX / dDY;
		peNew->m_dC /= dDY;
	}

	peNew->m_nIndex = m_nNoE++;

	return peNew;
}

SPoint* CVoronoiGeometry::Intersect(SHalfEdge* pheOne, SHalfEdge* pheTwo)
{
	SEdge* peOne = pheOne->m_peEdge;
	SEdge* peTwo = pheTwo->m_peEdge;
	if (peOne == EG_NULL || peTwo == EG_NULL)
	{
		return PT_NULL;
	}
	if (peOne->m_pptReg[1] == peTwo->m_pptReg[1])
	{
		return PT_NULL;
	}
	double dD = peOne->m_dA * peTwo->m_dB - peTwo->m_dA * peOne->m_dB;
	if (-1.0E-68 < dD && dD < +1.0E-68)
	{
		return PT_NULL;
	}
	double dXI = (peTwo->m_dB * peOne->m_dC - peOne->m_dB * peTwo->m_dC) / dD;
	double dYI = (peOne->m_dA * peTwo->m_dC - peTwo->m_dA * peOne->m_dC) / dD;
	SHalfEdge* pheThis;
	SEdge* peThis;
	if (peOne->m_pptReg[1]->m_psXY.m_dY < peTwo->m_pptReg[1]->m_psXY.m_dY ||
		peOne->m_pptReg[1]->m_psXY.m_dY == peTwo->m_pptReg[1]->m_psXY.m_dY &&
			peOne->m_pptReg[1]->m_psXY.m_dX < peTwo->m_pptReg[1]->m_psXY.m_dX)
	{
		pheThis = pheOne;
		peThis = peOne;
	}
	else
	{
		pheThis = pheTwo;
		peThis = peTwo;
	}
	bool bRightOfSite = dXI >= peThis->m_pptReg[1]->m_psXY.m_dX;
	if (bRightOfSite && pheThis->m_nSide == LE ||
		!bRightOfSite && pheThis->m_nSide == RE)
	{
		return PT_NULL;
	}
	SPoint* pptVertex = m_fnlptPrivate.GetFreeNode();
	pptVertex->m_psXY.m_dX = dXI;
	pptVertex->m_psXY.m_dY = dYI;

	return pptVertex;
}

bool CVoronoiGeometry::EndPoint(SEdge* peThis, int nSide, SPoint* pptThis)
{
	peThis->m_pptEnd[nSide] = pptThis;
	if (peThis->m_pptEnd[RE - nSide] == PT_NULL)
	{
		return false;
	}

	return true;
}

double CVoronoiGeometry::Distance(SPoint* pptOne, SPoint* pptTwo)
{
	double dDX = pptTwo->m_psXY.m_dX - pptOne->m_psXY.m_dX;
	double dDY = pptTwo->m_psXY.m_dY - pptOne->m_psXY.m_dY;

	return sqrt(dDX * dDX + dDY * dDY);
}

void CVoronoiGeometry::MakeVertex(SPoint* pptVertex)
{
	pptVertex->m_nIndex = m_nNoV++;
}

void CVoronoiGeometry::ClipEdge(SEdge* peThis, SPosition& psOne, SPosition& psTwo)
{
	SPoint* pptEnd1;
	SPoint* pptEnd2;
	if (peThis->m_dA == 1.0 && peThis->m_dB >= 0)
	{
		pptEnd1 = peThis->m_pptEnd[1];
		pptEnd2 = peThis->m_pptEnd[0];
	}
	else
	{
		pptEnd1 = peThis->m_pptEnd[0];
		pptEnd2 = peThis->m_pptEnd[1];
	}
	double dX1;
	double dX2;
	double dY1;
	double dY2;
	if (peThis->m_dA == 1.0)
	{
		dY1 = m_dYMinLmt;
		if (pptEnd1 != PT_NULL && pptEnd1->m_psXY.m_dY > m_dYMinLmt)
		{
			dY1 = pptEnd1->m_psXY.m_dY;
		}
		if (dY1 > m_dYMaxLmt)
		{
			return;
		}
		dX1 = peThis->m_dC - peThis->m_dB * dY1;
		dY2 = m_dYMaxLmt;
		if (pptEnd2 != PT_NULL && pptEnd2->m_psXY.m_dY < m_dYMaxLmt)
		{
			dY2 = pptEnd2->m_psXY.m_dY;
		}
		if (dY2 < m_dYMinLmt)
		{
			return;
		}
		dX2 = peThis->m_dC - peThis->m_dB * dY2;
		if (dX1 < m_dXMinLmt && dX2 < m_dXMinLmt || dX1 > m_dXMaxLmt && dX2 > m_dXMaxLmt)
		{
			return;
		}
		if (dX1 < m_dXMinLmt)
		{
			dX1 = m_dXMinLmt;
			dY1 = (peThis->m_dC - dX1) / peThis->m_dB;
		}
		if (dX1 > m_dXMaxLmt)
		{
			dX1 = m_dXMaxLmt;
			dY1 = (peThis->m_dC - dX1) / peThis->m_dB;
		}
		if (dX2 < m_dXMinLmt)
		{
			dX2 = m_dXMinLmt;
			dY2 = (peThis->m_dC - dX2) / peThis->m_dB;
		}
		if (dX2 > m_dXMaxLmt)
		{
			dX2 = m_dXMaxLmt;
			dY2 = (peThis->m_dC - dX2) / peThis->m_dB;
		}
	}
	else
	{
		dX1 = m_dXMinLmt;
		if (pptEnd1 != PT_NULL && pptEnd1->m_psXY.m_dX > m_dXMinLmt)
		{
			dX1 = pptEnd1->m_psXY.m_dX;
		}
		if (dX1 > m_dXMaxLmt)
		{
			return;
		}
		dY1 = peThis->m_dC - peThis->m_dA * dX1;
		dX2 = m_dXMaxLmt;
		if (pptEnd2 != PT_NULL && pptEnd2->m_psXY.m_dX < m_dXMaxLmt)
		{
			dX2 = pptEnd2->m_psXY.m_dX;
		}
		if (dX2 < m_dXMinLmt)
		{
			return;
		}
		dY2 = peThis->m_dC - peThis->m_dA * dX2;
		if (dY1 < m_dYMinLmt && dY2 < m_dYMinLmt || dY1 > m_dYMaxLmt && dY2 > m_dYMaxLmt)
		{
			return;
		}
		if (dY1 < m_dYMinLmt)
		{
			dY1 = m_dYMinLmt;
			dX1 = (peThis->m_dC - dY1) / peThis->m_dA;
		}
		if (dY1 > m_dYMaxLmt)
		{
			dY1 = m_dYMaxLmt;
			dX1 = (peThis->m_dC - dY1) / peThis->m_dA;
		}
		if (dY2 < m_dYMinLmt)
		{
			dY2 = m_dYMinLmt;
			dX2 = (peThis->m_dC - dY2) / peThis->m_dA;
		}
		if (dY2 > m_dYMaxLmt)
		{
			dY2 = m_dYMaxLmt;
			dX2 = (peThis->m_dC - dY2) / peThis->m_dA;
		}
	}
	psOne.m_dX = dX1;
	psOne.m_dY = dY1;
	psTwo.m_dX = dX2;
	psTwo.m_dY = dY2;
}