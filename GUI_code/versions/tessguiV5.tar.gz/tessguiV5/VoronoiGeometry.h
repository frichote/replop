#ifndef __VORONOI_GEOMETRY__
#define __VORONOI_GEOMETRY__

#include "FortuneStructures.h"
#include "FreeNodeList.h"

#define INF 1.0E+168

class CVoronoiGeometry
{
public:
	CVoronoiGeometry();
	CVoronoiGeometry(double dXMin, double dXMax, double dYMin, double dYMax);
	virtual ~CVoronoiGeometry();
	SEdge* Bisect(SPoint* pptOne, SPoint* pptTwo);
	SPoint* Intersect(SHalfEdge* pheOne, SHalfEdge* pheTwo);
	bool EndPoint(SEdge* peThis, int nSide, SPoint* pptThis);
	double Distance(SPoint* pptOne, SPoint* pptTwo);
	void MakeVertex(SPoint* pptVertex);
	void ClipEdge(SEdge* peThis, SPosition& psOne, SPosition& psTwo);
	double GetXMinLmt();
	double GetXMaxLmt();
	double GetYMinLmt();
	double GetYMaxLmt();

private:
	double m_dXMin;
	double m_dXMax;
	double m_dYMin;
	double m_dYMax;

	double m_dXMinLmt;
	double m_dXMaxLmt;
	double m_dYMinLmt;
	double m_dYMaxLmt;

	int m_nNoV;
	int m_nNoE;
	CFreeNodeList< SEdge > m_fnlePrivate;
	CFreeNodeList< SPoint > m_fnlptPrivate;
};

inline double CVoronoiGeometry::GetXMinLmt()
{
	return m_dXMinLmt;
}

inline double CVoronoiGeometry::GetXMaxLmt()
{
	return m_dXMaxLmt;
}

inline double CVoronoiGeometry::GetYMinLmt()
{
	return m_dYMinLmt;
}

inline double CVoronoiGeometry::GetYMaxLmt()
{
	return m_dYMaxLmt;
}

#endif//__VORONOI_GEOMETRY__
