#include <QtGui>
#include "aboutdialog.h"
#include "title.h"

AboutDialog::AboutDialog(QWidget *parent)
    : QDialog(parent)
{
	setWindowTitle(tr("About %1").arg(GUI_TITLE));

	QLabel *aboutLabel = new QLabel(tr("<b>%1</b> is a user friendly shell for "
		"<b>%2</b>, which is a MCMC algorithm for inference of spatial "
		"population structure.").arg(GUI_TITLE).arg(CMD_TITLE));
	aboutLabel->setWordWrap(true);
	
	QLabel *emailLabel = new QLabel(tr("Contact Authors: "));
	QLabel *emailUrl = new QLabel(tr("<a href=\"mailto:eric.durand20@gmail.com\">eric.durand20@gmail.com</a>"));
	QLabel *emailUrl2 = new QLabel(tr("<a href=\"mailto:chen.chibiao@gmail.com\">chen.chibiao@gmail.com</a>"));
	emailUrl->setOpenExternalLinks(true);
	emailUrl2->setOpenExternalLinks(true);
	QLabel *wwwLabel = new QLabel(tr("Download Latest Version: "));
	QLabel *wwwUrl = new QLabel(tr("<a href=\"http://www-timc.imag.fr/Olivier.Francois/\">http://www-timc.imag.fr/Olivier.Francois/</a>"));
	wwwUrl->setOpenExternalLinks(true);
	QGridLayout *urlLayout = new QGridLayout;
	urlLayout->addWidget(emailLabel, 0, 0);
	urlLayout->addWidget(emailUrl, 0, 1);
	urlLayout->addWidget(emailUrl2, 1, 1);
	urlLayout->addWidget(wwwLabel, 2, 0);
	urlLayout->addWidget(wwwUrl, 2, 1);

	QLabel *disclaimerLabel = new QLabel(tr("The program is provided AS IS with "
		"NO WARRANTY OF ANY KIND, INCLUDING THE WARRANTY OF DESIGN, "
		"MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE."));
	disclaimerLabel->setWordWrap(true);

	QPushButton *okPushButton = new QPushButton(tr("OK"));
	connect(okPushButton, SIGNAL(clicked()), this, SLOT(accept()));
	QHBoxLayout *okLayout = new QHBoxLayout;
	okLayout->addStretch();
	okLayout->addWidget(okPushButton);
	okLayout->addStretch();

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addWidget(aboutLabel);
	mainLayout->addLayout(urlLayout);
	mainLayout->addWidget(disclaimerLabel);
	mainLayout->addStretch();
	mainLayout->addSpacing(5);
	mainLayout->addLayout(okLayout);

	setLayout(mainLayout);
}

AboutDialog::~AboutDialog()
{
}

