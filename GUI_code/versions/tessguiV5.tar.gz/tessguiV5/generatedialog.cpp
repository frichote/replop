#include <QtCore>
#include <QtGui>
#include "generatedialog.h"
#include "datawindow.h"
#include "title.h"

GenerateDialog::GenerateDialog(QWidget *parent)
    : QDialog(parent)
{
	setWindowTitle(tr("Generate Spatial Coordinates"));

	QLabel *sfLabel = new QLabel(tr("Spatial Information File:"));
	sfLineEdit = new QLineEdit;
	connect(sfLineEdit, SIGNAL(textChanged(const QString &)), 
		this, SLOT(sFileChanged()));

	QPushButton *browseSFilePushButton = new QPushButton(tr("Browse..."));
	browseSFilePushButton->setAutoDefault(false);
	connect(browseSFilePushButton, SIGNAL(clicked()), this, SLOT(browseSFile()));

	viewSFilePushButton = new QPushButton(tr("View..."));
	viewSFilePushButton->setAutoDefault(false);
	viewSFilePushButton->setEnabled(false);
	connect(viewSFilePushButton, SIGNAL(clicked()), this, SLOT(viewSFile()));

	QFrame *sgFrame = new QFrame;
	sgFrame->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	QLabel *gfLabel = new QLabel(tr("Genetic Information File:"));
	gfLineEdit = new QLineEdit;
	connect(gfLineEdit, SIGNAL(textChanged(const QString &)), 
		this, SLOT(gFileChanged()));

	QPushButton *browseGFilePushButton = new QPushButton(tr("Browse..."));
	browseGFilePushButton->setAutoDefault(false);
	connect(browseGFilePushButton, SIGNAL(clicked()), this, SLOT(browseGFile()));

	viewGFilePushButton = new QPushButton(tr("View..."));
	viewGFilePushButton->setAutoDefault(false);
	viewGFilePushButton->setEnabled(false);
	connect(viewGFilePushButton, SIGNAL(clicked()), this, SLOT(viewGFile()));

	QLabel *nLabel = new QLabel(tr("Number of Individuals:"));
	nLineEdit = new QLineEdit;
	QIntValidator *nV = new QIntValidator(this);
	nV->setBottom(1);
	nLineEdit->setValidator(nV);

	QLabel *dLabel = new QLabel(tr("Number of Dummy Individuals:"));
	dLineEdit = new QLineEdit;
	dLineEdit->setText(tr("0"));
	QIntValidator *dV = new QIntValidator(this);
	dV->setBottom(0);
	dLineEdit->setValidator(dV);

	QLabel *aLabel = new QLabel(tr("Ploidy:"));
	aLineEdit = new QLineEdit;
	aLineEdit->setText(tr("2"));
	QIntValidator *aV = new QIntValidator(this);
	aV->setBottom(1);
	aLineEdit->setValidator(aV);

	QLabel *lLabel = new QLabel(tr("Number of Loci:"));
	lLineEdit = new QLineEdit;
	QIntValidator *lV = new QIntValidator(this);
	lV->setBottom(1);
	lLineEdit->setValidator(lV);

	aCheckBox = new QCheckBox(tr("Data Containing Information for Association Mapping Test"));

	QLabel *rLabel = new QLabel(tr("Number of Extra Rows:"));
	rLineEdit = new QLineEdit;
	rLineEdit->setText(tr("0"));
	QIntValidator *rV = new QIntValidator(this);
	rV->setBottom(0);
	rLineEdit->setValidator(rV);

	QLabel *cLabel = new QLabel(tr("Number of Extra Columns:"));
	cLineEdit = new QLineEdit;
	cLineEdit->setText(tr("0"));
	QIntValidator *cV = new QIntValidator(this);
	cV->setBottom(0);
	cLineEdit->setValidator(cV);

	QFrame *grFrame = new QFrame;
	grFrame->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	QLabel *rfLabel = new QLabel(tr("Result File with Combined Info.:"));
	rfLineEdit = new QLineEdit;

	QPushButton *browseRFilePushButton = new QPushButton(tr("Browse..."));
	browseRFilePushButton->setAutoDefault(false);
	connect(browseRFilePushButton, SIGNAL(clicked()), this, SLOT(browseRFile()));

	showResult = new QCheckBox(tr("Show Generated (Textual) Result File"));
	showResult->setCheckState(Qt::Checked);

	showCoords = new QCheckBox(tr("Show Generated Spatial Coordinates (Visually)"));
	showCoords->setCheckState(Qt::Checked);

	QGridLayout *infoLayout = new QGridLayout;
	infoLayout->addWidget(sfLabel, 0, 0);
	infoLayout->addWidget(sfLineEdit, 0, 1);
	infoLayout->addWidget(browseSFilePushButton, 0, 2);
	infoLayout->addWidget(viewSFilePushButton, 0, 3);
	infoLayout->addWidget(sgFrame, 1, 0, 1, 4);
	infoLayout->addWidget(gfLabel, 2, 0);
	infoLayout->addWidget(gfLineEdit, 2, 1);
	infoLayout->addWidget(browseGFilePushButton, 2, 2);
	infoLayout->addWidget(viewGFilePushButton, 2, 3);
	infoLayout->addWidget(nLabel, 3, 0);
	infoLayout->addWidget(nLineEdit, 3, 1);
	infoLayout->addWidget(dLabel, 4, 0);
	infoLayout->addWidget(dLineEdit, 4, 1);
	infoLayout->addWidget(aLabel, 5, 0);
	infoLayout->addWidget(aLineEdit, 5, 1);
	infoLayout->addWidget(lLabel, 6, 0);
	infoLayout->addWidget(lLineEdit, 6, 1);
	//infoLayout->addWidget(aCheckBox, 7, 0, 1, 4);
	infoLayout->addWidget(rLabel, 8, 0);
	infoLayout->addWidget(rLineEdit, 8, 1);
	infoLayout->addWidget(cLabel, 9, 0);
	infoLayout->addWidget(cLineEdit, 9, 1);
	infoLayout->addWidget(grFrame, 10, 0, 1, 4);
	infoLayout->addWidget(rfLabel, 11, 0);
	infoLayout->addWidget(rfLineEdit, 11, 1);
	infoLayout->addWidget(browseRFilePushButton, 11, 2);
	infoLayout->addWidget(showResult, 12, 0, 1, 2);
	infoLayout->addWidget(showCoords, 13, 0, 1, 2);

	QPushButton *okPushButton = new QPushButton(tr("OK"));
	okPushButton->setDefault(true);
	connect(okPushButton, SIGNAL(clicked()), this, SLOT(accept()));

	QPushButton *cancelPushButton = new QPushButton(tr("Cancel"));
	connect(cancelPushButton, SIGNAL(clicked()), this, SLOT(reject()));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch();
	buttonLayout->addWidget(okPushButton);
	buttonLayout->addStretch();
	buttonLayout->addWidget(cancelPushButton);
	buttonLayout->addStretch();
	
	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(infoLayout);
	mainLayout->addStretch();
	mainLayout->addSpacing(5);
	mainLayout->addLayout(buttonLayout);

	setLayout(mainLayout);
}

GenerateDialog::~GenerateDialog()
{
}

void GenerateDialog::accept()
{
	if (validate())
	{
		QDialog::accept();
	}
}

void GenerateDialog::browseSFile()
{
	QString file = QFileDialog::getOpenFileName(this, 
		tr("Choose Spatial Information File"), commonPath);
	if (!file.isEmpty())
	{
		sfLineEdit->setText(file);
		commonPath = QFileInfo(file).absolutePath();
	}
}

void GenerateDialog::browseGFile()
{
	QString file = QFileDialog::getOpenFileName(this, 
		tr("Choose Genetic Information File"), commonPath);
	if (!file.isEmpty())
	{
		gfLineEdit->setText(file);
		commonPath = QFileInfo(file).absolutePath();
	}
}

void GenerateDialog::browseRFile()
{
	QString file = QFileDialog::getSaveFileName(this, tr("Save Result File"), commonPath);
	if (!file.isEmpty())
	{
		rfLineEdit->setText(file);
		commonPath = QFileInfo(file).absolutePath();
	}
}

void GenerateDialog::sFileChanged()
{
	viewSFilePushButton->setEnabled(!sfLineEdit->text().isEmpty());
}

void GenerateDialog::gFileChanged()
{
	viewGFilePushButton->setEnabled(!gfLineEdit->text().isEmpty());
}

void GenerateDialog::viewSFile()
{
	if (!QFile::exists(sfLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified spatial information file does not exist."));
		return;
	}

	QDialog *dataDialog = new QDialog;
	dataDialog->setAttribute(Qt::WA_DeleteOnClose);
	dataDialog->setWindowTitle(tr("Spatial Information File"));
	DataWindow *dataWidget = new DataWindow;
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(dataWidget);
	dataDialog->setLayout(mainLayout);
	if (dataWidget->loadFile(sfLineEdit->text()))
	{
		dataDialog->exec();	
	}
	else
	{
		dataDialog->close();
	}
}

void GenerateDialog::viewGFile()
{
	if (!QFile::exists(gfLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified genetic information file does not exist."));
		return;
	}

	QDialog *dataDialog = new QDialog;
	dataDialog->setAttribute(Qt::WA_DeleteOnClose);
	dataDialog->setWindowTitle(tr("Genetic Information File"));
	DataWindow *dataWidget = new DataWindow;
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(dataWidget);
	dataDialog->setLayout(mainLayout);
	if (dataWidget->loadFile(gfLineEdit->text()))
	{
		dataDialog->exec();	
	}
	else
	{
		dataDialog->close();
	}
}

bool GenerateDialog::validate()
{
	if (sfLineEdit->text().isEmpty() || !QFile::exists(sfLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified spatial information file does not exist."));
		return false;
	}

	QList< int > sfFormat = infoFormat(sfLineEdit->text());
	sfNumRow = sfFormat.size();
	int i;
	for (i = 0; i < sfNumRow; i++)
	{
		if (sfFormat.at(i) != SF_NUM_COL)
		{
			QMessageBox::warning(this, GUI_TITLE, QString(tr(
				"For the spatial information file, there should be exactly %1 columns on each row.\n\n"
				"The correct format is as following:\n"
				"Number-of-Individuals-in-Region X-Min X-Max X-Sigma Y-Min Y-Max Y-Sigma")).arg(SF_NUM_COL));
			return false;
		}
	}

	if (gfLineEdit->text().isEmpty() || !QFile::exists(gfLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified genetic information file does not exist."));
		return false;
	}

	QString nText = nLineEdit->text();
	int nPos = 0;
	if (nLineEdit->validator()->validate(nText, nPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Individuals"));
		return false;
	}

	QString dText = dLineEdit->text();
	int dPos = 0;
	if (dLineEdit->validator()->validate(dText, dPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Dummy Individuals"));
		return false;
	}

	QString aText = aLineEdit->text();
	int aPos = 0;
	if (aLineEdit->validator()->validate(aText, aPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Ploidy"));
		return false;
	}

	QString lText = lLineEdit->text();
	int lPos = 0;
	if (lLineEdit->validator()->validate(lText, lPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Loci"));
		return false;
	}

	QString rText = rLineEdit->text();
	int rPos = 0;
	if (rLineEdit->validator()->validate(rText, rPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Extra Rows"));
		return false;
	}

	QString cText = cLineEdit->text();
	int cPos = 0;
	if (cLineEdit->validator()->validate(cText, cPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Extra Columns"));
		return false;
	}

	// Specified Total Number of Rows
	int sRows = rLineEdit->text().toInt() + aLineEdit->text().toInt() * 
		(nLineEdit->text().toInt() + dLineEdit->text().toInt());
	QList< int > gfFormat = infoFormat(gfLineEdit->text());
	// Expected Total Number of Rows
	int eRows = gfFormat.size();
	if (sRows != eRows)
	{
		QMessageBox::warning(this, GUI_TITLE, QString(tr(
			"According to your input, there should be totally %1 rows in the\n"
			"genetic information file, but I detected that there are actually %2 rows.\n\n"
			"Please check whether you have correctly input:\n"
			"Number of Individuals\n"
			"Number of Dummy Individuals\n"
			"Ploidy\n"
			"Number of Extra Rows")).arg(sRows).arg(eRows));
		return false;
	}
	// Specified Total Number of Columns
	int sCols = cLineEdit->text().toInt() + lLineEdit->text().toInt();
	if (aCheckBox->checkState() == Qt::Checked)
	{
		sCols += 2;
	}
	// Expected Total Number of Columns
	int eCols;
	for (i = rLineEdit->text().toInt(); i < eRows; i++)
	{
		eCols = gfFormat.at(i);
		if (sCols != eCols)
		{
			QMessageBox::warning(this, GUI_TITLE, QString(tr(
				"According to your input, there should be %1 columns in the data area of\n"
				"the genetic information file, but I detected that there are actually %2 columns.\n\n"
				"Please check whether you have correctly input:\n"
				"Number of Loci\n"
				"Data Containing Information for Association Mapping Test\n"
				"Number of Extra Columns\n"
				"Number of Extra Rows")).arg(sCols).arg(eCols));
			return false;
		}
	}

	resultPath = QFileInfo(rfLineEdit->text()).absolutePath();
	QDir resultDir(resultPath);
	if (rfLineEdit->text().isEmpty() || !resultDir.exists())
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified result PATH does not exist."));
		return false;
	}
	resultBase = QFileInfo(rfLineEdit->text()).baseName();

	return true;
}

const QList< int > &GenerateDialog::infoFormat(const QString &infoFile)
{
	static QList< int > format;
	format.clear();

	QFile file(infoFile);
	if (!file.open(QFile::ReadOnly | QFile::Text)) 
	{
		QMessageBox::warning(this, GUI_TITLE,
			tr("Cannot verify information file %1!").arg(infoFile));
		return format;
	}
	QTextStream in(&file);
	QRegExp reWC("\\w");  // Word Character
	QRegExp regExp("\\s+|\\t+");  // Space(s) or Tab(s)
	QString oneRow;
	QStringList oneRowList;
	QApplication::setOverrideCursor(Qt::WaitCursor);
	while (!(oneRow = in.readLine()).isNull())
	{
		if (oneRow.contains(reWC))
		{
			oneRowList = oneRow.split(regExp, QString::SkipEmptyParts);
			format.append(oneRowList.size());
		}
	}
	QApplication::restoreOverrideCursor();
	file.close();

	return format;
}

