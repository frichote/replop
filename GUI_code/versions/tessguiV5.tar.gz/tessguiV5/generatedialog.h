#ifndef GENERATEDIALOG_H
#define GENERATEDIALOG_H

#include <QDialog>

#define SF_NUM_COL 7

class QCheckBox;
class QLineEdit;
class QPushButton;

class GenerateDialog : public QDialog
{
    Q_OBJECT

public:
    GenerateDialog(QWidget *parent = 0);
    ~GenerateDialog();

public:
	QLineEdit *sfLineEdit;	// Spatial Information File (Input)
	QLineEdit *gfLineEdit;	// Genetic Information File (Input)
	QLineEdit *rfLineEdit;	// Result File (Output)

	QLineEdit *nLineEdit;	// Number of Individuals
	QLineEdit *dLineEdit;	// Number of Dummy Individuals
	QLineEdit *aLineEdit;	// Ploidy
	QLineEdit *lLineEdit;	// Number of Loci
	QCheckBox *aCheckBox;	// Data Containing Information for Association Mapping Test?
	QLineEdit *rLineEdit;	// Number of Extra Rows
	QLineEdit *cLineEdit;	// Number of Extra Columns

	QCheckBox *showResult;	// Show the result text file?
	QCheckBox *showCoords;	// Show the generated spatial coordinates visually?

	QString commonPath;

	QString resultPath;
	QString resultBase;

	int sfNumRow;

protected:
	void accept();

private slots:
	void browseSFile();
	void browseGFile();
	void browseRFile();
	void sFileChanged();
	void gFileChanged();
	void viewSFile();
	void viewGFile();

private:
	bool validate();
	const QList< int > &infoFormat(const QString &infoFile);

private:
	QPushButton *viewSFilePushButton;
	QPushButton *viewGFilePushButton;
};

#endif // GENERATEDIALOG_H
