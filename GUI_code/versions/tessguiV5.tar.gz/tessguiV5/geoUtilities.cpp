#include <gsl/gsl_math.h>
#include <gsl/gsl_sf_trig.h>
#include "geoUtilities.h"
#include <cmath>


#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

#define radius 	6372.795	//earth radius in kilometers

void computeEuclidianDist(const DBL_VCTR_2D& coord, DBL_VCTR_2D& dist) 
{
	int N = static_cast<int>(coord.size());
	int i,j;
	double tmp1,tmp2;
	for (i=0;i<N;i++) 
	{
		for (j=0; j<N;j++)
		{
			if (i == j)
			{
				dist[i][j] = 0;
			}
			else
			{
				tmp1 = (double)((coord[i][0] - coord[j][0]));	
				tmp2 = (double)((coord[i][1] - coord[j][1]));
				dist[i][j] = sqrt((double)(gsl_pow_2(tmp1) + gsl_pow_2(tmp2)));
			}
		}
	}
}

void computeGCDist(const DBL_VCTR_2D& coord, DBL_VCTR_2D& dist, bool longFirst)
{
	int N = static_cast<int>(coord.size());
	double dLambda; //longitude difference
	double dPhi; //latitude difference
	double dSigma; //angular difference
	double sign_i1,sign_i2,sign_j1,sign_j2,deg_i1,deg_i2,deg_j1,deg_j2,min_i1,min_i2,min_j1,min_j2,lati,latj,longi,longj = 0.0;
	int i,j;
	double tmp,tmp1,tmp2;
	
	for (i=0;i<N;i++) 
	{
		for (j=0; j<N; j++)
		{
			if (i == j)
			{
				dist[i][j] = 0.0;
			}
			else 
			{
				if (coord[i][0] >= 0) {
					sign_i1 = 1;
				}
				else {
					sign_i1 = -1;
				}
				
				if (coord[i][1] >= 0) {
					sign_i2 = 1;
				}
				else {
					sign_i2 = -1;
				}
				
				if (coord[j][0] >= 0) {
					sign_j1 = 1;
				}
				else {
					sign_j1 = -1;
				}
				
				if (coord[j][1] >= 0) {
					sign_j2 = 1;
				}
				else {
					sign_j2 = -1;
				}
				
				deg_i1 = floor(abs(coord[i][0]));
				deg_i2 = floor(abs(coord[i][1]));
				deg_j1 = floor(abs(coord[j][0]));
				deg_j2 = floor(abs(coord[j][1]));
				
				min_i1 = floor((abs(coord[i][0]) - deg_i1)*100);
				min_i2 = floor((abs(coord[i][1]) - deg_i2)*100);
				min_j1 = floor((abs(coord[j][0]) - deg_j1)*100);
				min_j2 = floor((abs(coord[j][1]) - deg_j2)*100);
			
				if (!longFirst)
				{
					longi = sign_i2*(deg_i2 + min_i2/60.0)*3.1415927/180.0;
					longj =	sign_j2*(deg_j2 + min_j2/60.0)*3.1415927/180.0;
				
					lati = sign_i1*(deg_i2 + min_i1/60.0)*3.1415927/180.0;
					latj = sign_j1*(deg_j1 + min_j1/60.0)*3.1415927/180.0;
					dLambda =  longi - longj;
					dPhi = 	lati - latj;
// 				dSigma = 2*asin(sqrt(gsl_pow_2(gsl_sf_sin(dPhi/2.0)) + gsl_sf_cos(coord[i][0])*gsl_sf_cos(coord[j][0])*gsl_sf_sin(dLambda/2.0)));
// 				dSigma = atan(sqrt(gsl_pow_2(gsl_sf_cos(coord[j][0])*gsl_sf_sin(dLambda)) + gsl_pow_2(gsl_sf_cos(coord[i][0])*gsl_sf_sin(coord[j][0]) - gsl_sf_sin(coord[i][0])*gsl_sf_cos(coord[j][0])*gsl_sf_cos(dLambda)))/(gsl_sf_sin(coord[i][0])*gsl_sf_sin(coord[j][0]) + gsl_sf_cos(coord[i][0])*gsl_sf_cos(coord[j][0])*gsl_sf_cos(dLambda)));
					dSigma = atan2(sqrt(gsl_pow_2(gsl_sf_cos(latj)*gsl_sf_sin(dLambda)) + gsl_pow_2(gsl_sf_cos(lati)*gsl_sf_sin(latj) - gsl_sf_sin(lati)*gsl_sf_cos(latj)*gsl_sf_cos(dLambda))),(gsl_sf_sin(lati)*gsl_sf_sin(latj) + gsl_sf_cos(lati)*gsl_sf_cos(latj)*gsl_sf_cos(dLambda)));
				}
				else
				{
					lati = sign_i2*(deg_i2 + min_i2/60.0)*3.1415927/180.0;
					latj =	sign_j2*(deg_j2 + min_j2/60.0)*3.1415927/180.0;
				
					longi = sign_i1*(deg_i1 + min_i1/60.0)*3.1415927/180.0;
					longj = sign_j1*(deg_j1 + min_j1/60.0)*3.1415927/180.0;
				
				
					dPhi = lati - latj;
					dLambda = longi - longj;

// 				dSigma = atan(sqrt(gsl_pow_2(gsl_sf_cos(coord[j][1])*gsl_sf_sin(dLambda)) + gsl_pow_2(gsl_sf_cos(coord[i][1])*gsl_sf_sin(coord[j][1]) - gsl_sf_sin(coord[i][1])*gsl_sf_cos(coord[j][1])*gsl_sf_cos(dLambda)))/(gsl_sf_sin(coord[i][1])*gsl_sf_sin(coord[j][1]) + gsl_sf_cos(coord[i][1])*gsl_sf_cos(coord[j][1])*gsl_sf_cos(dLambda)));
					dSigma = atan2(sqrt(gsl_pow_2(gsl_sf_cos(latj)*gsl_sf_sin(dLambda)) + gsl_pow_2(gsl_sf_cos(lati)*gsl_sf_sin(latj) - gsl_sf_sin(lati)*gsl_sf_cos(latj)*gsl_sf_cos(dLambda))),(gsl_sf_sin(lati)*gsl_sf_sin(latj) + gsl_sf_cos(lati)*gsl_sf_cos(latj)*gsl_sf_cos(dLambda)));
				}	
						
				tmp = radius * dSigma;
				
				if (isnan(tmp) || !finite(tmp))
				{
					tmp1 = (double)((coord[i][0] - coord[j][0]));	
					tmp2 = (double)((coord[i][1] - coord[j][1]));
					dist[i][j] = sqrt((double)(gsl_pow_2(tmp1) + gsl_pow_2(tmp2)));
				}
				else
				{
					dist[i][j] = tmp;
				}
			}
		}
	}
}
