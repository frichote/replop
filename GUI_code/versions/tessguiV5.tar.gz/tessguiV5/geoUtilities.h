#include "VectorUtilities.h"

//compute euclidian distance 
void computeEuclidianDist(const DBL_VCTR_2D& coord, DBL_VCTR_2D& dist);

//compute great circle distances
void computeGCDist(const DBL_VCTR_2D& coord, DBL_VCTR_2D& dist, bool longFirst);
