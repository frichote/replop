#include <QtCore>
#include <QtGui>
#include "geodialog.h"
#include "title.h"
#include "datawindow.h"

GeoDialog::GeoDialog(QWidget *parent)
	: QDialog(parent)
{
	setWindowTitle(tr("Generate Geographic Distances"));
	
	gcRadioButton = new QRadioButton(tr("Compute Great Circle Distances"));
	gcRadioButton->setChecked(true);
	euclRadioButton = new QRadioButton(tr("Compute Euclidian Distances"));
	
	
	QLabel *sfLabel = new QLabel(tr("File Containing Spatial Information (TESS format):"));
	sfLineEdit = new QLineEdit;
	connect(sfLineEdit, SIGNAL(textChanged(const QString &)), 
		this, SLOT(sFileChanged()));

	specialCheckBox = new QCheckBox(tr("Data Stored in One Line per Individual Format"));
	recessiveCheckBox = new QCheckBox(tr("Row of recessive alleles"));
	
	QPushButton *browseSFilePushButton = new QPushButton(tr("Browse..."));
	browseSFilePushButton->setAutoDefault(false);
	connect(browseSFilePushButton, SIGNAL(clicked()), this, SLOT(browseSFile()));

	viewSFilePushButton = new QPushButton(tr("View..."));
	viewSFilePushButton->setAutoDefault(false);
	viewSFilePushButton->setEnabled(false);
	connect(viewSFilePushButton, SIGNAL(clicked()), this, SLOT(viewSFile()));
	
	QLabel *nLabel = new QLabel(tr("Number of Individuals:"));
	nLineEdit = new QLineEdit;
	QIntValidator *nV = new QIntValidator(this);
	nV->setBottom(1);
	nLineEdit->setValidator(nV);
	
	QLabel *aLabel = new QLabel(tr("Ploidy:"));
	aLineEdit = new QLineEdit;
	aLineEdit->setText(tr("2"));
	QIntValidator *aV = new QIntValidator(this);
	aV->setBottom(1);
	aLineEdit->setValidator(aV);
	
	QLabel *rLabel = new QLabel(tr("Number of Extra Rows:"));
	rLineEdit = new QLineEdit;
	rLineEdit->setText(tr("0"));
	QIntValidator *rV = new QIntValidator(this);
	rV->setBottom(0);
	rLineEdit->setValidator(rV);

	QLabel *cLabel = new QLabel(tr("Number of Extra Columns:"));
	cLineEdit = new QLineEdit;
	cLineEdit->setText(tr("0"));
	QIntValidator *cV = new QIntValidator(this);
	cV->setBottom(0);
	cLineEdit->setValidator(cV);

	
	QLabel *rfLabel = new QLabel(tr("Result File with Geographic Distances:"));
	rfLineEdit = new QLineEdit;

	rfLineEdit->setReadOnly(true);
	
	QPushButton *browseRFilePushButton = new QPushButton(tr("Browse..."));
	browseRFilePushButton->setAutoDefault(false);
	connect(browseRFilePushButton, SIGNAL(clicked()), this, SLOT(browseRFile()));

	showResult = new QCheckBox(tr("Show Generated (Textual) Result File"));
	showResult->setCheckState(Qt::Checked);
	
		
	QGridLayout *infoLayout = new QGridLayout;
	infoLayout->addWidget(gcRadioButton,0,0);
	infoLayout->addWidget(euclRadioButton,0,1);
	infoLayout->addWidget(sfLabel,1,0);
	infoLayout->addWidget(sfLineEdit,1,1);
	infoLayout->addWidget(browseSFilePushButton,1,2);
	infoLayout->addWidget(viewSFilePushButton,1,3);
	infoLayout->addWidget(specialCheckBox,2,0);
	infoLayout->addWidget(nLabel,3,0);
	infoLayout->addWidget(nLineEdit,3,1);
	infoLayout->addWidget(aLabel,4,0);
	infoLayout->addWidget(aLineEdit,4,1);
	infoLayout->addWidget(rLabel,5,0);
	infoLayout->addWidget(rLineEdit,5,1);
	infoLayout->addWidget(cLabel,6,0);
	infoLayout->addWidget(cLineEdit,6,1);		     
	infoLayout->addWidget(rfLabel,7,0);
	infoLayout->addWidget(rfLineEdit,7,1);
	infoLayout->addWidget(browseRFilePushButton,7,2);
	infoLayout->addWidget(showResult,8,0);
	
	QPushButton *okPushButton = new QPushButton(tr("OK"));
	okPushButton->setDefault(true);
	connect(okPushButton, SIGNAL(clicked()), this, SLOT(accept()));

	QPushButton *cancelPushButton = new QPushButton(tr("Cancel"));
	connect(cancelPushButton, SIGNAL(clicked()), this, SLOT(reject()));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch();
	buttonLayout->addWidget(okPushButton);
	buttonLayout->addStretch();
	buttonLayout->addWidget(cancelPushButton);
	buttonLayout->addStretch();

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(infoLayout);
	mainLayout->addStretch();
	mainLayout->addSpacing(5);
	mainLayout->addLayout(buttonLayout);

	setLayout(mainLayout);
}

GeoDialog::~GeoDialog()
{
}

void GeoDialog::accept()
{
	if (validate())
	{
		QDialog::accept();
	}
}

void GeoDialog::browseSFile()
{
	QString file = QFileDialog::getOpenFileName(this, 
			tr("Choose Spatial Information File"), commonPath);
	if (!file.isEmpty())
	{
		sfLineEdit->setText(file);
		commonPath = QFileInfo(file).absolutePath();
	}
}



void GeoDialog::browseRFile()
{
	QString file = QFileDialog::getSaveFileName(this, tr("Save Result File"), commonPath);
	if (!file.isEmpty())
	{
		rfLineEdit->setText(file);
		commonPath = QFileInfo(file).absolutePath();
	}
}

void GeoDialog::sFileChanged()
{
	viewSFilePushButton->setEnabled(!sfLineEdit->text().isEmpty());
}

void GeoDialog::viewSFile()
{
	if (!QFile::exists(sfLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
				     tr("The specified spatial information file does not exist."));
		return;
	}

	QDialog *dataDialog = new QDialog;
	dataDialog->setAttribute(Qt::WA_DeleteOnClose);
	dataDialog->setWindowTitle(tr("Spatial Information File"));
	DataWindow *dataWidget = new DataWindow;
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(dataWidget);
	dataDialog->setLayout(mainLayout);
	if (dataWidget->loadFile(sfLineEdit->text()))
	{
		dataDialog->exec();	
	}
	else
	{
		dataDialog->close();
	}
}

bool GeoDialog::validate()
{
	if (sfLineEdit->text().isEmpty() || !QFile::exists(sfLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
				     tr("The specified spatial information file does not exist."));
		return false;
	}
	
	QString nText = nLineEdit->text();
	int nPos = 0;
	if (nLineEdit->validator()->validate(nText, nPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Individuals"));
		return false;
	}

	QString aText = aLineEdit->text();
	int aPos = 0;
	if (aLineEdit->validator()->validate(aText, aPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Ploidy"));
		return false;
	}

	QString rText = rLineEdit->text();
	int rPos = 0;
	if (rLineEdit->validator()->validate(rText, rPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Extra Rows"));
		return false;
	}

	QString cText = cLineEdit->text();
	int cPos = 0;
	if (cLineEdit->validator()->validate(cText, cPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Extra Columns"));
		return false;
	}
	
	// Specified Total Number of Rows
	int sRows;
	if (!specialCheckBox->isChecked())
	{
		sRows = rLineEdit->text().toInt() + aLineEdit->text().toInt() * nLineEdit->text().toInt();
	}
	else
	{
		sRows = rLineEdit->text().toInt() + nLineEdit->text().toInt();
	}
	QList< int > sfFormat = infoFormat(sfLineEdit->text());
	// Expected Total Number of Rows
	int eRows = sfFormat.size();
	if (sRows != eRows)
	{
		QMessageBox::warning(this, GUI_TITLE, QString(tr(
				     "According to your input, there should be totally %1 rows in the\n"
						     "genetic information file, but I detected that there are actually %2 rows.\n\n"
						     "Please check whether you have correctly input:\n"
						     "Number of Individuals\n"
						     "Ploidy\n"
						     "Number of Extra Rows")).arg(sRows).arg(eRows));
		return false;
	}
	
	return true;
	
}

const QList< int > &GeoDialog::infoFormat(const QString &infoFile)
{
	static QList< int > format;
	format.clear();

	QFile file(infoFile);
	if (!file.open(QFile::ReadOnly | QFile::Text)) 
	{
		QMessageBox::warning(this, GUI_TITLE,
				     tr("Cannot verify information file %1!").arg(infoFile));
		return format;
	}
	QTextStream in(&file);
	QRegExp reWC("\\w");  // Word Character
	QRegExp regExp("\\s+|\\t+");  // Space(s) or Tab(s)
	QString oneRow;
	QStringList oneRowList;
	QApplication::setOverrideCursor(Qt::WaitCursor);
	while (!(oneRow = in.readLine()).isNull())
	{
		if (oneRow.contains(reWC))
		{
			oneRowList = oneRow.split(regExp, QString::SkipEmptyParts);
			format.append(oneRowList.size());
		}
	}
	QApplication::restoreOverrideCursor();
	file.close();

	return format;
}
