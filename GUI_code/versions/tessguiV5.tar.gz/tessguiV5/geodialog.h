#ifndef GEODIALOG_H
#define GEODIALOG_H
#include <QDialog>

class QRadioButton;
class QCheckBox;
class QLineEdit;
class QPushButton;

class GeoDialog : public QDialog
{
	Q_OBJECT

public:
	GeoDialog(QWidget *parent = 0);
	~GeoDialog();			
	
public:
	QLineEdit *sfLineEdit;	// Spatial Information File (Input)
	QLineEdit *rfLineEdit;	// Result File (Output)
	QLineEdit *rLineEdit;	// Number of extra rows
	QLineEdit *cLineEdit;	// Number of extra columns
	QLineEdit *nLineEdit;	// Number of individuals
	QLineEdit *aLineEdit;	// Ploidy
	QCheckBox *showResult;	// Show the result text file?
	QRadioButton *gcRadioButton; //Great Circle Distances ?
	QRadioButton *euclRadioButton; //Euclidian Distances ?
	QString commonPath;
	QCheckBox* specialCheckBox;
	QCheckBox* recessiveCheckBox;
	
protected:
	void accept();
	
private:
	QPushButton *viewSFilePushButton;
	bool validate();
	const QList< int > &infoFormat(const QString &infoFile);
	
private slots:
	void browseSFile();
	void browseRFile();
	void sFileChanged();
	void viewSFile();
	
};
#endif
