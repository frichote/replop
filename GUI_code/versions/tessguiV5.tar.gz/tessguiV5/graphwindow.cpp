#include <QtCore>
#include <QtGui>
#include <iostream>
#include "graphwindow.h"
#include "title.h"

using namespace std;

GraphWindow::GraphWindow(QWidget *parent)
    : QScrollArea(parent)
{
	setAttribute(Qt::WA_DeleteOnClose);
	setWindowIcon(QIcon(":/images/filegraph.png"));

	imageLabel = new QLabel;
	imageLabel->setBackgroundRole(QPalette::Base);
	imageLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
	imageLabel->setScaledContents(true);

	setWidget(imageLabel);

	createActions();
	createMenus();
	
}

GraphWindow::~GraphWindow()
{
}

bool GraphWindow::loadFile(const QString &fileName)
{
	if (!fileName.isEmpty()) 
	{
		QImage image(fileName);
		if (image.isNull()) 
		{
			QMessageBox::warning(this, GUI_TITLE,
				tr("Cannot load graph file %1!").arg(fileName));
			return false;
		}
		imageLabel->setPixmap(QPixmap::fromImage(image));
		scaleFactor = 1.0;

		printAct->setEnabled(true);
		fitToWindowAct->setEnabled(true);
		updateActions();

		if (!fitToWindowAct->isChecked())
			imageLabel->adjustSize();
	}

	setWindowTitle(fileName);
	setCurrentFile(fileName);

	return true;
}

void GraphWindow::mousePressEvent(QMouseEvent *event)
{
	if (event->button() == Qt::RightButton)
	{
		viewMenu->exec(event->globalPos());
	}
}

void GraphWindow::print()
{
	Q_ASSERT(imageLabel->pixmap());
	QPrintDialog dialog(&printer, this);
	if (dialog.exec()) 
	{
		QPainter painter(&printer);
		QRect rect = painter.viewport();
		QSize size = imageLabel->pixmap()->size();
		size.scale(rect.size(), Qt::KeepAspectRatio);
		painter.setViewport(rect.x(), rect.y(), size.width(), size.height());
		painter.setWindow(imageLabel->pixmap()->rect());
		painter.drawPixmap(0, 0, *imageLabel->pixmap());
	}
}

void GraphWindow::zoomIn()
{
	scaleImage(1.25);
}

void GraphWindow::zoomOut()
{
	scaleImage(0.8);
}

void GraphWindow::normalSize()
{
	imageLabel->adjustSize();
	scaleFactor = 1.0;
}

void GraphWindow::fitToWindow()
{
	bool fitToWindow = fitToWindowAct->isChecked();
	setWidgetResizable(fitToWindow);
	if (!fitToWindow) 
	{
		normalSize();
	}
	updateActions();
}

void GraphWindow::createActions()
{
	printAct = new QAction(tr("&Print..."), this);
	printAct->setEnabled(false);
	connect(printAct, SIGNAL(triggered()), this, SLOT(print()));

	exitAct = new QAction(tr("&Close"), this);
	connect(exitAct, SIGNAL(triggered()), this, SLOT(close()));

	zoomInAct = new QAction(tr("Zoom &In (25%)"), this);
	zoomInAct->setEnabled(false);
	connect(zoomInAct, SIGNAL(triggered()), this, SLOT(zoomIn()));

	zoomOutAct = new QAction(tr("Zoom &Out (25%)"), this);
	zoomOutAct->setEnabled(false);
	connect(zoomOutAct, SIGNAL(triggered()), this, SLOT(zoomOut()));

	normalSizeAct = new QAction(tr("&Normal Size"), this);
	normalSizeAct->setEnabled(false);
	connect(normalSizeAct, SIGNAL(triggered()), this, SLOT(normalSize()));

	fitToWindowAct = new QAction(tr("&Fit to Window"), this);
	fitToWindowAct->setEnabled(false);
	fitToWindowAct->setCheckable(true);
	connect(fitToWindowAct, SIGNAL(triggered()), this, SLOT(fitToWindow()));
}

void GraphWindow::createMenus()
{
	fileMenu = new QMenu(tr("&File"), this);
	fileMenu->addAction(printAct);
	fileMenu->addSeparator();
	fileMenu->addAction(exitAct);

	viewMenu = new QMenu(tr("&View"), this);
	viewMenu->addAction(zoomInAct);
	viewMenu->addAction(zoomOutAct);
	viewMenu->addAction(normalSizeAct);
	viewMenu->addSeparator();
	viewMenu->addAction(fitToWindowAct);
}

void GraphWindow::updateActions()
{
	zoomInAct->setEnabled(!fitToWindowAct->isChecked());
	zoomOutAct->setEnabled(!fitToWindowAct->isChecked());
	normalSizeAct->setEnabled(!fitToWindowAct->isChecked());
}

void GraphWindow::scaleImage(double factor)
{
	Q_ASSERT(imageLabel->pixmap());
	scaleFactor *= factor;
	imageLabel->resize(scaleFactor * imageLabel->pixmap()->size());

	adjustScrollBar(horizontalScrollBar(), factor);
	adjustScrollBar(verticalScrollBar(), factor);

	zoomInAct->setEnabled(scaleFactor < 5.0);
	zoomOutAct->setEnabled(scaleFactor > 0.2);
}

void GraphWindow::adjustScrollBar(QScrollBar *scrollBar, double factor)
{
	scrollBar->setValue(int(factor * scrollBar->value()
		+ (factor - 1) * scrollBar->pageStep() / 2));
}


void GraphWindow::setCurrentFile(const QString &fileName)
{
	file = QFileInfo(fileName).canonicalFilePath();
}
