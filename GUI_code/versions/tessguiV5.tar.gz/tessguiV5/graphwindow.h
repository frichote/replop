#ifndef GRAPHWINDOW_H
#define GRAPHWINDOW_H

#include <QScrollArea>
#include <QPrinter>

class QAction;
class QLabel;
class QMenu;
class QScrollBar;

class GraphWindow : public QScrollArea
{
    Q_OBJECT

public:
    GraphWindow(QWidget *parent = 0);
    ~GraphWindow();

	QString currentFile()
	{
		return file;
	}

	bool loadFile(const QString &fileName);

protected:
	void mousePressEvent(QMouseEvent *event);

private slots:
	void print();

	void zoomIn();
	void zoomOut();
	void normalSize();
	void fitToWindow();

private:
	void createActions();
	void createMenus();
	void updateActions();
	void scaleImage(double factor);
	void adjustScrollBar(QScrollBar *scrollBar, double factor);

	QLabel *imageLabel;
	double scaleFactor;

	QPrinter printer;

	QAction *printAct;
	QAction *exitAct;

	QAction *zoomInAct;
	QAction *zoomOutAct;
	QAction *normalSizeAct;
	QAction *fitToWindowAct;

	QMenu *fileMenu;
	QMenu *viewMenu;

private:
	void setCurrentFile(const QString &fileName);
	QString file;
};

#endif // GRAPHWINDOW_H
