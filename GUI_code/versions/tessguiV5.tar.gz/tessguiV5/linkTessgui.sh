#!/bin/sh

install_name_tool -change libchartdir.5.dylib @executable_path/../Frameworks/libchartdir.5.dylib ./tessgui.app/Contents/MacOS/tessgui

install_name_tool -change libchartdir.5.dylib @executable_path/../Frameworks/libchartdir.5.dylib ./tessgui.app/Contents/MacOS/tessm


install_name_tool -change libchartdir.5.dylib @executable_path/../Frameworks/libchartdir.5.dylib ./tessgui.app/Contents/MacOS/tessmAdmBYM

install_name_tool -change libchartdir.5.dylib @executable_path/../Frameworks/libchartdir.5.dylib ./tessgui.app/Contents/MacOS/tessmAdmCAR



install_name_tool -id @executable_path/../Frameworks/libQtCore.4.dylib ./tessgui.app/Contents/Frameworks/libQtCore.4.dylib

install_name_tool -id @executable_path/../Frameworks/libQtGui.4.dylib ./tessgui.app/Contents/Frameworks/libQtGui.4.dylib

install_name_tool -change /usr/local/Trolltech/Qt-4.6.0/lib/libQtGui.4.dylib @executable_path/../Frameworks/libQtGui.4.dylib ./tessgui.app/Contents/MacOS/tessgui

install_name_tool -change /usr/local/Trolltech/Qt-4.6.0/lib/libQtCore.4.dylib @executable_path/../Frameworks/libQtCore.4.dylib ./tessgui.app/Contents/MacOS/tessgui

install_name_tool -change /usr/local/Trolltech/Qt-4.6.0/lib/libQtCore.4.dylib @executable_path/../Frameworks/libQtCore.4.dylib ./tessgui.app/Contents/Frameworks/libQtGui.4.dylib



install_name_tool -id @executable_path/../Frameworks/libstdc++.6.dylib ./tessgui.app/Contents/Frameworks/libstdc++.6.dylib
# 
install_name_tool -change /usr/lib/libstdc++.6.dylib @executable_path/../Frameworks/libstdc++.6.dylib ./tessgui.app/Contents/MacOS/tessgui
install_name_tool -change /usr/lib/libstdc++.6.dylib @executable_path/../Frameworks/libstdc++.6.dylib ./tessgui.app/Contents/MacOS/tessm
install_name_tool -change /usr/lib/libstdc++.6.dylib @executable_path/../Frameworks/libstdc++.6.dylib ./tessgui.app/Contents/MacOS/tessmAdmBYM
install_name_tool -change /usr/lib/libstdc++.6.dylib @executable_path/../Frameworks/libstdc++.6.dylib ./tessgui.app/Contents/MacOS/tessmAdmCAR
# 
install_name_tool -change /usr/lib/libstdc++.6.dylib @executable_path/../Frameworks/libstdc++.6.dylib ./tessgui.app/Contents/Frameworks/libchartdir.5.dylib
install_name_tool -change /usr/lib/libstdc++.6.dylib @executable_path/../Frameworks/libstdc++.6.dylib ./tessgui.app/Contents/Frameworks/libQtCore.4.dylib
install_name_tool -change /usr/lib/libstdc++.6.dylib @executable_path/../Frameworks/libstdc++.6.dylib ./tessgui.app/Contents/Frameworks/libQtGui.4.dylib

# install_name_tool -id @executable_path/../Frameworks/libgcc_s.1.dylib ./tessgui.app/Contents/Frameworks/libgcc_s.1.dylib
# 
# install_name_tool -change /usr/lib/libgcc_s.1.dylib @executable_path/../Frameworks/libgcc_s.1.dylib ./tessgui.app/Contents/MacOS/tessgui
# install_name_tool -change /usr/lib/libgcc_s.1.dylib @executable_path/../Frameworks/libgcc_s.1.dylib ./tessgui.app/Contents/MacOS/tessm
# install_name_tool -change /usr/lib/libgcc_s.1.dylib @executable_path/../Frameworks/libgcc_s.1.dylib ./tessgui.app/Contents/MacOS/tessmAdmBYM
# install_name_tool -change /usr/lib/libgcc_s.1.dylib @executable_path/../Frameworks/libgcc_s.1.dylib ./tessgui.app/Contents/MacOS/tessmAdmCAR
# 
# 
# install_name_tool -id @executable_path/../Frameworks/libSystem.B.dylib ./tessgui.app/Contents/Frameworks/libSystem.B.dylib
# 
# install_name_tool -change /usr/lib/libSystem.B.dylib @executable_path/../Frameworks/libSystem.B.dylib ./tessgui.app/Contents/MacOS/tessgui
# install_name_tool -change /usr/lib/libSystem.B.dylib @executable_path/../Frameworks/libSystem.B.dylib ./tessgui.app/Contents/MacOS/tessm
# install_name_tool -change /usr/lib/libSystem.B.dylib @executable_path/../Frameworks/libSystem.B.dylib ./tessgui.app/Contents/MacOS/tessmAdmBYM
# install_name_tool -change /usr/lib/libSystem.B.dylib @executable_path/../Frameworks/libSystem.B.dylib ./tessgui.app/Contents/MacOS/tessmAdmCAR





