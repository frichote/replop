#include <QtGui/QApplication>
#include "tessgui.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TESSGUI w;
	w.showMaximized();
    a.connect(&a, SIGNAL(lastWindowClosed()), &a, SLOT(quit()));
    return a.exec();
}
