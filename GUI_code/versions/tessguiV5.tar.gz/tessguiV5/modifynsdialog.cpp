#include <algorithm>
#include <cmath>
#include <QtGui>
#include "modifynsdialog.h"
#include "title.h"

using namespace std;

ModifyNSDialog::ModifyNSDialog(QWidget *parent)
    : QDialog(parent)
{
	setWindowTitle(tr("Modify Neighborhood System"));
	
	QLabel *caiLabel = new QLabel(tr("Choose An Individual:"));
	caiComboBox = new QComboBox;
	QVBoxLayout *caiLayout = new QVBoxLayout;
	caiLayout->addWidget(caiLabel);
	caiLayout->addWidget(caiComboBox);
// 	QHBoxLayout *caiBigLayout = new QHBoxLayout;

	QLabel *nLabel = new QLabel(tr("Neighbors:"));
	nListWidget = new QListWidget;
	nListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
	QVBoxLayout *nLayout = new QVBoxLayout;
	nLayout->addWidget(nLabel);
	nLayout->addWidget(nListWidget);

	n2rPushButton = new QPushButton(tr("->"));
	n2rPushButton->setAutoDefault(false);
	r2nPushButton = new QPushButton(tr("<-"));
	r2nPushButton->setAutoDefault(false);
	QVBoxLayout *nnrLayout = new QVBoxLayout;
	nnrLayout->addWidget(n2rPushButton);
	nnrLayout->addWidget(r2nPushButton);

	QLabel *rLabel = new QLabel(tr("Removal List:"));
	rListWidget = new QListWidget;
	rListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
	QVBoxLayout *rLayout = new QVBoxLayout;
	rLayout->addWidget(rLabel);
	rLayout->addWidget(rListWidget);

	QLabel *cLabel = new QLabel(tr("Candidates:"));
	cListWidget = new QListWidget;
	cListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
	QVBoxLayout *cLayout = new QVBoxLayout;
	cLayout->addWidget(cLabel);
	cLayout->addWidget(cListWidget);

	c2aPushButton = new QPushButton(tr("->"));
	c2aPushButton->setAutoDefault(false);
	a2cPushButton = new QPushButton(tr("<-"));
	a2cPushButton->setAutoDefault(false);
	QVBoxLayout *cnaLayout = new QVBoxLayout;
	cnaLayout->addWidget(c2aPushButton);
	cnaLayout->addWidget(a2cPushButton);

	QLabel *aLabel = new QLabel(tr("Addition List:"));
	aListWidget = new QListWidget;
	aListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
	QVBoxLayout *aLayout = new QVBoxLayout;
	aLayout->addWidget(aLabel);
	aLayout->addWidget(aListWidget);

	QGridLayout *inputLayout = new QGridLayout;
	inputLayout->addLayout(caiLayout, 0, 0);
	inputLayout->addLayout(nLayout, 1, 0);
	inputLayout->addLayout(nnrLayout, 1, 1);
	inputLayout->addLayout(rLayout, 1, 2);
	inputLayout->addLayout(cLayout, 1, 3);
	inputLayout->addLayout(cnaLayout, 1, 4);
	inputLayout->addLayout(aLayout, 1, 5);

	okPushButton = new QPushButton(tr("OK"));
	applyPushButton = new QPushButton(tr("Apply"));
	cancelPushButton = new QPushButton(tr("Cancel"));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch();
	buttonLayout->addWidget(okPushButton);
	buttonLayout->addStretch();
	buttonLayout->addWidget(applyPushButton);
	buttonLayout->addStretch();
	buttonLayout->addWidget(cancelPushButton);
	buttonLayout->addStretch();

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(inputLayout);
	mainLayout->addStretch();
	mainLayout->addSpacing(5);
	mainLayout->addLayout(buttonLayout);

	setLayout(mainLayout);

	connect(caiComboBox, SIGNAL(activated(int)), this, SLOT(itemActivated(int)));
	connect(n2rPushButton, SIGNAL(clicked()), this, SLOT(n2rClicked()));
	connect(r2nPushButton, SIGNAL(clicked()), this, SLOT(r2nClicked()));
	connect(c2aPushButton, SIGNAL(clicked()), this, SLOT(c2aClicked()));
	connect(a2cPushButton, SIGNAL(clicked()), this, SLOT(a2cClicked()));
	connect(okPushButton, SIGNAL(clicked()), this, SLOT(okClicked()));
	connect(applyPushButton, SIGNAL(clicked()), this, SLOT(applyClicked()));
	connect(cancelPushButton, SIGNAL(clicked()), this, SLOT(cancelClicked()));
}

ModifyNSDialog::~ModifyNSDialog()
{
}

void ModifyNSDialog::show()
{
	caiComboBox->clear();

	nListWidget->clear();
	rListWidget->clear();
	cListWidget->clear();
	aListWidget->clear();

	numDigits = int(log10(double(N)) + 1);
	for (int i = 0; i < N; i++)
	{
		// Make sure the first index is 1 not 0.
		caiComboBox->addItem(QString("%1").arg(i + 1, numDigits, 10, QChar('0')));
	}
	CVoronoi::LoadVoronoi(vptC, vbKeep, vdDataMinMax, vdDataScale, veVoronoi, vvnNS, 
		c.toAscii().constData());
	vvnNSOriginal = vvnNS;
	nOld = -1;
	updateButtons();

	return QDialog::show();
}

void ModifyNSDialog::closeEvent(QCloseEvent *event)
{
	event->accept();
	emit finished();
}

void ModifyNSDialog::keyPressEvent(QKeyEvent *event)
{
	if (event->key() == Qt::Key_Escape)
	{
		close();
	}
}

void ModifyNSDialog::itemActivated(int nNew)
{
	if (nNew == nOld)
	{
		return;
	}
	else
	{
		if (rListWidget->count() || aListWidget->count())
		{
			if (QMessageBox::Yes == QMessageBox::question(this, GUI_TITLE, 
				tr("Neighborhood system changed!\nDo you want to apply your changes?"), 
				QMessageBox::Yes, QMessageBox::No))
			{
				applyClicked();
			}
		}

		nListWidget->clear();
		int i;
		for (i = 0; i < int(vvnNS[nNew].size()); i++)
		{
			// Make sure the first index is 1 not 0.
			nListWidget->addItem(QString("%1")
				.arg(vvnNS[nNew][i] + 1, numDigits, 10, QChar('0')));
		}
		nListWidget->sortItems();
		rListWidget->clear();

		cListWidget->clear();
		for (i = 0; i < N; i++)
		{
			// Make sure the first index is 1 not 0.
			cListWidget->addItem(QString("%1").arg(i + 1, numDigits, 10, QChar('0')));
		}
		vector< int > vnNnI = vvnNS[nNew];
		vnNnI.push_back(nNew);
		sort(vnNnI.begin(), vnNnI.end());
		for (i = int(vnNnI.size()) - 1; i > -1; i--)
		{
			delete cListWidget->takeItem(vnNnI[i]);
		}
		cListWidget->sortItems();
		aListWidget->clear();

		nOld = nNew;

		updateButtons();
	}
}

void ModifyNSDialog::n2rClicked()
{
	QList<QListWidgetItem *> selectedItems = nListWidget->selectedItems();
	for (int i = 0; i < selectedItems.size(); i++)
	{
		rListWidget->addItem(
			nListWidget->takeItem(nListWidget->row(selectedItems.at(i))));
	}
	nListWidget->sortItems();
	rListWidget->sortItems();

	updateButtons();
}

void ModifyNSDialog::r2nClicked()
{
	QList<QListWidgetItem *> selectedItems = rListWidget->selectedItems();
	for (int i = 0; i < selectedItems.size(); i++)
	{
		nListWidget->addItem(
			rListWidget->takeItem(rListWidget->row(selectedItems.at(i))));
	}
	rListWidget->sortItems();
	nListWidget->sortItems();

	updateButtons();
}

void ModifyNSDialog::c2aClicked()
{
	QList<QListWidgetItem *> selectedItems = cListWidget->selectedItems();
	for (int i = 0; i < selectedItems.size(); i++)
	{
		aListWidget->addItem(
			cListWidget->takeItem(cListWidget->row(selectedItems.at(i))));
	}
	cListWidget->sortItems();
	aListWidget->sortItems();

	updateButtons();
}

void ModifyNSDialog::a2cClicked()
{
	QList<QListWidgetItem *> selectedItems = aListWidget->selectedItems();
	for (int i = 0; i < selectedItems.size(); i++)
	{
		cListWidget->addItem(
			aListWidget->takeItem(aListWidget->row(selectedItems.at(i))));
	}
	aListWidget->sortItems();
	cListWidget->sortItems();

	updateButtons();
}

void ModifyNSDialog::okClicked()
{
	close();

	if (rListWidget->count() || aListWidget->count())
	{
		applyClicked();
	}

	if (vvnNS != vvnNSOriginal)
	{
		CVoronoi::DrawNeighborhoodSystem(vptC, vdDataScale, vvnNS, true, 
			n.toAscii().data());
		CVoronoi::SaveVoronoi(vptC, vbKeep, vdDataMinMax, vdDataScale, veVoronoi, vvnNS, 
			c.toAscii().constData());
		emit modified();
	}
}

void ModifyNSDialog::applyClicked()
{
	rListWidget->selectAll();
	QList<QListWidgetItem *> rSelectedItems = rListWidget->selectedItems();
	int rNum = rSelectedItems.size();
	if (rNum > 0)
	{
		for (int i = 0; i < rNum; i++)
		{
			cListWidget->addItem(
				rListWidget->takeItem(rListWidget->row(rSelectedItems.at(i))));
			// Make sure the first index is 0 not 1.
			int neighbor = rSelectedItems.at(i)->data(Qt::DisplayRole).toInt() - 1;
			vector <int>::iterator newEnd;
			newEnd = remove(vvnNS[nOld].begin(), vvnNS[nOld].end(), neighbor);
			vvnNS[nOld].erase(newEnd, vvnNS[nOld].end());
			newEnd = remove(vvnNS[neighbor].begin(), vvnNS[neighbor].end(), nOld);
			vvnNS[neighbor].erase(newEnd, vvnNS[neighbor].end());
		}
	}
	cListWidget->sortItems();

	aListWidget->selectAll();
	QList<QListWidgetItem *> aSelectedItems = aListWidget->selectedItems();
	int aNum = aSelectedItems.size();
	if (aNum > 0)
	{
		for (int i = 0; i < aNum; i++)
		{
			nListWidget->addItem(
				aListWidget->takeItem(aListWidget->row(aSelectedItems.at(i))));
			// Make sure the first index is 0 not 1.
			int neighbor = aSelectedItems.at(i)->data(Qt::DisplayRole).toInt() - 1;
			vvnNS[nOld].push_back(neighbor);
			vvnNS[neighbor].push_back(nOld);
		}
	}
	nListWidget->sortItems();

	updateButtons();
}

void ModifyNSDialog::cancelClicked()
{
	close();
}

void ModifyNSDialog::updateButtons()
{
	n2rPushButton->setEnabled(nListWidget->count());
	r2nPushButton->setEnabled(rListWidget->count());
	c2aPushButton->setEnabled(cListWidget->count());
	a2cPushButton->setEnabled(aListWidget->count());

	applyPushButton->setEnabled(rListWidget->count() || aListWidget->count());
}
