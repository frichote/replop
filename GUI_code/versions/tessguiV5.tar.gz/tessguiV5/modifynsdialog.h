#ifndef MODIFYNSDIALOG_H
#define MODIFYNSDIALOG_H

#include <QDialog>

class QCloseEvent;
class QComboBox;
class QListWidget;
class QPushButton;

#include "Voronoi.h"

class ModifyNSDialog : public QDialog
{
    Q_OBJECT

public:
    ModifyNSDialog(QWidget *parent = 0);
    ~ModifyNSDialog();

	int N;
	int numDigits;
	int nOld;
	QString n;
	QString c;

signals:
	void finished();
	void modified();

public slots:
	void show();

protected:
	void closeEvent(QCloseEvent *event);
	void keyPressEvent(QKeyEvent *event);

private slots:
	void itemActivated(int nNew);
	void n2rClicked();
	void r2nClicked();
	void c2aClicked();
	void a2cClicked();
	void okClicked();
	void applyClicked();
	void cancelClicked();

private:
	void updateButtons();

	QComboBox *caiComboBox;

	QListWidget *nListWidget;
	QListWidget *rListWidget;
	QListWidget *cListWidget;
	QListWidget *aListWidget;

	QPushButton *n2rPushButton;
	QPushButton *r2nPushButton;
	QPushButton *c2aPushButton;
	QPushButton *a2cPushButton;

	QPushButton *okPushButton;
	QPushButton *applyPushButton;
	QPushButton *cancelPushButton;

	vector< SPoint > vptC;
	vector< bool > vbKeep;
	vector< double > vdDataMinMax;
	vector< double > vdDataScale;
	vector< CEdge > veVoronoi;
	vector< vector< int > > vvnNS;
	vector< vector< int > > vvnNSOriginal;
};

#endif // MODIFYNSDIALOG_H
