#include <QtCore>
#include <QtGui>
#include "newprojectdialog.h"
#include "datawindow.h"
#include "title.h"

NewProjectDialog::NewProjectDialog(QWidget *parent)
    : QDialog(parent)
{
	setWindowTitle(tr("New Project"));

	QLabel *nameLabel = new QLabel(tr("Project Name:"));
	nameLineEdit = new QLineEdit;

	QLabel *pathLabel = new QLabel(tr("Project Path:"));
	pathLineEdit = new QLineEdit;

	QPushButton *browsePathPushButton = new QPushButton(tr("Browse..."));
	browsePathPushButton->setAutoDefault(false);
	connect(browsePathPushButton, SIGNAL(clicked()), this, SLOT(browsePath()));

	QLabel *dataLabel = new QLabel(tr("Project Data:"));
	dataLineEdit = new QLineEdit;
	connect(dataLineEdit, SIGNAL(textChanged(const QString &)), 
		this, SLOT(dataChanged()));

	QPushButton *browseDataPushButton = new QPushButton(tr("Browse..."));
	browseDataPushButton->setAutoDefault(false);
	connect(browseDataPushButton, SIGNAL(clicked()), this, SLOT(browseData()));

	QLabel *geoDataLabel = new QLabel(tr("Geographic Distance File (optional):"));
	geoDataLineEdit = new QLineEdit;
	connect(geoDataLineEdit, SIGNAL(textChanged(const QString &)), 
		this, SLOT(geoDataChanged()));
	
	QPushButton *browseGeoDataPushButton = new QPushButton(tr("Browse..."));
	browseGeoDataPushButton->setAutoDefault(false);
	connect(browseGeoDataPushButton, SIGNAL(clicked()), this, SLOT(browseGeoData()));
	
	QGridLayout *projectInfoLayout = new QGridLayout;
	projectInfoLayout->addWidget(nameLabel, 0, 0);
	projectInfoLayout->addWidget(nameLineEdit, 0, 1);
	projectInfoLayout->addWidget(pathLabel, 1, 0);
	projectInfoLayout->addWidget(pathLineEdit, 1, 1);
	projectInfoLayout->addWidget(browsePathPushButton, 1, 2);
	projectInfoLayout->addWidget(dataLabel, 2, 0);
	projectInfoLayout->addWidget(dataLineEdit, 2, 1);
	projectInfoLayout->addWidget(browseDataPushButton, 2, 2);
	projectInfoLayout->addWidget(geoDataLabel, 3, 0);
	projectInfoLayout->addWidget(geoDataLineEdit, 3, 1);
	projectInfoLayout->addWidget(browseGeoDataPushButton, 3, 2);
	

	QFrame *dataInfoFrame = new QFrame;
	dataInfoFrame->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	viewDataPushButton = new QPushButton(tr("View Data..."));
	viewDataPushButton->setAutoDefault(false);
	viewDataPushButton->setEnabled(false);
	connect(viewDataPushButton, SIGNAL(clicked()), this, SLOT(viewData()));
	
	viewGeoDataPushButton = new QPushButton(tr("View Geographic Data..."));
	viewGeoDataPushButton->setAutoDefault(false);
	viewGeoDataPushButton->setEnabled(false);
	connect(viewGeoDataPushButton, SIGNAL(clicked()), this, SLOT(viewGeoData()));
	

	QLabel *nLabel = new QLabel(tr("Number of Individuals:"));
	nLineEdit = new QLineEdit;
	QIntValidator *nV = new QIntValidator(this);
	nV->setBottom(1);
	nLineEdit->setValidator(nV);

	QLabel *dLabel = new QLabel(tr("Number of Dummy Individuals:"));
	dLineEdit = new QLineEdit;
	dLineEdit->setText(tr("0"));
	QIntValidator *dV = new QIntValidator(this);
	dV->setBottom(0);
	dLineEdit->setValidator(dV);

	QLabel *aLabel = new QLabel(tr("Ploidy:"));
	aLineEdit = new QLineEdit;
	aLineEdit->setText(tr("2"));
	QIntValidator *aV = new QIntValidator(this);
	aV->setBottom(1);
	aLineEdit->setValidator(aV);

	QLabel *lLabel = new QLabel(tr("Number of Loci:"));
	lLineEdit = new QLineEdit;
	QIntValidator *lV = new QIntValidator(this);
	lV->setBottom(1);
	lLineEdit->setValidator(lV);

	QLabel *mLabel = new QLabel(tr("Missing Data Value:"));
	mLineEdit = new QLineEdit;
	mLineEdit->setText(tr("-9"));
	QIntValidator *mV = new QIntValidator(this);
	mV->setTop(-1);
	mLineEdit->setValidator(mV);

	specialCheckBox = new QCheckBox(tr("Data Stored in One Line per Individual Format"));
	recessiveCheckBox = new QCheckBox(tr("Row of recessive alleles (diploid individuals only)"));


	QLabel *rLabel = new QLabel(tr("Number of Extra Rows:"));
	rLineEdit = new QLineEdit;
	rLineEdit->setText(tr("0"));
	QIntValidator *rV = new QIntValidator(this);
	rV->setBottom(0);
	rLineEdit->setValidator(rV);

	QLabel *cLabel = new QLabel(tr("Number of Extra Columns:"));
	cLineEdit = new QLineEdit;
	cLineEdit->setText(tr("0"));
	QIntValidator *cV = new QIntValidator(this);
	cV->setBottom(0);
	cLineEdit->setValidator(cV);


	QGridLayout *dataInfoLayout = new QGridLayout;
	dataInfoLayout->addWidget(viewDataPushButton, 0, 0);
	dataInfoLayout->addWidget(viewGeoDataPushButton, 0, 1);
	dataInfoLayout->addWidget(nLabel, 1, 0);
	dataInfoLayout->addWidget(nLineEdit, 1, 1);
	dataInfoLayout->addWidget(dLabel, 2, 0);
	dataInfoLayout->addWidget(dLineEdit, 2, 1);
	dataInfoLayout->addWidget(aLabel, 3, 0);
	dataInfoLayout->addWidget(aLineEdit, 3, 1);
	dataInfoLayout->addWidget(lLabel, 4, 0);
	dataInfoLayout->addWidget(lLineEdit, 4, 1);
	dataInfoLayout->addWidget(mLabel, 5, 0);
	dataInfoLayout->addWidget(mLineEdit, 5, 1);
	dataInfoLayout->addWidget(specialCheckBox, 6, 0, 1, 2);
	dataInfoLayout->addWidget(recessiveCheckBox, 7, 0, 1, 2);
	dataInfoLayout->addWidget(rLabel, 8, 0);
	dataInfoLayout->addWidget(rLineEdit, 8, 1);
	dataInfoLayout->addWidget(cLabel, 9, 0);
	dataInfoLayout->addWidget(cLineEdit, 9, 1);

	QPushButton *okPushButton = new QPushButton(tr("OK"));
	okPushButton->setDefault(true);
	connect(okPushButton, SIGNAL(clicked()), this, SLOT(accept()));

	QPushButton *cancelPushButton = new QPushButton(tr("Cancel"));
	connect(cancelPushButton, SIGNAL(clicked()), this, SLOT(reject()));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch();
	buttonLayout->addWidget(okPushButton);
	buttonLayout->addStretch();
	buttonLayout->addWidget(cancelPushButton);
	buttonLayout->addStretch();

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(projectInfoLayout);
	mainLayout->addWidget(dataInfoFrame);
	mainLayout->addLayout(dataInfoLayout);
//	mainLayout->addWidget(dataFormatFrame);
//	mainLayout->addLayout(dataFormatLayout);
	mainLayout->addStretch();
	mainLayout->addSpacing(5);
	mainLayout->addLayout(buttonLayout);

	setLayout(mainLayout);
}

NewProjectDialog::~NewProjectDialog()
{
}

void NewProjectDialog::accept()
{
	if (validate())
	{
		QDialog::accept();
	}
}

void NewProjectDialog::browsePath()
{
	QString path = QFileDialog::getExistingDirectory(this, 
		tr("Choose Project Path"), projectPath);
	if (path.endsWith('/') || path.endsWith('\\'))
	{
		path = path.left(path.length() - 1);
	}
	if (!path.isEmpty())
	{
		pathLineEdit->setText(path);
		projectPath = path;
	}
}

void NewProjectDialog::browseData()
{
	QString data = QFileDialog::getOpenFileName(this, 
		tr("Choose Project Data File"), projectPath);
	if (!data.isEmpty())
	{
		dataLineEdit->setText(data);
		projectPath = QFileInfo(data).absolutePath();
	}
}

void NewProjectDialog::browseGeoData()
{
	QString data = QFileDialog::getOpenFileName(this, 
			tr("Choose Geographic Distances File"), projectPath);
	if (!data.isEmpty())
	{
		geoDataLineEdit->setText(data);
	}
}

void NewProjectDialog::geoDataChanged()
{
	viewGeoDataPushButton->setEnabled(!geoDataLineEdit->text().isEmpty());
}

void NewProjectDialog::dataChanged()
{
	viewDataPushButton->setEnabled(!dataLineEdit->text().isEmpty());
}

void NewProjectDialog::viewGeoData()
{
	if (!QFile::exists(dataLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
				     tr("The specified geographic distances file does not exist."));
		return;
	}

	QDialog *geoDataDialog = new QDialog;
	geoDataDialog->setAttribute(Qt::WA_DeleteOnClose);
	geoDataDialog->setWindowTitle(tr("Geographic Distances File"));
	DataWindow *dataWidget = new DataWindow;
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(dataWidget);
	geoDataDialog->setLayout(mainLayout);
	geoDataDialog->resize(480, 320);
	if (dataWidget->loadFile(geoDataLineEdit->text()))
	{
		geoDataDialog->exec();	
	}
	else
	{
		geoDataDialog->close();
	}
}

void NewProjectDialog::viewData()
{
	if (!QFile::exists(dataLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified project data does not exist."));
		return;
	}

	QDialog *dataDialog = new QDialog(this,Qt::WindowTitleHint);
	dataDialog->setAttribute(Qt::WA_DeleteOnClose);
	dataDialog->setWindowTitle(tr("Project Data"));
	// dataDialog->setWindowFlags(Qt::WindowSystemMenuHint & Qt::WindowCloseButtonHint);
	// Qt::WindowSystemMenuHint && 
	// setWindowFlags(Qt::Tool);
	DataWindow *dataWidget = new DataWindow;
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(dataWidget);
	dataDialog->setLayout(mainLayout);
	dataDialog->resize(480, 320);
	if (dataWidget->loadFile(dataLineEdit->text()))
	{
		dataDialog->exec();	
	}
	else
	{
		dataDialog->close();
	}
}

bool NewProjectDialog::validate()
{
	if (nameLineEdit->text().isEmpty())
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Project name cannot be empty."));
		return false;
	}

	QDir path(pathLineEdit->text());
	if (pathLineEdit->text().isEmpty() || !path.exists())
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified project path does not exist."));
		return false;
	}

	if (QFile::exists(pathLineEdit->text() + "/" + nameLineEdit->text() + ".tp"))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("A project with same name already exists.\n"
			"Please change the name of your project."));
		return false;
	}

	if (!geoDataLineEdit->text().isEmpty() && !QFile::exists(geoDataLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
				     tr("The specified geographic distances file does not exist."));
		return false;
	}
	
	if (dataLineEdit->text().isEmpty() || !QFile::exists(dataLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified project data does not exist."));
		return false;
	}

	QFileInfo dataInfo(dataLineEdit->text());
	if (path != dataInfo.absoluteDir())
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("Please put data in the project directory."));
		return false;
	}

	QString nText = nLineEdit->text();
	int nPos = 0;
	if (nLineEdit->validator()->validate(nText, nPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Individuals"));
		return false;
	}

	QString dText = dLineEdit->text();
	int dPos = 0;
	if (dLineEdit->validator()->validate(dText, dPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Dummy Individuals"));
		return false;
	}

	QString aText = aLineEdit->text();
	int aPos = 0;
	if (aLineEdit->validator()->validate(aText, aPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Ploidy"));
		return false;
	}
	
	if (recessiveCheckBox->isChecked() && aText.toInt() != 2)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Recessive alleles option available for diploid individuals only"));
		return false;
	}

	QString lText = lLineEdit->text();
	int lPos = 0;
	if (lLineEdit->validator()->validate(lText, lPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Loci"));
		return false;
	}

	QString mText = mLineEdit->text();
	int mPos = 0;
	if (mLineEdit->validator()->validate(mText, mPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("Please use a negative integer to represent missing data."));
		return false;
	}

	QString rText = rLineEdit->text();
	int rPos = 0;
	if (rLineEdit->validator()->validate(rText, rPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Extra Rows"));
		return false;
	}

	QString cText = cLineEdit->text();
	int cPos = 0;
	if (cLineEdit->validator()->validate(cText, cPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Extra Columns"));
		return false;
	}

	// Checking Geographic file dimension
	int sGeoRows = nLineEdit->text().toInt();
	if (!geoDataLineEdit->text().isEmpty())
	{
		QList< int > formatGeo = dataFormat(geoDataLineEdit->text());
		int eGeoRows = formatGeo.size();
		if (sGeoRows != eGeoRows)
		{
			QMessageBox::warning(this, GUI_TITLE, QString(tr(
						     "According to your input, there should be totally %1 rows in the geographic data file,\n"
						     "but I detected that there are actually %2 rows.\n\n"
						     "Please check whether you have correctly input:\n"
						     "Number of Individuals\n"
						     "Geographic File\n"
						     )).arg(sGeoRows).arg(eGeoRows));
			return false;
		}
	}
		
	// Specified Total Number of Rows
	int sRows;
	int rec;
	if (recessiveCheckBox->isChecked())
	{
		rec = 1;
	}
	else
	{
		rec = 0;
	}
	if (!specialCheckBox->isChecked())
	{
		// A-ploids individuals stored on A lines.
		sRows = rec + rLineEdit->text().toInt() + aLineEdit->text().toInt() * 
				(nLineEdit->text().toInt() + dLineEdit->text().toInt());
	}
	else
	{
		// individuals stored on one line.
		sRows = rec + rLineEdit->text().toInt() + nLineEdit->text().toInt() + dLineEdit->text().toInt();
	}
	
	QList< int > format = dataFormat(dataLineEdit->text());
	// Expected Total Number of Rows
	int eRows = format.size();
	if (sRows != eRows)
	{
		QMessageBox::warning(this, GUI_TITLE, QString(tr(
				     "According to your input, there should be totally %1 rows in the data file,\n"
						     "but I detected that there are actually %2 rows.\n\n"
						     "Please check whether you have correctly input:\n"
						     "Number of Individuals\n"
						     "Number of Dummy Individuals\n"
						     "Ploidy\n"
						     "Number of Extra Rows")).arg(sRows).arg(eRows));
		return false;
	}
	
	// Specified Total Number of Columns (Two Columns for XY Coordinates)
	int sCols;
	if (!specialCheckBox->isChecked())
	{
		// One column per locus
		sCols = cLineEdit->text().toInt() + 2 + lLineEdit->text().toInt();
	}
	else
	{
		// A column(s) per locus for A ploids individuals
		sCols = cLineEdit->text().toInt() + 2 + aLineEdit->text().toInt() * lLineEdit->text().toInt();
	}
	
	// Expected Total Number of Columns
	int eCols;
	for (int i = (rec+rLineEdit->text().toInt()); i < eRows; i++)
	{
		eCols = format.at(i);
		if (sCols != eCols)
		{
			QMessageBox::warning(this, GUI_TITLE, QString(tr(
				"According to your input, there should be %1 columns in data area,\n"
				"but I detected that there are actually %2 columns.\n\n"
				"Please check whether you have correctly input:\n"
				"Number of Loci\n"
				"Data Containing Information for Association Mapping Test\n"
				"Number of Extra Columns\n"
				"Number of Extra Rows")).arg(sCols).arg(eCols));
			return false;
		}
	}
	return true;
}

const QList< int > &NewProjectDialog::dataFormat(const QString &data)
{
	static QList< int > format;
	format.clear();

	QFile file(data);
	if (!file.open(QFile::ReadOnly | QFile::Text)) 
	{
		QMessageBox::warning(this, GUI_TITLE,
			tr("Cannot verify data file %1!").arg(data));
		return format;
	}
	QTextStream in(&file);
	QRegExp reWC("\\w");  // Word Character
	QRegExp regExp("\\s+|\\t+");  // Space(s) or Tab(s)
	QString oneRow;
	QStringList oneRowList;
	QApplication::setOverrideCursor(Qt::WaitCursor);
	while (!(oneRow = in.readLine()).isNull())
	{
		if (oneRow.contains(reWC))
		{
			oneRowList = oneRow.split(regExp, QString::SkipEmptyParts);
			format.append(oneRowList.size());
		}
	}
	QApplication::restoreOverrideCursor();
	file.close();

	return format;
}
