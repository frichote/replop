#ifndef NEWPROJECTDIALOG_H
#define NEWPROJECTDIALOG_H

#include <QDialog>
#include <QList>

class QCheckBox;
class QLineEdit;
class QPushButton;

class NewProjectDialog : public QDialog
{
    Q_OBJECT

public:
    NewProjectDialog(QWidget *parent = 0);
    ~NewProjectDialog();

public:
	QLineEdit *nameLineEdit;
	QLineEdit *pathLineEdit;
	QLineEdit *dataLineEdit;
	QLineEdit *geoDataLineEdit;

	QLineEdit *nLineEdit;
	QLineEdit *dLineEdit;
	QLineEdit *aLineEdit;
	QLineEdit *lLineEdit;
	QLineEdit *mLineEdit;
	QCheckBox *specialCheckBox;
	QCheckBox *recessiveCheckBox;
	
	QLineEdit *rLineEdit;
	QLineEdit *cLineEdit;

protected:
	void accept();

private slots:
	void browsePath();
	void browseData();
	void browseGeoData();
	void dataChanged();
	void geoDataChanged();
	void viewData();
	void viewGeoData();
	
private:
	bool validate();
	const QList< int > &dataFormat(const QString &data);

	QPushButton *viewDataPushButton;
	QPushButton *viewGeoDataPushButton;
	QString projectPath;
};

#endif // NEWPROJECTDIALOG_H
