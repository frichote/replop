#include <QtCore>
#include <QtGui>
#include "newrundialog.h"
#include "title.h"
#include "advancedialog.h"

#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

NewRunDialog::NewRunDialog(QWidget *parent, QString oldscOption, bool hasGeo, QString oldPsi, bool oldUpdatePsi, QString oldSigma, bool oldUpdateSigma, QString oldLambda)
: QDialog(parent)
{
	
	psi = oldPsi;
	updatePsi = oldUpdatePsi;
	sigma = oldSigma;
	updateSigma = oldUpdateSigma;
	
	scOption = oldscOption;
	hasGeoData = hasGeo;	
	
	lambda = oldLambda;
	
	setWindowFlags(Qt::WindowCloseButtonHint);
    setWindowTitle(tr("New Run(s)"));

    noAdmRadioButton = new QRadioButton(tr("Without Admixture"));
        
    admRadioButton = new QRadioButton(tr("With Admixture"));
    connect(admRadioButton, SIGNAL(toggled(bool)), this, SLOT(admToggled(bool)));
    
    QHBoxLayout *typeLayout = new QHBoxLayout;
    typeLayout->addWidget(noAdmRadioButton);
    typeLayout->addWidget(admRadioButton);
    tGroupBox = new QGroupBox(tr("Level of Spatial Influence"));
    tGroupBox->setLayout(typeLayout);

	carRadioButton = new QRadioButton(tr("CAR Model"));
	bymRadioButton = new QRadioButton(tr("BYM Model"));
	
	
	QVBoxLayout *admModelLayout = new QVBoxLayout;
	admModelLayout->addWidget(bymRadioButton);
	admModelLayout->addWidget(carRadioButton);
	mGroupBox = new QGroupBox(tr("Admixture Model"));
	mGroupBox->setLayout(admModelLayout);
	
	scriptLabel = new QLabel(tr("Set Multiple Ks"));
	scriptCheckBox = new QCheckBox();
	connect(scriptCheckBox, SIGNAL(stateChanged(int)), this, SLOT(scriptStateChanged(int)));
	
        rLabel = new QLabel(tr("Number of Runs (per K):"));
        rLineEdit = new QLineEdit;
        QIntValidator *rV = new QIntValidator(this);
        rV->setBottom(1);
        rLineEdit->setValidator(rV);

        kLabel = new QLabel(tr("Maximal Number of Clusters:"));
        kLineEdit = new QLineEdit;
        QIntValidator *kV = new QIntValidator(this);
        kV->setRange(2, 216);
        kLineEdit->setValidator(kV);
	
	toKLabel = new QLabel(tr("to:"));
	toKLineEdit = new QLineEdit;
	QIntValidator *toKV = new QIntValidator(this);
	toKV->setRange(2, 216);
	toKLineEdit->setValidator(toKV);

//         pLabel = new QLabel(tr("Spatial Interaction Parameter:"));
//         pLineEdit = new QLineEdit;
//         QDoubleValidator *pV = new QDoubleValidator(this);
//         pV->setRange(0.0, 100.0, 2);
//         pLineEdit->setValidator(pV);
// 	
// 	pUpdateLabel = new QLabel(tr("Update Spatial Interaction Parameter"));
// 	pUpdateCheckBox = new QCheckBox();
	
	trendDegreeLabel = new QLabel(tr("Degree of trend:"));
	trendDegreeComboBox = new QComboBox;
	trendDegreeComboBox->addItem(QString("Constant (0)"));
	trendDegreeComboBox->addItem(QString("Linear (1)"));
	trendDegreeComboBox->addItem(QString("Quadratic (2)"));
	trendDegreeComboBox->addItem(QString("Cubic (3)"));
	
// 	sigmaLabel = new QLabel(tr("Initial CAR Variance:"));
// 	sigmaLineEdit = new QLineEdit;
// 	QDoubleValidator *sigmaV = new QDoubleValidator(this);
// 	sigmaV->setRange(0.0, 100.0, 2);
// 	sigmaLineEdit->setValidator(sigmaV);
// 	
// 	updateLabel = new QLabel(tr("Update CAR Variance"));
// 	updateCheckBox = new QCheckBox();
	
	advanced = new QPushButton(tr("Advanced Options"));
	connect(advanced, SIGNAL(clicked()), this, SLOT(advOpt()));
	
// 	dLabel = new QLabel(tr("Parameter of Allele Freq. Model:"));
//         dLineEdit = new QLineEdit;
//         QDoubleValidator *dV = new QDoubleValidator(this);
//         dV->setRange(1.0, 10.0, 2);
//         dLineEdit->setValidator(dV);

        sLabel = new QLabel(tr("Total Number of Sweeps:"));
        sLineEdit = new QLineEdit;
        QIntValidator *sV = new QIntValidator(this);
        sV->setBottom(1);
        sLineEdit->setValidator(sV);

        bLabel = new QLabel(tr("Burn In Number of Sweeps:"));
        bLineEdit = new QLineEdit;
        QIntValidator *bV = new QIntValidator(this);
        bV->setBottom(0);
        bLineEdit->setValidator(bV);

        zCheckBox = new QCheckBox(tr("Continuing Lowest DIC Run"));
	njCheckBox = new QCheckBox(tr("Start from Neighbour Joining Tree"));
	connect(njCheckBox, SIGNAL(stateChanged(int)), this, SLOT(njStateChanged(int)));
	connect(zCheckBox, SIGNAL(stateChanged(int)), this, SLOT(zStateChanged(int)));
	
	mapLabel = new QLabel(tr("Map Path:"));
	mapLineEdit = new QLineEdit;
		
	QPushButton *browseMapPushButton = new QPushButton(tr("Browse..."));
	browseMapPushButton->setAutoDefault(false);
	connect(browseMapPushButton, SIGNAL(clicked()), this, SLOT(browseData()));
	
	QGridLayout *fieldLayout = new QGridLayout;
	fieldLayout->addWidget(mapLabel,0,0);
	fieldLayout->addWidget(mapLineEdit,0,1);
	fieldLayout->addWidget(browseMapPushButton,0,2);
	predGroupBox = new QGroupBox(tr("Input Prediction Map (optional)"));
	predGroupBox->setLayout(fieldLayout);
	
	
        QGridLayout *inputLayout = new QGridLayout;
        inputLayout->addWidget(tGroupBox, 3, 0, 1, 3);
	inputLayout->addWidget(mGroupBox, 3, 3);
	inputLayout->addWidget(scriptLabel,4,0);
	inputLayout->addWidget(scriptCheckBox,4,1);
        inputLayout->addWidget(rLabel, 5, 0, 1, 1);
        inputLayout->addWidget(rLineEdit, 5, 1, 1, 3);
        inputLayout->addWidget(kLabel, 6, 0,1,1);
        inputLayout->addWidget(kLineEdit, 6, 1,1,1);
	inputLayout->addWidget(toKLabel, 6, 2, 1,1,Qt::AlignRight);
	inputLayout->addWidget(toKLineEdit, 6, 3, 1,1);
// 	inputLayout->addWidget(pLabel, 7, 0);
//         inputLayout->addWidget(pLineEdit, 7, 1, 1, 3);
// 	inputLayout->addWidget(pUpdateLabel,8,0);
// 	inputLayout->addWidget(pUpdateCheckBox,8,1);
	inputLayout->addWidget(trendDegreeLabel, 9, 0);
	inputLayout->addWidget(trendDegreeComboBox,9, 1);
// 	inputLayout->addWidget(sigmaLabel, 10, 0);
// 	inputLayout->addWidget(sigmaLineEdit, 10, 1, 1, 3);
// 	inputLayout->addWidget(updateLabel,11,0);
// 	inputLayout->addWidget(updateCheckBox,11,1);
	inputLayout->addWidget(advanced,9,3);
//         inputLayout->addWidget(dLabel, 13, 0);
// 	inputLayout->addWidget(dLineEdit, 13, 1, 1, 3);
        inputLayout->addWidget(sLabel, 14, 0);
	inputLayout->addWidget(sLineEdit, 14, 1, 1, 3);
        inputLayout->addWidget(bLabel, 15, 0);
	inputLayout->addWidget(bLineEdit, 15, 1, 1, 3);
	inputLayout->addWidget(predGroupBox, 16, 0, 1, 4);
        inputLayout->addWidget(zCheckBox, 17, 0, 1, 2);
	inputLayout->addWidget(njCheckBox, 17, 2, 1, 2);


        QPushButton *okPushButton = new QPushButton(tr("OK"));
        connect(okPushButton, SIGNAL(clicked()), this, SLOT(accept()));

        QPushButton *cancelPushButton = new QPushButton(tr("Cancel"));
        connect(cancelPushButton, SIGNAL(clicked()), this, SLOT(reject()));

        QHBoxLayout *buttonLayout = new QHBoxLayout;
        buttonLayout->addStretch();
        buttonLayout->addWidget(okPushButton);
        buttonLayout->addStretch();
        buttonLayout->addWidget(cancelPushButton);
        buttonLayout->addStretch();

        QVBoxLayout *mainLayout = new QVBoxLayout;
        mainLayout->addLayout(inputLayout);
        mainLayout->addStretch();
        mainLayout->addSpacing(5);
        mainLayout->addLayout(buttonLayout);

        setLayout(mainLayout);
}

NewRunDialog::~NewRunDialog()
{
}

void NewRunDialog::accept()
{
        if (validate())
        {
                QDialog::accept();
        }
}

void NewRunDialog::zStateChanged(int state)
{
	bool checked = state == Qt::Checked;
	if (checked)
	{
		njCheckBox->setCheckState(Qt::Unchecked);
	}
}

void NewRunDialog::njStateChanged(int state)
{
	bool checked = state == Qt::Checked;
	if (checked)
	{
		zCheckBox->setCheckState(Qt::Unchecked);
	}
}


void NewRunDialog::scriptStateChanged(int state)
{
	bool checked = state == Qt::Checked;
	toKLabel->setEnabled(checked);
	toKLineEdit->setEnabled(checked);
	if (checked)
	{
		zCheckBox->setCheckState(Qt::Unchecked);
	}
	zCheckBox->setEnabled(!checked);
}

void NewRunDialog::admToggled(bool checked)
{
// 	pUpdateLabel->setEnabled(checked);
// 	pUpdateCheckBox->setEnabled(checked);
	trendDegreeLabel->setEnabled(checked);
	trendDegreeComboBox->setEnabled(checked);
// 	sigmaLabel->setEnabled(checked);
// 	sigmaLineEdit->setEnabled(checked);
// 	updateLabel->setEnabled(checked);
// 	updateCheckBox->setEnabled(checked);
	predGroupBox->setEnabled(checked);
	mGroupBox->setEnabled(checked);
	carRadioButton->setEnabled(checked);
	bymRadioButton->setEnabled(checked);
}

void NewRunDialog::advOpt()
{
	AdvancedOption *advancedoption = new AdvancedOption;
	bool admixture = admRadioButton->isChecked();
	bool bBYM = admRadioButton->isChecked() && bymRadioButton->isChecked();
	advancedoption->setState(scOption,hasGeoData,psi,updatePsi,sigma,updateSigma,admixture,bBYM,lambda);       //restore the previous user choice
	advancedoption->exec();
	
	psi = advancedoption->pLineEdit->text();
	updatePsi = advancedoption->pUpdateCheckBox->checkState() == Qt::Checked;
	sigma = advancedoption->sigmaLineEdit->text();
	updateSigma = advancedoption->updateCheckBox->checkState() == Qt::Checked;
	lambda = advancedoption->dLineEdit->text();
	
	
	if (hasGeoData)
	{
		if (advancedoption->mRadioButton->isChecked())
		{
			scOption = "m";
		}
		if (advancedoption->dRadioButton->isChecked())
		{
			scOption = "d";
		}
		if (advancedoption->xRadioButton->isChecked())
		{
			scOption = "x";
		}
		if (advancedoption->uRadioButton->isChecked())
		{
			scOption = advancedoption->uLineEdit->text();;
		}
	}
	delete advancedoption;
}

void NewRunDialog::browseData()
{
	QString data = QFileDialog::getOpenFileName(this, 
			tr("Choose Map File"), mapPath);
	if (!data.isEmpty())
	{
		mapLineEdit->setText(data);
		mapPath = QFileInfo(data).absolutePath();
	}
}

bool NewRunDialog::validate()
{
        QString rText = rLineEdit->text();
        int rPos = 0;
        if (rLineEdit->validator()->validate(rText, rPos) != QValidator::Acceptable)
        {
                QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Runs"));
                return false;
        }
	
        QString kText = kLineEdit->text();
        int kPos = 0;
        if (kLineEdit->validator()->validate(kText, kPos) != QValidator::Acceptable)
        {
                QMessageBox::warning(this, GUI_TITLE, 
                                     tr("Please input an integer from 2 to 216 for number of clusters."));
                return false;
        }
	
	if (scriptCheckBox->checkState() == Qt::Checked)
	{
		QString toKText = toKLineEdit->text();
		int toKPos = 0;
		if (toKLineEdit->validator()->validate(toKText, toKPos) != QValidator::Acceptable)
		{
			QMessageBox::warning(this, GUI_TITLE, 
					     tr("Please input an integer from 2 to 216 for the upper number of clusters."));
			return false;
		}
	
		if (toKText.toInt() < kText.toInt())
		{
			QMessageBox::warning(this, GUI_TITLE, 
					     tr("The upper number of clusters must be greater or equal than the lower number of clusters."));
			return false;
		}
	}
	
// 	QString dText = dLineEdit->text();
//         int dPos = 0;
//         if (dLineEdit->validator()->validate(dText, dPos) != QValidator::Acceptable)
//         {
//                 QMessageBox::warning(this, GUI_TITLE, 
//                             tr("Please input a float from 1.0 to 10.0 for parameter of allele freq. model."));
//                 return false;
// 	}
// 	
	

        QString sText = sLineEdit->text();
        int sPos = 0;
        if (sLineEdit->validator()->validate(sText, sPos) != QValidator::Acceptable)
        {
                QMessageBox::warning(this, GUI_TITLE, 
                         tr("Invalid Total Number of Sweeps"));
                return false;
        }

	
        QString bText = bLineEdit->text();
        int bPos = 0;
        if (bLineEdit->validator()->validate(bText, bPos) != QValidator::Acceptable)
        {
                QMessageBox::warning(this, GUI_TITLE, 
                         tr("Invalid Burn In Number of Sweeps"));
                return false;
        }

	
        if (!(sLineEdit->text().toInt() > bLineEdit->text().toInt()))
        {
               QMessageBox::warning(this, GUI_TITLE, 
                         tr("Total number of sweeps must be larger than burn in number of sweeps."));
               return false;
        }  
	
	if (zCheckBox->checkState() == Qt::Checked && njCheckBox->checkState() == Qt::Checked)
	{
		QMessageBox::warning(this, GUI_TITLE, 
				     tr("You cannot continue lowest DIC run and start from Neighbour Joining Tree at the same time!"));
		return false;
	}
	
	
        if (zCheckBox->checkState() == Qt::Checked)
        {
		if (admRadioButton->isChecked()) 
		{
					
			
			QString mlfStr;
			QString zfStr;
			
			if (carRadioButton->isChecked())
			{
                		mlfStr = path + "/" + mlAdmCAR;
				zfStr = path + "/" + zadmCAR;
			}
			
			if (bymRadioButton->isChecked())
			{
				mlfStr = path + "/" + mlAdmBYM;
				zfStr = path + "/" + zadmBYM;
			}
			
			QFile zf(zfStr);
			QFile mlf(mlfStr);
			QString admMod = "CAR";
			if (bymRadioButton->isChecked())
			{
				admMod = "BYM";
			}
                	
			if (!mlf.open(QIODevice::ReadOnly) || !zf.open(QIODevice::ReadOnly))
			{
				QMessageBox::warning(this, GUI_TITLE, 
				    QString(tr("No configuration file found for the %1 admixture model\n"
					       "You can continue previous runs for the no-admixture model or the other admixture model.\n"  
					       "Please modify settings for current run.\n")).arg(admMod)
						    ,QMessageBox::Ok);
				return false;
			}
                	QTextStream in(&zf);
                	QTextStream inml(&mlf);
                	QString K = in.read(8);
                	QString MLInfo = inml.readLine();
                	zf.close();
                	mlf.close();
                	K = K.left(K.indexOf(' '));
                	QString MLadmixture = MLInfo.right(2);
	
			QString MLadmMod = "CAR";
			
			if (MLadmixture.toInt() == 0)
			{
				MLadmMod = "BYM";
			}
                	MLInfo.chop(MLadmixture.length());
                	MLadmixture = MLadmixture.left(1);
                	QString MLtrendDeg = MLInfo.right((MLInfo.length() - MLInfo.lastIndexOf(' ',-2))-1);
                	MLInfo.chop(MLtrendDeg.length());
                	if (K != kLineEdit->text())
                	{
                        	if (QMessageBox::Yes == QMessageBox::warning(this, GUI_TITLE, 
                               	                                      QString(
                                	                                            tr("You have chosen to continue from lowest DIC run.\n"
                                        	                                       "The maximal number of clusters was set to %1 in this previous run,\n"
                                                	                               "while the maximal number of clusters is set to %2 for the current run.\n"
                                                        	                       "Do you want to modify settings for current run?\n"))
                                                                	     .arg(K).arg(kLineEdit->text()), QMessageBox::Yes, QMessageBox::No))
                        	{
                                	return false;
                        	}
                	}
			if (admMod != MLadmMod)
                	{
                        	if (QMessageBox::Yes == QMessageBox::warning(this, GUI_TITLE, 
                                                                     QString(
                                                                            tr("You have chosen to continue from lowest DIC run.\n"
                                                                               "The admixture model was set to %1 in this previous run,\n"
                                                                               "while it is set to %2 for the current run.\n"
                                                                               "Do you want to modify settings for current run?\n"))
										.arg(MLadmMod).arg(admMod), QMessageBox::Yes, QMessageBox::No))
                        	{
                                	return false;
                        	}

                	}
                
			
			if (MLtrendDeg.toInt() != trendDegreeComboBox->currentIndex())
			{
				if (QMessageBox::Yes == QMessageBox::warning(this, GUI_TITLE,
			    	QString(
				    tr("You have chosen to continue from lowest DIC run.\n"
					    "The trend degree was set to %1 in this previous run,\n"
					    "while it is set to %2 for the current run.\n"
					    "Do you want to modify settings for current run?\n"))
					    .arg(MLtrendDeg).arg(trendDegreeComboBox->currentIndex()), QMessageBox::Yes, QMessageBox::No))
				{
					return false;
				}

			}	
		
		}
		else
		{
			//No admixture case
			QFile zf(path + "/" + znoAdm);
			QFile mlf(path + "/" + mlnoAdm);
			zf.open(QIODevice::ReadOnly);
			if (!mlf.open(QIODevice::ReadOnly))
			{
				QMessageBox::warning(this, GUI_TITLE, 
						QString(tr("No configuration file found for the model without admixture.\n"
								"You can continue previous runs for the admixture model.\n"  
								"Please modify settings for current run.\n"))
								,QMessageBox::Ok);
				return false;
			}
			QTextStream in(&zf);
			QTextStream inml(&mlf);
			QString MLInfo = inml.readLine();
			QString K = in.read(8);
			zf.close();
			mlf.close();
			
			QString MLadmixture = MLInfo.right(2);
			MLInfo.chop(MLadmixture.length());
			MLadmixture = MLadmixture.left(1);
			QString MLpsi = MLInfo.right((MLInfo.length() - MLInfo.lastIndexOf(' ',-2))-1);
			
			K = K.left(K.indexOf(' '));
			if (K != kLineEdit->text())
			{
				if (QMessageBox::Yes == QMessageBox::warning(this, GUI_TITLE, 
				    QString(
					    tr("You have chosen to continue from previous run.\n"
						    "The maximal number of clusters was set to %1 for previous run,\n"
						    "while the maximal number of clusters is set to %2 for current run.\n"
						    "Do you want to modify settings for current run?\n"))
						    .arg(K).arg(kLineEdit->text()), QMessageBox::Yes, QMessageBox::No))
				{
					return false;
				}
			}
			
			if (MLpsi.toDouble() != psi.toDouble())
			{
				if (QMessageBox::Yes == QMessageBox::warning(this, GUI_TITLE,
				    QString(
					    tr("You have chosen to continue from lowest DIC run.\n"
						    "The spatial interaction parameter was set to %1 in this previous run,\n"
						    "while it is set to %2 for the current run.\n"
						    "Do you want to modify settings for current run?\n"))
						    .arg(MLpsi).arg(psi), QMessageBox::Yes, QMessageBox::No))
				{
					return false;
				}

			}
			
		}
        }
	
        return true;
}
