#ifndef NEWRUNDIALOG_H
#define NEWRUNDIALOG_H

#include <QDialog>


class QCheckBox;
class QGroupBox;
class QLabel;
class QLineEdit;
class QRadioButton;
class QComboBox;


class NewRunDialog : public QDialog
{
    Q_OBJECT

public:
	NewRunDialog(QWidget *parent = 0, QString oldscOption="m", bool hasGeo = false, QString oldPsi = "0.6", bool oldUpdatePsi = false, QString oldSigma = "1.0", bool oldUpdateSigma=false, QString oldLambda = "1.0");
    ~NewRunDialog();


    QString scOption;
    bool hasGeoData;
    
    QPushButton* advanced;
    
    QRadioButton *noAdmRadioButton;
    QRadioButton *admRadioButton;
    
    QRadioButton *carRadioButton;
    QRadioButton *bymRadioButton;
    
    QGroupBox *tGroupBox;
    QGroupBox *mGroupBox;
    QLabel *rLabel;
    QLineEdit *rLineEdit;
    QLabel *kLabel;
    QLineEdit *kLineEdit;
    QLabel *toKLabel;
    QLineEdit *toKLineEdit;
    QLabel *scriptLabel;
    QCheckBox *scriptCheckBox;
//     QLabel *pLabel;
//     QLineEdit *pLineEdit;
    QString psi;
    bool updatePsi;
//     QLabel *pUpdateLabel;
//     QCheckBox *pUpdateCheckBox;
    QLabel *trendDegreeLabel;
    QComboBox *trendDegreeComboBox;
//     QLabel *sigmaLabel;
//     QLineEdit *sigmaLineEdit;
    QString sigma;
    bool updateSigma;
    
//     QLabel *dLabel;
//     QLineEdit *dLineEdit;
    
    QString lambda;
    
    QLabel *sLabel;
    QLineEdit *sLineEdit;
    QLabel *bLabel;
    QLineEdit *bLineEdit;
    QLabel *iLabel;
    QLineEdit *iLineEdit;

//     QLabel *updateLabel;
//     QCheckBox *updateCheckBox;
    
    QCheckBox *zCheckBox;
    QCheckBox *njCheckBox;

    QLabel *mapLabel;
    QLineEdit* mapLineEdit;
//     QLineEdit* mXLineEdit;
//     QLineEdit* mYLineEdit;
    QGroupBox* predGroupBox;
    
    QString path;
    QString znoAdm;
    QString zadmCAR;
    QString zadmBYM;
    QString mlAdmCAR;
    QString mlAdmBYM;
    QString mlnoAdm;

protected:
	void accept();
    

private slots:
	void njStateChanged(int state);
	void zStateChanged(int state);
	void admToggled(bool checked);
	void scriptStateChanged(int state);
	void advOpt();
// 	void predictToggled(int state);
	void browseData();


private:
	bool validate();
	QString mapPath;
};

#endif // NEWRUNDIALOG_H
