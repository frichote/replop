#include <cmath>
#include <QtCore>
#include <QtGui>
#include "resampledialog.h"
#include "datawindow.h"
#include "title.h"

ResampleDialog::ResampleDialog(QWidget *parent)
    : QDialog(parent)
{
	setWindowTitle(tr("Resample Loci"));

	QLabel *dfLabel = new QLabel(tr("Input Data File:"));
	dfLineEdit = new QLineEdit;
	connect(dfLineEdit, SIGNAL(textChanged(const QString &)), 
		this, SLOT(dFileChanged()));

	QPushButton *browseDFilePushButton = new QPushButton(tr("Browse..."));
	browseDFilePushButton->setAutoDefault(false);
	connect(browseDFilePushButton, SIGNAL(clicked()), this, SLOT(browseDFile()));

	viewDFilePushButton = new QPushButton(tr("View Input Data..."));
	viewDFilePushButton->setAutoDefault(false);
	viewDFilePushButton->setEnabled(false);
	connect(viewDFilePushButton, SIGNAL(clicked()), this, SLOT(viewDFile()));

	QLabel *nLabel = new QLabel(tr("Number of Individuals:"));
	nLineEdit = new QLineEdit;
	QIntValidator *nV = new QIntValidator(this);
	nV->setBottom(1);
	nLineEdit->setValidator(nV);

	QLabel *dLabel = new QLabel(tr("Number of Dummy Individuals:"));
	dLineEdit = new QLineEdit;
	dLineEdit->setText(tr("0"));
	QIntValidator *dV = new QIntValidator(this);
	dV->setBottom(0);
	dLineEdit->setValidator(dV);

	QLabel *aLabel = new QLabel(tr("Ploidy:"));
	aLineEdit = new QLineEdit;
	aLineEdit->setText(tr("2"));
	QIntValidator *aV = new QIntValidator(this);
	aV->setBottom(1);
	aLineEdit->setValidator(aV);

	QLabel *lLabel = new QLabel(tr("Number of Loci:"));
	lLineEdit = new QLineEdit;
	QIntValidator *lV = new QIntValidator(this);
	lV->setBottom(1);
	lLineEdit->setValidator(lV);
	connect(lLineEdit, SIGNAL(textEdited(const QString &)), 
		this, SLOT(lTextEdited(const QString &)));
	connect(lLineEdit, SIGNAL(editingFinished()), this, SLOT(lEditingFinished()));

	aCheckBox = new QCheckBox(tr("Data Containing Information for Association Mapping Test"));

	QLabel *rLabel = new QLabel(tr("Number of Extra Rows:"));
	rLineEdit = new QLineEdit;
	rLineEdit->setText(tr("0"));
	QIntValidator *rV = new QIntValidator(this);
	rV->setBottom(0);
	rLineEdit->setValidator(rV);

	QLabel *cLabel = new QLabel(tr("Number of Extra Columns:"));
	cLineEdit = new QLineEdit;
	cLineEdit->setText(tr("0"));
	QIntValidator *cV = new QIntValidator(this);
	cV->setBottom(0);
	cLineEdit->setValidator(cV);

	containSI = new QCheckBox(tr("Data Containing Spatial Information"));
	containSI->setCheckState(Qt::Checked);

	QFrame *drFrame = new QFrame;
	drFrame->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	QLabel *rfLabel = new QLabel(tr("Output Resampled File:"));
	rfLineEdit = new QLineEdit;

	QPushButton *browseRFilePushButton = new QPushButton(tr("Browse..."));
	browseRFilePushButton->setAutoDefault(false);
	connect(browseRFilePushButton, SIGNAL(clicked()), this, SLOT(browseRFile()));

	sLabel = new QLabel(tr("Number of Resampled Loci (S):"));
	sLineEdit = new QLineEdit;
	QIntValidator *sV = new QIntValidator(this);
	sV->setBottom(1);
	sLineEdit->setValidator(sV);

	rRadioButton = new QRadioButton(tr("Sampling Random S Loci"));
	rRadioButton->setChecked(true);
	connect(rRadioButton, SIGNAL(toggled(bool)), this, SLOT(rToggled(bool)));

	fRadioButton = new QRadioButton(tr("Sampling the First S Loci"));
	connect(fRadioButton, SIGNAL(toggled(bool)), this, SLOT(fToggled(bool)));

	mRadioButton = new QRadioButton(tr("Sampling the Middle S Loci"));
	connect(mRadioButton, SIGNAL(toggled(bool)), this, SLOT(mToggled(bool)));

	lRadioButton = new QRadioButton(tr("Sampling the Last S Loci"));
	connect(lRadioButton, SIGNAL(toggled(bool)), this, SLOT(lToggled(bool)));

	sRadioButton = new QRadioButton(tr("Flexible Sampling (Selecting Loci from List)"));
	sRadioButton->setEnabled(false);
	connect(sRadioButton, SIGNAL(toggled(bool)), this, SLOT(sToggled(bool)));
	sListWidget = new QListWidget;
	sListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
	sListWidget->setEnabled(false);

	QVBoxLayout *sLayout = new QVBoxLayout;
	sLayout->addWidget(rRadioButton);
	sLayout->addWidget(fRadioButton);
	sLayout->addWidget(mRadioButton);
	sLayout->addWidget(lRadioButton);
	sLayout->addWidget(sRadioButton);
	sLayout->addWidget(sListWidget);

	sGroupBox = new QGroupBox(tr("Sampling Method"));
	sGroupBox->setLayout(sLayout);

	showResult = new QCheckBox(tr("Show Resampled File"));
	showResult->setCheckState(Qt::Checked);

	QGridLayout *infoLayout = new QGridLayout;
	infoLayout->addWidget(dfLabel, 0, 0);
	infoLayout->addWidget(dfLineEdit, 0, 1);
	infoLayout->addWidget(browseDFilePushButton, 0, 2);
	infoLayout->addWidget(viewDFilePushButton, 1, 0);
	infoLayout->addWidget(nLabel, 2, 0);
	infoLayout->addWidget(nLineEdit, 2, 1);
	infoLayout->addWidget(dLabel, 3, 0);
	infoLayout->addWidget(dLineEdit, 3, 1);
	infoLayout->addWidget(aLabel, 4, 0);
	infoLayout->addWidget(aLineEdit, 4, 1);
	infoLayout->addWidget(lLabel, 5, 0);
	infoLayout->addWidget(lLineEdit, 5, 1);
	//infoLayout->addWidget(aCheckBox, 6, 0, 1, 3);
	infoLayout->addWidget(rLabel, 7, 0);
	infoLayout->addWidget(rLineEdit, 7, 1);
	infoLayout->addWidget(cLabel, 8, 0);
	infoLayout->addWidget(cLineEdit, 8, 1);
	infoLayout->addWidget(containSI, 9, 0, 1, 3);
	infoLayout->addWidget(drFrame, 10, 0, 1, 3);
	infoLayout->addWidget(rfLabel, 11, 0);
	infoLayout->addWidget(rfLineEdit, 11, 1);
	infoLayout->addWidget(browseRFilePushButton, 11, 2);
	infoLayout->addWidget(sLabel, 12, 0);
	infoLayout->addWidget(sLineEdit, 12, 1);
	infoLayout->addWidget(sGroupBox, 13, 0, 1, 2);
	infoLayout->addWidget(showResult, 14, 0, 1, 3);

	QPushButton *okPushButton = new QPushButton(tr("OK"));
	okPushButton->setDefault(true);
	connect(okPushButton, SIGNAL(clicked()), this, SLOT(accept()));

	QPushButton *cancelPushButton = new QPushButton(tr("Cancel"));
	connect(cancelPushButton, SIGNAL(clicked()), this, SLOT(reject()));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch();
	buttonLayout->addWidget(okPushButton);
	buttonLayout->addStretch();
	buttonLayout->addWidget(cancelPushButton);
	buttonLayout->addStretch();

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(infoLayout);
	mainLayout->addStretch();
	mainLayout->addSpacing(5);
	mainLayout->addLayout(buttonLayout);

	setLayout(mainLayout);
}

ResampleDialog::~ResampleDialog()
{
}

void ResampleDialog::accept()
{
	if (validate())
	{
		QDialog::accept();
	}
}

void ResampleDialog::browseDFile()
{
	QString file = QFileDialog::getOpenFileName(this, 
		tr("Choose Data File"), commonPath);
	if (!file.isEmpty())
	{
		dfLineEdit->setText(file);
		commonPath = QFileInfo(file).absolutePath();
	}
}

void ResampleDialog::dFileChanged()
{
	viewDFilePushButton->setEnabled(!dfLineEdit->text().isEmpty());
}

void ResampleDialog::viewDFile()
{
	if (!QFile::exists(dfLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The data file does not exist."));
		return;
	}

	QDialog *dataDialog = new QDialog;
	dataDialog->setAttribute(Qt::WA_DeleteOnClose);
	dataDialog->setWindowTitle(tr("Data File"));
	DataWindow *dataWidget = new DataWindow;
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(dataWidget);
	dataDialog->setLayout(mainLayout);
	if (dataWidget->loadFile(dfLineEdit->text()))
	{
		dataDialog->exec();	
	}
	else
	{
		dataDialog->close();
	}
}

void ResampleDialog::lTextEdited(const QString &text)
{
	if (!text.toInt())
	{
		sRadioButton->setEnabled(false);
		sListWidget->clear();
	}
}

void ResampleDialog::lEditingFinished()
{
	int L = lLineEdit->text().toInt();
	sRadioButton->setEnabled(true);
	int numDigits = int(log10(double(L)) + 1.0);
	sListWidget->clear();
	for (int l = 0; l < L; l++)
	{
		sListWidget->addItem(QString("%1").arg(l + 1, numDigits, 10, QChar('0')));
	}
}

void ResampleDialog::browseRFile()
{
	QString file = QFileDialog::getSaveFileName(this, 
		tr("Save Resampled File"), commonPath);
	if (!file.isEmpty())
	{
		rfLineEdit->setText(file);
		commonPath = QFileInfo(file).absolutePath();
	}
}

void ResampleDialog::rToggled(bool checked)
{
	if (checked)
	{
		sLabel->setEnabled(true);
		sLineEdit->setEnabled(true);
		sListWidget->setEnabled(false);
	}
}

void ResampleDialog::fToggled(bool checked)
{
	if (checked)
	{
		sLabel->setEnabled(true);
		sLineEdit->setEnabled(true);
		sListWidget->setEnabled(false);
	}
}

void ResampleDialog::mToggled(bool checked)
{
	if (checked)
	{
		sLabel->setEnabled(true);
		sLineEdit->setEnabled(true);
		sListWidget->setEnabled(false);
	}
}

void ResampleDialog::lToggled(bool checked)
{
	if (checked)
	{
		sLabel->setEnabled(true);
		sLineEdit->setEnabled(true);
		sListWidget->setEnabled(false);
	}
}

void ResampleDialog::sToggled(bool checked)
{
	if (checked)
	{
		sLabel->setEnabled(false);
		sLineEdit->setEnabled(false);
		sListWidget->setEnabled(true);
	}
}

bool ResampleDialog::validate()
{
	if (dfLineEdit->text().isEmpty() || !QFile::exists(dfLineEdit->text()))
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified data file does not exist."));
		return false;
	}

	QString nText = nLineEdit->text();
	int nPos = 0;
	if (nLineEdit->validator()->validate(nText, nPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Individuals"));
		return false;
	}

	QString dText = dLineEdit->text();
	int dPos = 0;
	if (dLineEdit->validator()->validate(dText, dPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Dummy Individuals"));
		return false;
	}

	QString aText = aLineEdit->text();
	int aPos = 0;
	if (aLineEdit->validator()->validate(aText, aPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Ploidy"));
		return false;
	}

	QString lText = lLineEdit->text();
	int lPos = 0;
	if (lLineEdit->validator()->validate(lText, lPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Loci"));
		return false;
	}

	QString rText = rLineEdit->text();
	int rPos = 0;
	if (rLineEdit->validator()->validate(rText, rPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Extra Rows"));
		return false;
	}

	QString cText = cLineEdit->text();
	int cPos = 0;
	if (cLineEdit->validator()->validate(cText, cPos) != QValidator::Acceptable)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Extra Columns"));
		return false;
	}

	// Specified Total Number of Rows
	int sRows = rLineEdit->text().toInt() + aLineEdit->text().toInt() * 
		(nLineEdit->text().toInt() + dLineEdit->text().toInt());
	QList< int > dfFormat = infoFormat(dfLineEdit->text());
	// Expected Total Number of Rows
	int eRows = dfFormat.size();
	if (sRows != eRows)
	{
		QMessageBox::warning(this, GUI_TITLE, QString(tr(
			"According to your input, there should be totally %1 rows in the data file,\n"
			"but I detected that there are actually %2 rows.\n\n"
			"Please check whether you have correctly input:\n"
			"Number of Individuals\n"
			"Number of Dummy Individuals\n"
			"Ploidy\n"
			"Number of Extra Rows")).arg(sRows).arg(eRows));
		return false;
	}
	// Specified Total Number of Columns
	int sCols = cLineEdit->text().toInt() + lLineEdit->text().toInt();
	if (aCheckBox->checkState() == Qt::Checked)
	{
		sCols += 2;
	}
	if (containSI->checkState() == Qt::Checked)
	{
		sCols += 2;
	}
	// Expected Total Number of Columns
	int eCols;
	for (int i = rLineEdit->text().toInt(); i < eRows; i++)
	{
		eCols = dfFormat.at(i);
		if (sCols != eCols)
		{
			QMessageBox::warning(this, GUI_TITLE, QString(tr(
				"According to your input, there should be %1 columns in the data area of\n"
				"the data file, but I detected that there are actually %2 columns.\n\n"
				"Please check whether you have correctly input:\n"
				"Number of Loci\n"
				"Data Containing Information for Association Mapping Test\n"
				"Number of Extra Columns\n"
				"Data Containing Spatial Information\n"
				"Number of Extra Rows")).arg(sCols).arg(eCols));
			return false;
		}
	}

	QDir resultDir(QFileInfo(rfLineEdit->text()).absolutePath());
	if (rfLineEdit->text().isEmpty() || !resultDir.exists())
	{
		QMessageBox::warning(this, GUI_TITLE, 
			tr("The specified result PATH does not exist."));
		return false;
	}

	if (sLineEdit->isEnabled())
	{
		QString sText = sLineEdit->text();
		int sPos = 0;
		if (sLineEdit->validator()->validate(sText, sPos) != QValidator::Acceptable || 
			sLineEdit->text().toInt() > lLineEdit->text().toInt())
		{
			QMessageBox::warning(this, GUI_TITLE, tr("Invalid Number of Resampled Loci"));
			return false;
		}
	}

	if (sRadioButton->isChecked())
	{
		QList<QListWidgetItem *> manuallySampledItems = sListWidget->selectedItems();
		if (manuallySampledItems.size() == 0)
		{
			QMessageBox::warning(this, GUI_TITLE, 
				tr("Flexible sampling method selected, but no locus sampled!"));
			return false;
		}
	}

	return true;
}

const QList< int > &ResampleDialog::infoFormat(const QString &infoFile)
{
	static QList< int > format;
	format.clear();

	QFile file(infoFile);
	if (!file.open(QFile::ReadOnly | QFile::Text)) 
	{
		QMessageBox::warning(this, GUI_TITLE,
			tr("Cannot verify information file %1!").arg(infoFile));
		return format;
	}
	QTextStream in(&file);
	QRegExp reWC("\\w");  // Word Character
	QRegExp regExp("\\s+|\\t+");  // Space(s) or Tab(s)
	QString oneRow;
	QStringList oneRowList;
	QApplication::setOverrideCursor(Qt::WaitCursor);
	while (!(oneRow = in.readLine()).isNull())
	{
		if (oneRow.contains(reWC))
		{
			oneRowList = oneRow.split(regExp, QString::SkipEmptyParts);
			format.append(oneRowList.size());
		}
	}
	QApplication::restoreOverrideCursor();
	file.close();

	return format;
}
