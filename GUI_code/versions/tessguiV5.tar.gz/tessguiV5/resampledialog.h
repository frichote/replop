#ifndef RESAMPLEDIALOG_H
#define RESAMPLEDIALOG_H

#include <QDialog>

class QCheckBox;
class QGroupBox;
class QLabel;
class QLineEdit;
class QListWidget;
class QPushButton;
class QRadioButton;

class ResampleDialog : public QDialog
{
    Q_OBJECT

public:
    ResampleDialog(QWidget *parent = 0);
    ~ResampleDialog();

public:
	QLineEdit *dfLineEdit;		// Data File (Input)
	QLineEdit *nLineEdit;		// Number of Individuals
	QLineEdit *dLineEdit;		// Number of Dummy Individuals
	QLineEdit *aLineEdit;		// Ploidy
	QLineEdit *lLineEdit;		// Number of Loci
	QCheckBox *aCheckBox;		// Data Containing Information for Association Mapping Test?
	QLineEdit *rLineEdit;		// Number of Extra Rows
	QLineEdit *cLineEdit;		// Number of Extra Columns
	QCheckBox *containSI;		// Input data contain spatial information?

	QLineEdit *rfLineEdit;		// Resampled File (Output)
	QLabel *sLabel;				// Number of Resampled Loci (Label)
	QLineEdit *sLineEdit;		// Number of Resampled Loci
	QRadioButton *rRadioButton;	// Sample Random S Loci
	QRadioButton *fRadioButton;	// Sample Fist S Loci
	QRadioButton *mRadioButton;	// Sample Middle S Loci
	QRadioButton *lRadioButton;	// Sample Last S Loci
	QRadioButton *sRadioButton;	// Manually Sample
	QListWidget *sListWidget;	// User Interface for Selecting Loci (Manually Sample Only)
	QGroupBox *sGroupBox;		// Sampling Method Group Box
	QCheckBox *showResult;		// Show the resampled result file?

	int NoSL;					// Number of Sampled Loci

protected:
	void accept();

private slots:
	void browseDFile();
	void dFileChanged();
	void viewDFile();
	void lTextEdited(const QString &text);
	void lEditingFinished();
	void browseRFile();
	void rToggled(bool checked);
	void fToggled(bool checked);
	void mToggled(bool checked);
	void lToggled(bool checked);
	void sToggled(bool checked);

private:
	bool validate();
	const QList< int > &infoFormat(const QString &infoFile);

private:
	QString commonPath;
	QPushButton *viewDFilePushButton;
};

#endif // RESAMPLEDIALOG_H
