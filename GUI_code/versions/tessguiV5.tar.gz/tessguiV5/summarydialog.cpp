//#include <QtCore>
#include <QtGui>
#include <iostream>
#include "summarydialog.h"

using namespace std;

SummaryDialog::SummaryDialog(QWidget *parent) 
	: QDialog(parent)
{
	setWindowTitle(tr("Summarize Project Runs"));
	
	exportToClumpp = false;
	
	QLabel *lowerLabel = new QLabel(tr("Lower Range: "));
	lowerComboBox = new QComboBox;
	
	QLabel *upperLabel = new QLabel(tr("Upper Range: "));
	upperComboBox = new QComboBox;
	
	QLabel *avgDICLabel = new QLabel(tr("Avg. DIC =   "));
	avgDICTextEdit = new QLabel;
	
	QVBoxLayout *lowerLayout = new QVBoxLayout;
	lowerLayout->addWidget(lowerLabel);
	lowerLayout->addWidget(lowerComboBox,Qt::AlignLeft);
	
	QVBoxLayout *upperLayout = new QVBoxLayout;
	upperLayout->addWidget(upperLabel);
	upperLayout->addWidget(upperComboBox,Qt::AlignLeft);

	QLabel *percentageLabel = new QLabel(tr("Filter lowest DIC runs:"));
	percentageComboBox = new QComboBox();
	
	for (int i = 1; i <= 10; i++)
	{
		percentageComboBox->addItem(QString("%1 %").arg(i*10, 3, 10, QChar('0')));
	}
	
	QVBoxLayout *percentageLayout = new QVBoxLayout;
	percentageLayout->addWidget(percentageLabel);
	percentageLayout->addWidget(percentageComboBox);
		
	QHBoxLayout *avgDICLayout = new QHBoxLayout;
	avgDICLayout->addWidget(avgDICLabel);
	avgDICLayout->addWidget(avgDICTextEdit);
	
	toTextPushButton = new QPushButton(tr("Export Table to Text File"));
	
	QGridLayout *rangeLayout = new QGridLayout;

	rangeLayout->addLayout(lowerLayout,0,0,1,1);
	rangeLayout->addLayout(upperLayout,0,1,1,1);
	rangeLayout->addLayout(percentageLayout,0,2,1,1);
	rangeLayout->addLayout(avgDICLayout,1,0,1,1);
	rangeLayout->addWidget(toTextPushButton,1,2);
	
	summaryTable = new SummaryTable(this);
	summaryTable->resizeColumnsToContents();
	summaryTable->setMinimumSize(summaryTable->minimumSizeHint());
	QGridLayout *tableLayout = new QGridLayout;
	tableLayout->addWidget(summaryTable,0,0);
	
	QLabel *popfileLabel = new QLabel(tr("Export CLUMPP Popfile to:"));
	popfileLineEdit = new QLineEdit;
	
	browsePopfilePushButton = new QPushButton(tr("Browse..."));
	connect(browsePopfilePushButton, SIGNAL(clicked()), this, SLOT(browsePopfile()));
	
	writeParamfile = new QCheckBox(tr("Write CLUMPP Paramfile"));
	writeParamfile->setCheckState(Qt::Checked);
	
	QLabel *KmaxLabel = new QLabel(tr("Kmax:"));
	KmaxComboBox = new QComboBox();
	
	
	
	
	
	QLabel *candidateLabel = new QLabel(tr("Candidate Runs:"));
	candidateListWidget = new QListWidget;
	candidateListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
	QVBoxLayout *cLayout = new QVBoxLayout;
	cLayout->addWidget(candidateLabel);
	cLayout->addWidget(candidateListWidget,Qt::AlignLeft);

	c2ePushButton = new QPushButton(tr("->"));
	c2ePushButton->setAutoDefault(false);
	e2cPushButton = new QPushButton(tr("<-"));
	e2cPushButton->setAutoDefault(false);
	QVBoxLayout *ceLayout = new QVBoxLayout;
	ceLayout->addWidget(c2ePushButton);
	ceLayout->addWidget(e2cPushButton);
	
	connect(c2ePushButton, SIGNAL(clicked()), this, SLOT(c2eClicked()));
	connect(e2cPushButton, SIGNAL(clicked()), this, SLOT(e2cClicked()));
	

	QLabel *exportLabel = new QLabel(tr("Runs to Export:"));
	exportListWidget = new QListWidget;
	exportListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
	QVBoxLayout *eLayout = new QVBoxLayout;
	eLayout->addWidget(exportLabel);
	eLayout->addWidget(exportListWidget);
	
	toClumppPushButton = new QPushButton(tr("Export to CLUMPP"));
		
	
	QGridLayout *exportLayout = new QGridLayout;
	exportLayout->addWidget(KmaxLabel,0,0,Qt::AlignLeft);
	//exportLayout->addWidget(percentageLabel,0,1,Qt::AlignLeft);
	exportLayout->addWidget(KmaxComboBox,1,0,Qt::AlignLeft);
	//exportLayout->addWidget(percentageComboBox,1,1,Qt::AlignLeft);
	exportLayout->addLayout(cLayout,2,0,1,2,Qt::AlignLeft);
	exportLayout->addLayout(ceLayout,2,2,Qt::AlignCenter);
	exportLayout->addLayout(eLayout,2,3,1,2,Qt::AlignLeft);
	exportLayout->addWidget(popfileLabel,3,0,Qt::AlignLeft);
	exportLayout->addWidget(popfileLineEdit,3,1,1,2);
	exportLayout->addWidget(browsePopfilePushButton,3,3,Qt::AlignLeft);
	exportLayout->addWidget(writeParamfile,4,1,Qt::AlignLeft);
	exportLayout->addWidget(toClumppPushButton,4,3,Qt::AlignLeft);
	
	exportGroupBox = new QGroupBox(tr("Export to CLUMPP Utilities"));
	exportGroupBox->setLayout(exportLayout);
	
	
	
	QPushButton *closePushButton = new QPushButton(tr("Close"));
	connect(closePushButton, SIGNAL(clicked()), this, SLOT(closeClicked()));
	
	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch();
	buttonLayout->addWidget(closePushButton);
	buttonLayout->addStretch();
	
	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(rangeLayout);
	mainLayout->addWidget(summaryTable);
	mainLayout->addWidget(exportGroupBox,Qt::AlignCenter);
	mainLayout->addStretch();
	mainLayout->addLayout(buttonLayout,Qt::AlignCenter);
	setLayout(mainLayout);
}

SummaryDialog::~SummaryDialog()
{
	if (summaryTable) 
	{
		delete summaryTable;
	}
}

void SummaryDialog::browsePopfile()
{
	QString file = QFileDialog::getSaveFileName(this, tr("Save CLUMPP popfile"), commonPath);
	if (!file.isEmpty())
	{
		popfileLineEdit->setText(file);
		commonPath = QFileInfo(file).absolutePath();
	}
}

void SummaryDialog::c2eClicked()
{
	QList<QListWidgetItem *> selectedItems = candidateListWidget->selectedItems();
	for (int i = 0; i < selectedItems.size(); i++)
	{
		exportListWidget->addItem(
				     candidateListWidget->takeItem(candidateListWidget->row(selectedItems.at(i))));
	}
	candidateListWidget->sortItems();
	exportListWidget->sortItems();

	updateButtons();
}

void SummaryDialog::e2cClicked()
{
	QList<QListWidgetItem *> selectedItems = exportListWidget->selectedItems();
	for (int i = 0; i < selectedItems.size(); i++)
	{
		candidateListWidget->addItem(
				     exportListWidget->takeItem(exportListWidget->row(selectedItems.at(i))));
	}
	exportListWidget->sortItems();
	candidateListWidget->sortItems();

	updateButtons();
}

void SummaryDialog::updateButtons()
{
	c2ePushButton->setEnabled(candidateListWidget->count());
	e2cPushButton->setEnabled(exportListWidget->count());
}


void SummaryDialog::keyPressEvent(QKeyEvent *event)
{
	if (event->key() == Qt::Key_Escape)
	{
		close();
	}
}

void SummaryDialog::closeEvent(QCloseEvent *event)
{
	event->accept();
	emit finished();
}

void SummaryDialog::closeClicked()
{
	close();
}

void SummaryDialog::clear()
{
	lowerComboBox->disconnect();
	lowerComboBox->clear();
	upperComboBox->disconnect();
	upperComboBox->clear();
	KmaxComboBox->disconnect();
	KmaxComboBox->clear();
	candidateListWidget->disconnect();
	candidateListWidget->clear();
	exportListWidget->disconnect();
	exportListWidget->clear();
	percentageComboBox->disconnect();
}

