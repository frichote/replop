#ifndef SUMMARYDIALOG_H
#define SUMMARYDIALOG_H

#include <QDialog>

#include "summarytable.h"
class SummaryTable;
class QCloseEvent;
class QComboBox;
class QPushButton;
class QCheckBox;
class QLineEdit;
class QLabel;
class QListWidget;
class QGroupBox;

class SummaryDialog : public QDialog
{
	Q_OBJECT

public:
	SummaryDialog(QWidget *parent = 0);
	~SummaryDialog();

signals:
	void finished();
	
public:
	SummaryTable *summaryTable;
	QComboBox *lowerComboBox;
	QComboBox *upperComboBox;
	QPushButton *toTextPushButton;
	QPushButton *browsePopfilePushButton;
	QPushButton *toClumppPushButton;
	QCheckBox *writeParamfile;
	bool exportToClumpp;
	QComboBox *percentageComboBox; 
	QLabel *avgDICTextEdit;
	QGroupBox *exportGroupBox;
	QLineEdit *popfileLineEdit;
	QString commonPath;
	QComboBox* KmaxComboBox;
	QListWidget* candidateListWidget;
	QListWidget* exportListWidget;
	QPushButton* c2ePushButton;
	QPushButton* e2cPushButton;
	
	void clear();

protected:
	void closeEvent(QCloseEvent *event);
	void keyPressEvent(QKeyEvent *event);

private slots:
	void browsePopfile();
	void closeClicked();
	void c2eClicked();
	void e2cClicked();
	void updateButtons();
	
	
	

};

#endif
