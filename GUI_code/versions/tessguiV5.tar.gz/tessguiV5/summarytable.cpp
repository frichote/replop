#include <QtGui>
#include <cstdio>
#include <iostream>
#include "summarytable.h"

using namespace std;
SummaryTable::SummaryTable(QWidget *parent) : QTableWidget(parent)
{
	
	this->setColumnCount(9);
	this->verticalHeader()->setVisible(false);

	QTableWidgetItem *col0 = new QTableWidgetItem(tr("Run Label"));
	QTableWidgetItem *col1 = new QTableWidgetItem(tr("Kmax"));
	QTableWidgetItem *col2 = new QTableWidgetItem(tr("DIC"));
	QTableWidgetItem *col3 = new QTableWidgetItem(tr("Log-Likelihood History"));
	QTableWidgetItem *col4 = new QTableWidgetItem(tr("Hard Clustering"));
	QTableWidgetItem *col5 = new QTableWidgetItem(tr("Assignment Probabilities"));
// 	QTableWidgetItem *col6 = new QTableWidgetItem(tr("Admixture"));
	QTableWidgetItem *col6 = new QTableWidgetItem(tr("Trend Degree"));
	QTableWidgetItem *col7 = new QTableWidgetItem(tr("Admixture Model"));
	
	this->setHorizontalHeaderItem(0,col0);
	this->setHorizontalHeaderItem(1,col1);
	this->setHorizontalHeaderItem(2,col2);
	this->setHorizontalHeaderItem(3,col3);
	this->setHorizontalHeaderItem(4,col4);
	this->setHorizontalHeaderItem(5,col5);
// 	this->setHorizontalHeaderItem(6,col6);
	this->setHorizontalHeaderItem(6,col6);
	this->setHorizontalHeaderItem(7,col7);
	
	QHeaderView *hv = this->horizontalHeader();
	connect(hv,SIGNAL(sectionClicked(int)),this,SLOT(headerPressed(int)));
}

SummaryTable::~SummaryTable()
{
}

void SummaryTable::headerPressed(int col)
{
	int order = this->horizontalHeader()->sortIndicatorOrder();
	this->sortItems(col,Qt::SortOrder(order));
	order = orderChanged(order);
	this->horizontalHeader()->setSortIndicator(col,Qt::SortOrder(order));
}

int SummaryTable::orderChanged(int prevOrder = 1)
{
		if (prevOrder == 0) 
		{
			return 1;
		}
		return 0;
}

QSize SummaryTable::minimumSizeHint() 
{
	QSize size (QTableWidget::sizeHint());
	int width = 0;
	
	for (int c = 0; c < columnCount(); ++c)
	{
		width += columnWidth(c);
	}
	
	size.setWidth(width);
	
	return size;
}

QSize SummaryTable::sizeHint()
{
	return minimumSizeHint();
}
