// #include <QDialog>
#include <QTableWidget>

class QSize;
class QTableWidgetItem;

class SummaryTable : public QTableWidget
{
	Q_OBJECT
	public:
		SummaryTable(QWidget *parent = 0);
		~SummaryTable();
		
		QSize minimumSizeHint();
		QSize sizeHint();
		
		
	protected:
		void accept();
		int orderChanged(int prevOrder);
		
	private slots:
		void headerPressed(int col);
};
