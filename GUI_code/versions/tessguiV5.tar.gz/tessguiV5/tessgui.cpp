#include <QtAlgorithms>
#include <QtCore>
#include <QtGui>
#include <chartdir.h>
#include <set>
#include <cmath>
#include <algorithm>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_math.h>
#include <sstream>

#include "tessgui.h"
#include "aboutdialog.h"
#include "datawindow.h"
#include "generatedialog.h"
#include "geodialog.h"
#include "geoUtilities.h"
#include "graphwindow.h"
#include "newprojectdialog.h"
#include "newrundialog.h"
#include "resampledialog.h"
#include "textwindow.h"
#include "title.h"
#include "treewidget.h"
#include "IOUtilities.h"
#include "Voronoi.h"

#define EXIT_SUCCESS	0
#define EXIT_FAILURE	1

#define KMAX	216  



struct SPATIAL_INFO 
{
	int num;
	double xMin;
	double xMax;
	double xMu;
	double xSigma;
	double yMin;
	double yMax;
	double yMu;
	double ySigma;
};

struct SCOORD
{
	double x;
	double y;
};

TESSGUI::TESSGUI(QWidget *parent, Qt::WFlags flags)
    : QMainWindow(parent, flags)
{
	AllocRNG(rng, gsl_rng_ranlxs2);

	
	projectOpened = false;
	projectModified = false;

	workspace = new QWorkspace;
	setCentralWidget(workspace);
	connect(workspace, SIGNAL(windowActivated(QWidget *)), this, SLOT(updateMenus()));

	windowMapper = new QSignalMapper(this);
	connect(windowMapper, SIGNAL(mapped(QWidget *)), 
		workspace, SLOT(setActiveWindow(QWidget *)));

	createActions();
	createMenus();
	createToolBars();
	createStatusBar();
	createDockWindows();

	connect(projectTreeWidget, SIGNAL(itemDoubleClicked(QTreeWidgetItem *, int)), 
		this, SLOT(loadProjectItem(QTreeWidgetItem *, int)));

	setWindowTitle(GUI_TITLE);

	modifying = false;
	mnsd = new ModifyNSDialog(this);
	connect(mnsd, SIGNAL(finished()), this, SLOT(notModifying()));
	connect(mnsd, SIGNAL(modified()), this, SLOT(reloadNeighborhoodDiagram()));
	
	summaryOpened = false;
	summaryDialog = new SummaryDialog(this);
	summaryDialog->commonPath = project.path;
	connect(summaryDialog,SIGNAL(finished()),this,SLOT(notSummarizing()));
		
	cle = new QProcess(this);
	cle->setReadChannelMode(QProcess::MergedChannels);
	connect(cle, SIGNAL(error(QProcess::ProcessError)), 
		this, SLOT(cleError(QProcess::ProcessError)));
	connect(cle, SIGNAL(finished(int, QProcess::ExitStatus)), 
		this, SLOT(cleFinished(int, QProcess::ExitStatus)));
	connect(cle, SIGNAL(readyReadStandardError()), 
		this, SLOT(cleReadStandardError()));
	connect(cle, SIGNAL(readyReadStandardOutput()), 
		this, SLOT(cleReadStandardOutput()));
	connect(cle, SIGNAL(started()), this, SLOT(cleStarted()));
	connect(cle, SIGNAL(stateChanged(QProcess::ProcessState)), 
		this, SLOT(cleStateChanged(QProcess::ProcessState)));
	cleState = QProcess::NotRunning;

	updateMenus();
}

TESSGUI::~TESSGUI()
{
	if (mnsd)
	{
		delete mnsd;
	}
	
	if (summaryDialog)
	{
		delete summaryDialog;
	}
	
	FreeRNG(rng);
}

void TESSGUI::closeEvent(QCloseEvent *event)
{
	if (modifying)
	{
		int response = QMessageBox::question(this, GUI_TITLE, 
			tr("You are modifying the neighborhood system.\nDo you really want to quit?"), 
			QMessageBox::Yes, 
			QMessageBox::No | QMessageBox::Default);
		if (response == QMessageBox::Yes)
		{
			mnsd->close();
			
			if (summaryOpened)
			{
				summaryDialog->close();
				summaryOpened = false;
			}
			
			event->accept();
			
		}
		else
		{
			event->ignore();
		}
		
		return;
	}

	if (cleState != QProcess::NotRunning)
	{
		int response = QMessageBox::question(this, GUI_TITLE, 
			tr("Project is running. Do you really want to quit?"), 
			QMessageBox::Yes, 
			QMessageBox::No | QMessageBox::Default);
		if (response == QMessageBox::Yes)
		{
			if (summaryOpened)
			{
				summaryDialog->close();
				summaryOpened = false;
			}
			
			event->accept();
		}
		else
		{
			event->ignore();
		}
		
		if (summaryOpened)
		{
			summaryDialog->close();
			summaryOpened = false;
		}

		return;
	}
	
	if (summaryOpened)
	{
		summaryDialog->close();
		summaryOpened = false;
	}
	event->accept();
}

void TESSGUI::openData()
{
	QString fileName = QFileDialog::getOpenFileName(this, tr("Open Data"));
	loadData(fileName);
}

void TESSGUI::newProject()
{
	NewProjectDialog *newProjectDialog = new NewProjectDialog;
	if (newProjectDialog->exec() == QFileDialog::Accepted)
	{
		closeProject();  // Close previously opened project, if any.
		
		
		project.name = newProjectDialog->nameLineEdit->text();
		project.path = newProjectDialog->pathLineEdit->text();
		QFileInfo dataInfo(newProjectDialog->dataLineEdit->text());
		project.data = dataInfo.fileName();

		project.hasGeoData = !newProjectDialog->geoDataLineEdit->text().isEmpty();
		project.geoData = newProjectDialog->geoDataLineEdit->text();
		
		project.v = project.data + tr("VD.png");
		project.n = project.data + tr("ND.png");
		project.c = project.data + tr("VC");
		project.zadmCAR = project.data + tr("CFadmCAR");
		project.zadmBYM = project.data + tr("CFadmBYM");
		project.znoAdm = project.data + tr("CFnoAdm");
                project.mlAdmCAR = project.data + tr("MDIC_admCAR");
		project.mlAdmBYM = project.data + tr("MDIC_admBYM");
		project.mlnoAdm = project.data + tr("MDIC_noAdm");

		project.N = newProjectDialog->nLineEdit->text();
		project.D = newProjectDialog->dLineEdit->text();
		project.A = newProjectDialog->aLineEdit->text();
		project.L = newProjectDialog->lLineEdit->text();
		project.M = newProjectDialog->mLineEdit->text();
		project.specialFormat = newProjectDialog->specialCheckBox->isChecked();
		project.isRecessiveAllele = newProjectDialog->recessiveCheckBox->isChecked();
		
		project.R = newProjectDialog->rLineEdit->text();
		project.C = newProjectDialog->cLineEdit->text();

		project.i = 0;

		projectModified = true;
		currentProject = project.path + "/" + project.name + ".tp";
		saveProject();   // Save the newly created project.
		clearInfoWindow();
		if (!generateVNC())
		{
			infoTextEdit->append(tr("You may not be able to run this project!\n"));
		}
		if (!loadProject(currentProject))  // Load the new project.
		{
			projectOpened = true;
			closeProject();
		}
		updateMenus();
	}
	delete newProjectDialog;
}

void TESSGUI::openProject()
{
	QString projectName = QFileDialog::getOpenFileName(
		this,
		tr("Open %1 Project").arg(GUI_TITLE),
		QDir::currentPath(),
		tr("%1 Projects (*.tp);;All Files (*.*)").arg(GUI_TITLE)
	);
	if (!projectName.isEmpty())
	{
		if (projectOpened && projectName == currentProject)
		{
			return;
		}
		else
		{
			closeProject();  // Close previously opened project, if any.
			if (!loadProject(projectName))
			{
				projectOpened = true;
				closeProject();
				QMessageBox::warning(this, GUI_TITLE, tr("Cannot open project!"));
			}
		}
		updateMenus();
	}
}

void TESSGUI::closeProject()
{
	if (projectOpened)
	{
		saveProject();
		if (summaryOpened)
		{
			summaryDialog->close();
			summaryOpened = false;
		}
		summaryDialog->clear();
		projectTreeWidget->clear();
		workspace->closeAllWindows();
		clearInfoWindow();
		project.runs.clear();
		setDefaultRunParameters();
		projectOpened = false;
		updateMenus();
	}
}

void TESSGUI::saveProject()
{
	if (projectModified)
	{
		writeProjectSettings(currentProject);
		projectModified = false;
		updateMenus();
	}
}

void TESSGUI::openGraph()
{
	QString fileName = QFileDialog::getOpenFileName(
		this,
		tr("Open Graphical Results"),
		QDir::currentPath(),
		tr("Images (*.bmp *.gif *.jpg *.png *.pbm *.pgm *.ppm *.xbm *.xpm);;"
		"All Files (*.*)")
	);
	loadGraph(fileName);
}

void TESSGUI::openText()
{
	QString fileName = QFileDialog::getOpenFileName(this, tr("Open Textual Results"));
	loadText(fileName);
}

void TESSGUI::openRecentProject()
{
	QAction *action = qobject_cast<QAction *>(sender());
	if (action)
	{
		if (projectOpened && action->data().toString() == currentProject)
		{
			return;
		}
		else
		{
			closeProject();  // Close previously opened project, if any.
			if (!QFile::exists(action->data().toString()) || 
				!loadProject(action->data().toString()))
			{
				projectOpened = true;
				closeProject();
				QMessageBox::warning(this, GUI_TITLE, 
					tr("Cannot open this recent project!\n"
					"It will be removed from the recent project list."));
				QSettings settings(tr("SuperSoft"), GUI_TITLE);
				QStringList projects = 
					settings.value(tr("recentProjectList")).toStringList();
				projects.removeAll(action->data().toString());
				while (projects.size() > MAX_RECENT_PROJECTS)
				{
					projects.removeLast();
				}
				settings.setValue(tr("recentProjectList"), projects);
				updateRecentProjectActions();
			}
		}
		updateMenus();
	}
}

void TESSGUI::quit()
{
	if (summaryOpened)
	{
		summaryDialog->close();
		summaryOpened = false;
	}
	close();
}

void TESSGUI::modify()
{
	clearInfoWindow();

	if (!generateVNC())
	{
		infoTextEdit->append(tr("Cannot modify neighborhood system!\n"));
		return;
	}

	loadGraph(project.path + "/" + project.n);

	mnsd->N = project.N.toInt();
	mnsd->n = project.path + "/" + project.n;
	mnsd->c = project.path + "/" + project.c;
	mnsd->show();

	modifying = true;
	updateMenus();
}

void TESSGUI::run()
{
	NewRunDialog *newRunDialog = new NewRunDialog(0,oldRun.scOpt,project.hasGeoData,oldRun.P,oldRun.updatePsiParameter,oldRun.sigma,oldRun.updateParameters,oldRun.D);
	bool bNoAdm = oldRun.T == tr("without Admixture");
	newRunDialog->noAdmRadioButton->setChecked(bNoAdm);		
	bool bAdm = oldRun.T == tr("with Admixture");
	bool bCAR = oldRun.admMod == tr("CAR");
	bool bBYM = oldRun.admMod == tr("BYM");
	newRunDialog->admRadioButton->setChecked(bAdm);	
	newRunDialog->trendDegreeLabel->setEnabled(bAdm);
	newRunDialog->trendDegreeComboBox->setEnabled(bAdm);
	newRunDialog->predGroupBox->setEnabled(bAdm);	
	newRunDialog->mGroupBox->setEnabled(bAdm);
	newRunDialog->carRadioButton->setEnabled(bAdm && !bNoAdm);
	newRunDialog->bymRadioButton->setEnabled(bAdm && !bNoAdm);	
	newRunDialog->carRadioButton->setChecked(bCAR);
	newRunDialog->bymRadioButton->setChecked(bBYM);
	newRunDialog->rLineEdit->setText(oldRun.N);
	
	newRunDialog->scriptCheckBox->setCheckState(oldRun.script ? Qt::Checked : Qt::Unchecked);
	bool scriptChecked = newRunDialog->scriptCheckBox->checkState() == Qt::Checked;
	newRunDialog->kLineEdit->setText(oldRun.baseK);
	newRunDialog->toKLabel->setEnabled(scriptChecked);
	newRunDialog->toKLineEdit->setEnabled(scriptChecked);
	newRunDialog->toKLineEdit->setText(oldRun.toK);
		
	newRunDialog->trendDegreeComboBox->setCurrentIndex(oldRun.trendDegree.toInt());
		
// 	newRunDialog->dLineEdit->setText(oldRun.D);
	newRunDialog->sLineEdit->setText(oldRun.S);
	newRunDialog->bLineEdit->setText(oldRun.B);
	newRunDialog->zCheckBox->setCheckState(oldRun.C ? Qt::Checked : Qt::Unchecked);
	newRunDialog->njCheckBox->setCheckState(oldRun.NJ ? Qt::Checked : Qt::Unchecked);
	newRunDialog->path = project.path;
	newRunDialog->znoAdm = project.znoAdm;
	newRunDialog->zadmCAR = project.zadmCAR;
	newRunDialog->zadmBYM = project.zadmBYM;
        newRunDialog->mlAdmCAR = project.mlAdmCAR;
	newRunDialog->mlAdmBYM = project.mlAdmBYM;
	newRunDialog->mlnoAdm = project.mlnoAdm;
	
	newRunDialog->mapLineEdit->setText(oldRun.map);
	
	if (!QFile::exists(project.path + "/" + project.znoAdm) &&  !QFile::exists(project.path + "/" + project.zadmCAR) && !QFile::exists(project.path + "/" + project.zadmBYM))
	{
		newRunDialog->zCheckBox->setDisabled(true);
	}
	
	if (newRunDialog->exec() == QDialog::Accepted)
	{
		
		clearInfoWindow();

		if (!generateVNC())
		{
			infoTextEdit->append(tr("Cannot run project!\n"));
			delete newRunDialog;
			return;
		}

				
        newRun.q = newRunDialog->admRadioButton->isChecked();
		
		newRun.trendDegree = QString("%1").arg(newRunDialog->trendDegreeComboBox->currentIndex());
		newRun.sigma = newRunDialog->sigma;
                newRun.scOpt = newRunDialog->scOption;

		if (newRunDialog->admRadioButton->isChecked())
		{
			newRun.T = tr("with Admixture");
			if (newRunDialog->carRadioButton->isChecked())
			{
				newRun.admMod = tr("CAR");
			}
			if (newRunDialog->bymRadioButton->isChecked())
			{
				newRun.admMod = tr("BYM");
			}
		}
		if (newRunDialog->noAdmRadioButton->isChecked())
		{
			newRun.T = tr("without Admixture");
			newRun.admMod = tr("noAdm");
		}

		newRun.script = newRunDialog->scriptCheckBox->checkState() == Qt::Checked;
		newRun.N = newRunDialog->rLineEdit->text();
		newRun.baseK = newRunDialog->kLineEdit->text();
		
		currMRun = 0;
		newRun.K = newRun.baseK;
		
		if (newRun.script)
		{
			newRun.toK = newRunDialog->toKLineEdit->text();
			totMRun = (newRun.toK.toInt() - newRun.baseK.toInt() + 1)*newRun.N.toInt();
		}
		else
		{
			totMRun = newRun.N.toInt();
		}

		
		
		newRun.P = newRunDialog->psi;
		newRun.updateParameters = newRunDialog->updateSigma;
		newRun.updatePsiParameter = newRunDialog->updatePsi;
		newRun.D = newRunDialog->lambda;
		newRun.S = newRunDialog->sLineEdit->text();
		newRun.B = newRunDialog->bLineEdit->text();

		newRun.C = newRunDialog->zCheckBox->checkState() == Qt::Checked;
		newRun.NJ = newRunDialog->njCheckBox->checkState() == Qt::Checked;
		
		newRun.map = newRunDialog->mapLineEdit->text();
		performMRun();
	}
	
	delete newRunDialog;
	
}

void TESSGUI::abort()
{
	int response = QMessageBox::question(this, GUI_TITLE, 
		tr("Do you really want to abort the run(s)?\n\n"
		"Please note that if you choose to abort runs,\n" 
		"all results for the current run will be deleted\n"
		"and all the rest runs (if any) will be aborted."), 
		QMessageBox::Yes, QMessageBox::No);
	if (response == QMessageBox::Yes)  //  && cleState != QProcess::NotRunning
	{
		// Abort the current run by killing the running process.
		cle->kill();

		// Abort the rest runs, if any.
// 		currMRun = newRun.N.toInt();
		currMRun = totMRun;
		
		// Delete all result files.
		removeRunDir(project.path + "/" + newRun.name);
	}
}


bool TESSGUI::summaryRangeUpdated()
{
	summaryLowerRange = summaryDialog->lowerComboBox->currentIndex();
	summaryUpperRange = summaryDialog->upperComboBox->currentIndex();
	
	
	if (summaryLowerRange < 0 || summaryUpperRange < 0 )
	{
		return false;
	}
	
	if (summaryUpperRange < summaryLowerRange) 
	{
		QMessageBox::warning(this,GUI_TITLE,tr("The upper range must be greater than the lower range!"));
		return false;
	}
	
	summaryDialog->percentageComboBox->setCurrentIndex(9);
	updateSummaryTable();
	populateCandidateRuns(summaryDialog->KmaxComboBox->currentIndex());
	return true;
}


void TESSGUI::updateSummaryTable()
{
	int nbRun = (summaryUpperRange-summaryLowerRange)+1;
	summaryDialog->summaryTable->setRowCount((summaryUpperRange-summaryLowerRange)+1);
	//populate the summary table and compute average DIC
	double avgDIC = 0.0;
	
	int DICmaxDigits = 0;
	int KmaxDigits = 0;
	//First pass to determine number of digits for proper sort
	for (int j = 0; j <= (summaryUpperRange-summaryLowerRange); j++)
	{
		int i = j + summaryLowerRange;
		QString currDIC = project.runs[i].DIC;
		
		int toCut = currDIC.indexOf('.');
		currDIC = currDIC.left(toCut); 	//only keep digits before decimals
		QString currK = project.runs[i].K;
		if (currDIC.size() > DICmaxDigits)
		{
			DICmaxDigits = currDIC.size();
		}
		if (currK.size() > KmaxDigits)
		{
			KmaxDigits = currK.size();
		}
	}
	
	
	for (int j = 0; j <= (summaryUpperRange-summaryLowerRange); j++)
	{
		int i = j + summaryLowerRange;
		
		//run names
		QTableWidgetItem *name = new QTableWidgetItem(tr("%1").arg(project.runs[i].name));
		name->setFlags(Qt::ItemIsEnabled);
		summaryDialog->summaryTable->setItem(j,0,name);
		
		//run max num of clusters
		QTableWidgetItem *maxK = new QTableWidgetItem(tr("%1").arg(project.runs[i].K,KmaxDigits,QChar('0')));
		maxK->setFlags(Qt::ItemIsEnabled);
		summaryDialog->summaryTable->setItem(j,1,maxK);
		
		//run DIC
		QTableWidgetItem *dic = new QTableWidgetItem(tr("%1").arg(project.runs[i].DIC, DICmaxDigits, QChar('0')));
		dic->setFlags(Qt::ItemIsEnabled);
		summaryDialog->summaryTable->setItem(j,2,dic);
		
		//run LL Hist
		QTableWidgetItem *llHist = new QTableWidgetItem(tr("%1").arg(project.runs[i].LH));
		llHist->setFlags(Qt::ItemIsEnabled);
		summaryDialog->summaryTable->setItem(j,3,llHist);
					
		//run HC
		QTableWidgetItem *hc = new QTableWidgetItem(tr("%1").arg(project.runs[i].HC));
		hc->setFlags(Qt::ItemIsEnabled);
		summaryDialog->summaryTable->setItem(j,4,hc);
		
		//run assigment probas
		QTableWidgetItem *ap = new QTableWidgetItem(tr("%1").arg(project.runs[i].AP));
		ap->setFlags(Qt::ItemIsEnabled);
		summaryDialog->summaryTable->setItem(j,5,ap);
		
		//Used admixture?
// 		QTableWidgetItem *ad = new QTableWidgetItem(tr("%1").arg(project.runs[i].q ? "yes" : "no"));
// 		ad->setFlags(Qt::ItemIsEnabled);
// 		summaryDialog->summaryTable->setItem(j,6,ad);
				
		//Degree of trend?
		QTableWidgetItem *td = new QTableWidgetItem(tr("%1").arg(project.runs[i].trendDegree));
		td->setFlags(Qt::ItemIsEnabled);
		summaryDialog->summaryTable->setItem(j,6,td);
		
		//Model of admixture
		QTableWidgetItem *adMod;
		if (project.runs[i].q)
		{
			 adMod = new QTableWidgetItem(tr("%1").arg(project.runs[i].admMod));
		}
		else
		{
			adMod = new QTableWidgetItem(tr("noAdm"));
		}
		adMod->setFlags(Qt::ItemIsEnabled);
		summaryDialog->summaryTable->setItem(j,7,adMod);
		avgDIC += project.runs[i].DIC.toDouble();
	}
	
	//Display average DIC
	avgDIC /= (double)(summaryUpperRange-summaryLowerRange +1);
	summaryDialog->avgDICTextEdit->setText(QString(tr("%1").arg(avgDIC)));
	summaryDialog->summaryTable->resizeColumnToContents(0);
	summaryDialog->summaryTable->resizeColumnToContents(2);
}

bool TESSGUI::initSummary()
{
	
	int size = project.runs.size();
	if (size < 0)
	{
		return false;
	} 
	
	
	if (size > 0)
	{
		int numDigits = int(log10(double(size)) + 1);
		set<int> setKmax;
		for (int i = 0; i < size; i++)
		{
			QString currentItem = project.runs[i].name;
			int toCut = currentItem.lastIndexOf('_') + 1;
			currentItem.remove(0,toCut); 
			summaryDialog->lowerComboBox->addItem(QString("%1").arg(currentItem.toInt(), numDigits, 10, QChar('0')));
			
			summaryDialog->upperComboBox->addItem(QString("%1").arg(currentItem.toInt(), numDigits, 10, QChar('0')));
			
			setKmax.insert(project.runs[i].K.toInt());
		}
		
		set<int>::iterator KmaxIterator;
		for( KmaxIterator = setKmax.begin(); KmaxIterator != setKmax.end(); KmaxIterator++ ) {
			summaryDialog->KmaxComboBox->addItem(QString("%1").arg(*KmaxIterator));//, numDigits, 10, QChar('0')));
		}  
		
		summaryDialog->KmaxComboBox->setCurrentIndex(0);
		summaryDialog->lowerComboBox->setCurrentIndex(0);
		summaryDialog->upperComboBox->setCurrentIndex((size - 1));
	}
	
	else
	{
		summaryDialog->KmaxComboBox->setCurrentIndex(0);
		summaryDialog->lowerComboBox->setCurrentIndex(0);
		summaryDialog->upperComboBox->setCurrentIndex(0);
	}
	
	summaryLowerRange = summaryDialog->lowerComboBox->currentIndex();
	summaryUpperRange = summaryDialog->upperComboBox->currentIndex();
	
	summaryDialog->percentageComboBox->setCurrentIndex(9);
	if (size > 0)
	{
		updateSummaryTable();
		populateCandidateRuns(summaryDialog->KmaxComboBox->currentIndex());
	}
	
	connect(summaryDialog->lowerComboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(summaryRangeUpdated()));
	connect(summaryDialog->upperComboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(summaryRangeUpdated()));
	connect(summaryDialog->summaryTable, SIGNAL(itemDoubleClicked(QTableWidgetItem *)), this, SLOT(loadSummaryItem(QTableWidgetItem *)));
	
	connect(summaryDialog->percentageComboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(filterCandidateRuns(int)));
	
	connect(summaryDialog->KmaxComboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(populateCandidateRuns(int)));
	connect(summaryDialog->toClumppPushButton, SIGNAL(clicked()),this,SLOT(exportToClumppPopfile()));
	connect(summaryDialog->toTextPushButton, SIGNAL(clicked()),this,SLOT(exportTableToText()));
	
	//init tableDIC
	vector < double > EmptyVect;
	for (int k=0; k < (KMAX - 1); k ++)
	{	
		tableDIC.push_back(EmptyVect);
	}
	
	return true;
}

void TESSGUI::summarize()
{
	int size = project.runs.size();
	if (size <= 0)
	{
		QMessageBox::warning(this,GUI_TITLE,tr("Nothing to summarize!"));
		return;
	}
	updateSummaryTable();
	summaryDialog->show();
	summaryOpened = true;
	updateMenus();
}

void TESSGUI::removeRunFromSummaryTable(int runLabel, int Kremoved)
{
	int size = project.runs.size(); //one run has just been removed...
	
	summaryDialog->upperComboBox->removeItem(runLabel);
	summaryDialog->lowerComboBox->removeItem(runLabel);
	
	QString removedK = QString("%1").arg(Kremoved);//, numDigits, 10, QChar('0'));
	
	
	bool removeKfromComboBox = true;
	for (int i = 0; i < size; i ++)
	{
		if (removedK.toInt() == project.runs[i].K.toInt())
		{
			//another run with same value of Kmax: we do nothing
			removeKfromComboBox = false;
			break;
		}
	}
	
	
	if (removeKfromComboBox)
	{
		int removeIndex = summaryDialog->KmaxComboBox->findText(removedK);
		summaryDialog->KmaxComboBox->removeItem(removeIndex);
	}
	
	
	if (size > 0)
	{
		summaryDialog->percentageComboBox->setCurrentIndex(9);
		//updateSummaryTable();
	}

	
	else
	{
		if (summaryOpened)
		{
			summaryDialog->close();
			summaryOpened = false;
		}
	}
}

void TESSGUI::addRunToSummaryTable()
{
	int size = project.runs.size();
	int numDigits = int(log10(double(size)) + 1);

	
	QString currentItem = project.runs[size-1].name;
	int toCut = currentItem.lastIndexOf('_') + 1;
	currentItem.remove(0,toCut); 
	
	summaryDialog->upperComboBox->addItem(QString("%1").arg(currentItem.toInt(), numDigits, 10, QChar('0')));
	summaryDialog->lowerComboBox->addItem(QString("%1").arg(currentItem.toInt(), numDigits, 10, QChar('0')));			
	

	//If we were on the last run, increment
	if (summaryDialog->upperComboBox->currentIndex() == summaryDialog->upperComboBox->count()-2)
	{
		summaryDialog->upperComboBox->setCurrentIndex(summaryDialog->upperComboBox->count()-1);
	}
	
	int currentK = project.runs[size-1].K.toInt();
// 	int numDigitsK = int(log10(double(currentK)) + 1);
	
	QString currK = QString("%1").arg(currentK);//, numDigitsK, 10, QChar('0'));
	
	
	//Insert the value of Kmax to the comboBox to the correct place if it's not already in it. The comboBox is initially sorted.
	//If it's empty, add it, else look for it and add it if not already in
	if (summaryDialog->KmaxComboBox->count() == 0)
	{
		summaryDialog->KmaxComboBox->addItem(currK);
	}
	
	
	else if (summaryDialog->KmaxComboBox->findText(currK) == -1)
	{
		//Item is not in the comboBox
		int nbUniqueKmax = summaryDialog->KmaxComboBox->count();
		bool found = false;
		for (int k = 0; k < nbUniqueKmax; k++)
		{
			int Kmax = summaryDialog->KmaxComboBox->itemText(k).toInt();
			if (currK.toInt() < Kmax)
			{
				summaryDialog->KmaxComboBox->insertItem(k,currK);
				found = true;
				break;
			}
		}
		if (!found)
		{
			summaryDialog->KmaxComboBox->addItem(currK);
		}
	}
	summaryDialog->percentageComboBox->setCurrentIndex(9);
	//updateSummaryTable();
}

void TESSGUI::populateCandidateRuns(int KmaxIndex)
{
	if (KmaxIndex < 0)
	{
		return;
	}
	summaryDialog->candidateListWidget->clear();
	summaryDialog->exportListWidget->clear();
	int Kmax = summaryDialog->KmaxComboBox->itemText(KmaxIndex).toInt();
	//int lower = summaryDialog->lowerComboBox->currentIndex();
	//int upper = summaryDialog->upperComboBox->currentIndex();
	//QString lowerText = summaryDialog->summaryTable->item(0,0)->text();
	//QString upperText = summaryDialog->summaryTable->item(summaryDialog->summaryTable->rowCount()-1,0)->text();
	//lowerText=lowerText.right(lowerText.size() - lowerText.lastIndexOf('0',-2) - 1);
	//upperText=upperText.right(upperText.size() - upperText.lastIndexOf('0',-2) - 1);
	
	//int lower = lowerText.toInt();
	//int upper = upperText.toInt();
	
	int runNumber = summaryDialog->summaryTable->rowCount();
	QString runName;
	int size = project.runs.size();
	for (int i = 0; i < runNumber; i++)
	{
		runName = summaryDialog->summaryTable->item(i,0)->text();
		//cout << "Run name= " << runName.toStdString() << endl;
		for (int j = 0; j < size; j++)
		{
			if (project.runs[j].name == runName && project.runs[j].K.toInt() == Kmax)
			{
				QString currentItem = project.runs[j].name;
				summaryDialog->candidateListWidget->addItem(currentItem);
				break;
			}
		}
	}
	
	//cout <<"Populate test lower " << lowerTest.toInt() << " populate test upper " << upperTest.toInt() << endl; 
	
//	for (int i = lower; i <= upper; i++)
//	{
//		if (project.runs[i].K.toInt() == Kmax)
//		{
//			QString currentItem = project.runs[i].name;
//			summaryDialog->candidateListWidget->addItem(currentItem);
//		}
//	}
}

void TESSGUI::filterCandidateRuns(int percentageIndex)
{
	if (percentageIndex < 0)
	{
		return;
	}
	//int Kmax = summaryDialog->KmaxComboBox->currentText().toInt();
	int Kmax = 0;
	int KmaxIndex = summaryDialog->KmaxComboBox->currentIndex();
	updateSummaryTable();
	populateCandidateRuns(KmaxIndex);
	QString percentage = summaryDialog->percentageComboBox->itemText(percentageIndex);
	percentage.chop(1);
	
	//int nbCandidates = summaryDialog->candidateListWidget->count();
	int nbCandidates = summaryDialog->summaryTable->rowCount();
	
	if (nbCandidates == 0)
	{
		return;
	}
	if (percentage.toInt() == 100)
	{
		return;
	}
	
	int size = project.runs.size();
	QStringList candidateList;
	double avgDIC = 0.0;
	
	for (int i = 0; i < nbCandidates; i++)
	{
		for (int j = 0; j < size; j ++)
		{
			//if (project.runs[j].name == summaryDialog->candidateListWidget->item(i)->text())
			if (project.runs[j].name == summaryDialog->summaryTable->item(i,0)->text())
			{
				candidateList << QString("%1").arg(j);
				avgDIC += project.runs[i].DIC.toDouble();
				break;
			}
		}
	}
	
	updateDICTable(candidateList,Kmax);
	//int sizeOfCandidates = candidateList.size(); 
	
	//int indexMaxDIC = floor(sizeOfCandidates*(double)(percentage.toInt()/100.0));
	int indexMaxDIC = floor(nbCandidates*(double)(percentage.toInt()/100.0));
	double maxDIC = tableDIC[Kmax][indexMaxDIC]; //all runs with DIC > maxDIC are rejected
	
	//QList < QListWidgetItem*> runsToReject;
	QList < QTableWidgetItem*> runsToReject;
	for (int i = 0; i < nbCandidates; i ++)
	{
		int runIndex = candidateList[i].toInt();
		if (project.runs[runIndex].DIC.toDouble() >= maxDIC)
		{	
			//runsToReject << summaryDialog->candidateListWidget->item(i);
			runsToReject << summaryDialog->summaryTable->item(i,0);
			avgDIC -= project.runs[runIndex].DIC.toDouble();
		}
	}
	
	if (runsToReject.size() < nbCandidates)
	{
		avgDIC /= (nbCandidates - runsToReject.size());
	}
	else
	{
		avgDIC = -1.0;
	}
	
	
	for (int i = 0; i < runsToReject.size(); i ++)
	{
		//summaryDialog->candidateListWidget->takeItem(summaryDialog->candidateListWidget->row(runsToReject.at(i)));
		summaryDialog->summaryTable->removeRow(summaryDialog->summaryTable->row(runsToReject.at(i)));
		
	}
	populateCandidateRuns(KmaxIndex);
	summaryDialog->candidateListWidget->sortItems();
	
	//Update average DIC
	summaryDialog->avgDICTextEdit->setText(QString(tr("%1").arg(avgDIC)));
}

void TESSGUI::updateDICTable(QStringList candidateList, int Kmax)
{
	//Prerequisite: ALL RUNS BETWEEN LOWER AND UPPER HAVE SAME VALUE FOR KMAX (should be always true); Kmax=0 corresponds to all runs
	tableDIC[Kmax].clear();
		
	int sizeOfCandidates = candidateList.size();

	for (int i = 0; i < sizeOfCandidates; i++)
	{
		int runIndex = candidateList[i].toInt();
		int currK = project.runs[runIndex].K.toInt();
		if (Kmax !=0 && currK != Kmax)
		{
			QMessageBox::warning(this, GUI_TITLE, 
					     tr("Internal Error! Please Select Runs to Export Manually."));
			return;
		}
		
		tableDIC[Kmax].push_back(project.runs[runIndex].DIC.toDouble());
	}
		
	sort(tableDIC[Kmax].begin(),tableDIC[Kmax].end());
}

void TESSGUI::exportTableToText()
{
	QString saveFileName = QFileDialog::getSaveFileName(this, tr("Save Table"), summaryDialog->commonPath);
	if (saveFileName.isEmpty())
	{
		QMessageBox::warning(this, GUI_TITLE, 
				     tr("Cannot open/create file %1! Check your rights")
						     .arg(summaryDialog->popfileLineEdit->text()));
		return;
	}
	QFile saveFile(saveFileName);
	if (!saveFile.open(QFile::WriteOnly | QFile::Text)) 
	{
		QMessageBox::warning(this, GUI_TITLE, 
				     tr("Cannot open file %1!")
						     .arg(summaryDialog->popfileLineEdit->text()));
		return;
	}
	
	QTextStream out(&saveFile);
	
	out << "Labels" << '\t' << "Kmax" << '\t' << "DIC" << '\t' << "Trend_Degree" << '\t' <<"Model" << endl;
	
	int nRow = summaryDialog->summaryTable->rowCount();
	//We export columns number 0,1,2,6,7
	for (int i=0; i < nRow; i++)
	{
		out << summaryDialog->summaryTable->item(i,0)->text() << '\t';
		out << summaryDialog->summaryTable->item(i,1)->text() << '\t';
		out << summaryDialog->summaryTable->item(i,2)->text() << '\t';
		out << summaryDialog->summaryTable->item(i,6)->text() << '\t';
		out << summaryDialog->summaryTable->item(i,7)->text() << endl;
	}
	saveFile.close();
	QMessageBox::information(this, GUI_TITLE, tr(" Success! "));
	return;
}

void TESSGUI::exportToClumppPopfile()
{	
	QFile popfile(summaryDialog->popfileLineEdit->text());
		
	if (!popfile.open(QFile::WriteOnly | QFile::Text)) 
	{
		QMessageBox::warning(this, GUI_TITLE, 
				     tr("Cannot open popfile %1!")
						     .arg(summaryDialog->popfileLineEdit->text()));
		return;
	}
		
	int nbExport = summaryDialog->exportListWidget->count();
	if (nbExport <=0)
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Nothing to export!"));
		return;
	}
	
	int size = project.runs.size();
	QStringList exportList;
	for (int i = 0; i < nbExport; i++)
	{
		for (int j = 0; j < size; j++)
		{
			if (project.runs[j].name == summaryDialog->exportListWidget->item(i)->text())
			{
				exportList << QString("%1").arg(j);
				break;
			}
		}
	}
	QTextStream out(&popfile);
	int indNumber = project.N.toInt();
	for (int i = 0; i < nbExport; i++)
	{
		int runIndex = exportList[i].toInt();
		QString fullPath = project.path + "/" + project.runs[runIndex].TR;
		QFile trFile(fullPath);
		trFile.open(QIODevice::ReadOnly);
		QTextStream in(&trFile);
		in.readLine();
		in.readLine();
		for (int n = 0; n < indNumber; n++)
		{
			out << in.readLine() << endl;
		}
		out << endl << endl;			
		trFile.close();
	}
	
	
	
	if (summaryDialog->writeParamfile->checkState() == Qt::Checked)
	{
		QString popfileName = QFileInfo(popfile).fileName();
		QString pathToPopfile = QFileInfo(popfile).absolutePath();
		QFile paramFile(pathToPopfile + "/paramfile");
		paramFile.open(QIODevice::WriteOnly);
		QTextStream paramStream(&paramFile);
		paramStream << "DATATYPE 1" << endl;
		paramStream << "INDFILE NOTNEEDED.indfile" << endl;
		paramStream << "POPFILE " << popfileName << endl;
		paramStream << "OUTFILE " << popfileName << ".outfile" << endl;
		paramStream << "MISCFILE NOTNEEDED.miscfile" << endl;
		paramStream << "K " << summaryDialog->KmaxComboBox->currentText().toInt() << endl;
		paramStream << "C " << indNumber << endl;
		paramStream << "R " << nbExport << endl;
		paramStream << "M 2 " << endl;
		paramStream << "W 0" << endl; 
		paramStream << "S 2" << endl;
		paramStream << "GREEDY_OPTION 2 " << endl;
		paramStream << "REPEATS 20 " << endl;
		paramStream << "PERMUTATIONFILE NOTNEEDED.permutationfile " << endl;
		paramStream << "PRINT_PERMUTED_DATA 0 " << endl;
		paramStream << "PERMUTED_DATAFILE " << popfileName << ".perm_datafile"  << endl;
		paramStream << "PRINT_EVERY_PERM 0 " << endl;
		paramStream << "EVERY_PERMFILE " << popfileName << ".every_permfile" << endl;
		paramStream << "PRINT_RANDOM_INPUTORDER 0 " << endl;
		paramStream << "RANDOM_INPUTORDERFILE " << popfileName <<".random_inputorderfile" << endl;
		paramStream << "OVERRIDE_WARNINGS 0 " << endl;
		paramStream << "ORDER_BY_RUN 0" << endl; 					
							
		paramFile.close();
	}
	popfile.close();
	QMessageBox::information(this, GUI_TITLE, tr(" Success! "));
	return;
}

void TESSGUI::computeGeo()
{
	GeoDialog *geoDialog = new GeoDialog;
	if (geoDialog->exec() == QFileDialog::Accepted)
	{
		
		QFile sf(geoDialog->sfLineEdit->text());
		
		if (!sf.open(QFile::ReadOnly | QFile::Text)) 
		{
			QMessageBox::warning(this, GUI_TITLE, 
					     tr("Cannot open the spatial information file %1!")
							     .arg(geoDialog->sfLineEdit->text()));
			delete geoDialog;
			return;
		}
		
		QTextStream sfStream(&sf);
		
		
		const int N = geoDialog->nLineEdit->text().toInt();
		const int A = geoDialog->aLineEdit->text().toInt();
		const int R = geoDialog->rLineEdit->text().toInt();
		const int C = geoDialog->cLineEdit->text().toInt();
		int i,j,r,c,a;
				
		
		infoTextEdit->append(tr("Computing pairwise geographic distances from data... "));
		QApplication::setOverrideCursor(Qt::WaitCursor);
		
		
		DBL_VCTR_2D coord; //matrix contraining individual's coordinates
		InitVctr2D(coord,N,2,0.0);
		
		QString xcoord;
		QString ycoord;
		QString sfLine;
		int tabIndex,spaceIndex,indexLeft,indexMid;
		bool specialFormat = geoDialog->specialCheckBox->isChecked();
		bool isRecessive = geoDialog->recessiveCheckBox->isChecked();
		
		//discard extra rows in the input file
		for (r = 0; r < R; r++)
		{
			sfStream.readLine();
		}
		
		if (isRecessive)
		{
			//not needed here
			sfStream.readLine();
		}
		
		
		for (i = 0; i < N; i++)
		{
			if (!specialFormat)
			{
				for (a = 0; a < A; a++)
				{
					//Remove the extra columns
					for (c = 0; c < C; c++)
					{
						QString extraCol;
						sfStream >> extraCol;
					}
				
					sfLine = sfStream.readLine();
				
				}
				if (sfLine[0] ==  QChar(' ') || sfLine[0] ==  QChar('\t')) {
					sfLine = sfLine.remove(0,1);
				}
			}
			else
			{
				//Remove the extra columns
				for (c = 0; c < C; c++)
				{
					QString extraCol;
					sfStream >> extraCol;
				}
				
				sfLine = sfStream.readLine();
				if (sfLine[0] ==  QChar(' ') || sfLine[0] ==  QChar('\t')) {
					sfLine = sfLine.remove(0,1);
				}
			}
			
			//xcoord
			tabIndex = sfLine.indexOf('\t');
			spaceIndex = sfLine.indexOf(' ');
			if (tabIndex == -1 && spaceIndex == -1)
			{
				QMessageBox::warning(this, GUI_TITLE, 
						tr("Input file %1 format incorrect. Columns should be separated by spaces or tabs")
								.arg(geoDialog->sfLineEdit->text()));
				QApplication::restoreOverrideCursor();
				delete geoDialog;
				return;
			}
			
			if (tabIndex == -1)  
			{
				indexLeft = spaceIndex;
			}
			else
			{
				indexLeft = tabIndex;
			}
			xcoord = sfLine.left(indexLeft);
			
			//ycoord
			tabIndex = sfLine.indexOf('\t',(indexLeft+1));
			spaceIndex = sfLine.indexOf(' ',(indexLeft+1));
			
			if (tabIndex == -1 && spaceIndex == -1)
			{
				QMessageBox::warning(this, GUI_TITLE, 
						tr("Input file %1 format incorrect. Columns should be separated by spaces or tabs")
								.arg(geoDialog->sfLineEdit->text()));
				QApplication::restoreOverrideCursor();
				delete geoDialog;
				return;
			}
			
			if (tabIndex == -1)  
			{
				indexMid = spaceIndex;
			}
			else
			{
				indexMid = tabIndex;
			}
			
			ycoord = sfLine.mid((indexLeft+1),(indexMid-indexLeft-1));
			
			coord[i][0] = xcoord.toDouble();
			coord[i][1] = ycoord.toDouble();
		}
		sf.close();
		
		QFile rf(geoDialog->rfLineEdit->text());
		if (!rf.open(QFile::WriteOnly | QFile::Text)) 
		{
			QMessageBox::warning(this, GUI_TITLE, 
					     tr("Cannot open the result file %1!")
							     .arg(geoDialog->rfLineEdit->text()));
			QApplication::restoreOverrideCursor();
			delete geoDialog;
			return;
		}
		QTextStream rfStream(&rf);
		
		//Now, compute the geographic distances ...
		DBL_VCTR_2D dist;
		InitVctr2D(dist,N,N,0.0);
			
		if (geoDialog->gcRadioButton->isChecked())
		{
			//great circle distances
			bool longFirst = true;
			computeGCDist(coord,dist,longFirst);
		}
		if (geoDialog->euclRadioButton->isChecked())
		{
			//euclidian distances
			computeEuclidianDist(coord,dist);
		}
			
			
		//Now let's store the result in a file
		for (i = 0;i < N; i++)
		{
			for (j=0; j < N; j++)
			{
				rfStream << dist[i][j] << ' ';
			}
			rfStream << '\n';
		}
		
		
		rfStream.flush();
		rf.close();
		infoTextEdit->append(tr("done !\n"));
		QApplication::restoreOverrideCursor();
		
		bool showResult = geoDialog->showResult->checkState() == Qt::Checked;
		if (showResult)
		{
			loadData(geoDialog->rfLineEdit->text());
			workspace->tile();
		}
		
	}
	
	delete geoDialog;
}

void TESSGUI::generate()
{
	GenerateDialog *generateDialog = new GenerateDialog;
	if (generateDialog->exec() == QFileDialog::Accepted)
	{
		QApplication::setOverrideCursor(Qt::WaitCursor);

		QList< SPATIAL_INFO > siData;
		QFile sf(generateDialog->sfLineEdit->text());
		if (!sf.open(QFile::ReadOnly | QFile::Text)) 
		{
			QMessageBox::warning(this, GUI_TITLE, 
				tr("Cannot open the spatial information file %1!")
				.arg(generateDialog->sfLineEdit->text()));
			delete generateDialog;
			return;
		}
		QTextStream sfStream(&sf);
		int tniisf = 0;  // Total Number of Individuals in Spatial Information File
		int sfNumRow = generateDialog->sfNumRow;
		int i;
		for (i = 0; i < sfNumRow; i++)
		{
			SPATIAL_INFO si;
			sfStream >> si.num 
				>> si.xMin >> si.xMax >> si.xSigma >> si.yMin >> si.yMax >> si.ySigma;
			if (si.num < 1 || 
				si.xMin > si.xMax || si.xSigma < 0.0 || 
				si.yMin > si.yMax || si.ySigma < 0.0)
			{
				QMessageBox::warning(this, GUI_TITLE, 
					tr("Error in the spatial information file %1!")
					.arg(generateDialog->sfLineEdit->text()));
				sf.close();
				QApplication::restoreOverrideCursor();
				delete generateDialog;
				return;
			}
			tniisf += si.num;
			siData.push_back(si);
		}
		sf.close();
		int tniigf = 0;  // Total Number of Individuals in Genetic Information File
		tniigf = generateDialog->nLineEdit->text().toInt() +
			generateDialog->dLineEdit->text().toInt();
		if (tniisf != tniigf)
		{
			QMessageBox::warning(this, GUI_TITLE, 
				tr("Total number of individuals specified in the spatial information file\n"
				   "DOES NOT match that specified in the genetic information file!"));
			QApplication::restoreOverrideCursor();
			delete generateDialog;
			return;
		}
		double const FACTOR = 1.5;
		double dataXMin = +1.0E300;
		double dataXMax = -1.0E300;
		double dataYMin = +1.0E300;
		double dataYMax = -1.0E300;
		for (i = 0; i < sfNumRow; i++)
		{
			if (dataXMin > siData[i].xMin)
			{
				dataXMin = siData[i].xMin;
			}
			if (dataXMax < siData[i].xMax)
			{
				dataXMax = siData[i].xMax;
			}
			if (dataYMin > siData[i].yMin)
			{
				dataYMin = siData[i].yMin;
			}
			if (dataYMax < siData[i].yMax)
			{
				dataYMax = siData[i].yMax;
			}
			siData[i].xMu = (siData[i].xMin + siData[i].xMax) / 2.0;
			siData[i].yMu = (siData[i].yMin + siData[i].yMax) / 2.0;
			// Automatically Generating xSigmas and ySigmas for Unspecified Regions
			// No Effects for Points
			if (siData[i].xSigma == 0.0)
			{
				siData[i].xSigma = (siData[i].xMax - siData[i].xMin) / 2.0 / FACTOR;
			}
			if (siData[i].ySigma == 0.0)
			{
				siData[i].ySigma = (siData[i].yMax - siData[i].yMin) / 2.0 / FACTOR;
			}
		}
		double sum, avg;
		int cnt;
		// Automatically Generating xSigma and ySigma for Unspecified Points
		// Sigma as an Average of Those of Regions and Specified Points
		// xSigma
		sum = 0.0;
		cnt = 0;
		for (i = 0; i < sfNumRow; i++)
		{
			if (siData[i].xSigma != 0.0)
			{
				sum += siData[i].xSigma;
				cnt++;
			}
		}
		if (cnt > 0)
		{
			avg = sum / cnt;
		}
		else  // All Points
		{
			avg = (dataXMax - dataXMin) / sfNumRow / 2.0 / FACTOR;
		}
		for (i = 0; i < sfNumRow; i++)
		{
			if (siData[i].xSigma == 0.0)
			{
				siData[i].xSigma = avg;
			}
		}
		// ySigma
		sum = 0.0;
		cnt = 0;
		for (i = 0; i < sfNumRow; i++)
		{
			if (siData[i].ySigma != 0.0)
			{
				sum += siData[i].ySigma;
				cnt++;
			}
		}
		if (cnt > 0)
		{
			avg = sum / cnt;
		}
		else  // All Points
		{
			avg = (dataYMax - dataYMin) / sfNumRow / 2.0 / FACTOR;
		}
		for (i = 0; i < sfNumRow; i++)
		{
			if (siData[i].ySigma == 0.0)
			{
				siData[i].ySigma = avg;
			}
		}
		// Generating Spatial Coordinates
		vector< double > coordxs;
		vector< double > coordys;
		int j;
		for (i = 0; i < sfNumRow; i++)
		{
			if (siData[i].num == 1)
			{
				coordxs.push_back(siData[i].xMu);
				coordys.push_back(siData[i].yMu);
			}
			else
			{
				for (j = 0; j < siData[i].num; j++)
				{
					coordxs.push_back(siData[i].xMu + gsl_ran_gaussian(rng, siData[i].xSigma));
					coordys.push_back(siData[i].yMu + gsl_ran_gaussian(rng, siData[i].ySigma));
				}
			}
		}

		const int A = generateDialog->aLineEdit->text().toInt();
		const int L = generateDialog->lLineEdit->text().toInt();
		const int R = generateDialog->rLineEdit->text().toInt();
		const int C = generateDialog->cLineEdit->text().toInt();

		QFile gf(generateDialog->gfLineEdit->text());
		if (!gf.open(QFile::ReadOnly | QFile::Text)) 
		{
			QMessageBox::warning(this, GUI_TITLE, 
				tr("Cannot open the genetic information file %1!")
				.arg(generateDialog->gfLineEdit->text()));
			QApplication::restoreOverrideCursor();
			delete generateDialog;
			return;
		}
		QTextStream gfStream(&gf);
		QFile rf(generateDialog->rfLineEdit->text());
		if (!rf.open(QFile::WriteOnly | QFile::Text)) 
		{
			QMessageBox::warning(this, GUI_TITLE, 
				tr("Cannot open the result file %1!")
				.arg(generateDialog->rfLineEdit->text()));
			QApplication::restoreOverrideCursor();
			delete generateDialog;
			return;
		}
		QTextStream rfStream(&rf);
		for (int r = 0; r < R; r++)
		{
			QString extraRow = gfStream.readLine();
			rfStream << extraRow << '\n';
		}
		for (i = 0; i < tniigf; i++)
		{
			for (int a = 0; a < A; a++)
			{
				for (int c = 0; c < C; c++)
				{
					QString extraCol;
					gfStream >> extraCol;
					rfStream << extraCol << ' ';
				}
				rfStream << coordxs[i] << ' ' << coordys[i] << ' ';
				for (int l = 0; l < L; l++)
				{
					QString gDatum;
					gfStream >> gDatum;
					rfStream << gDatum << ' ';
				}
				if (generateDialog->aCheckBox->checkState() == Qt::Checked)
				{
					QString candidateLocus, phenotype;
					gfStream >> candidateLocus >> phenotype;
					rfStream << candidateLocus << ' ' << phenotype << ' ';
				}
				rfStream << '\n';
			}
		}
		gf.close();
		rfStream.flush();
		rf.close();

		QString graphFullName = generateDialog->resultPath + "/" 
			+ generateDialog->resultBase + ".png";
		double coordXMin = +1.0E300;
		double coordXMax = -1.0E300;
		double coordYMin = +1.0E300;
		double coordYMax = -1.0E300;
		for (i = 0; i < tniisf; i++)
		{
			if (coordxs[i] < coordXMin)
			{
				coordXMin = coordxs[i];
			}
			if (coordxs[i] > coordXMax)
			{
				coordXMax = coordxs[i];
			}
			if (coordys[i] < coordYMin)
			{
				coordYMin = coordys[i];
			}
			if (coordys[i] > coordYMax)
			{
				coordYMax = coordys[i];
			}
		}
		double coordXRange = coordXMax - coordXMin;
		double coordYRange = coordYMax - coordYMin;
		// Translate the XY coordinates to all positive values to circumvent the quirks of
		// ChartDirector in the XYChart.
		///////////////////////////////////////////////////////////////////////////////
		double xOffset = -coordXMin + coordXRange * 2.0;
		double yOffset = -coordYMin + coordYRange * 2.0;
		for (i = 0; i < tniisf; i++)
		{
			coordxs[i] += xOffset;
			coordys[i] += yOffset;
		}
		coordXMin += xOffset;
		coordXMax += xOffset;
		coordYMin += yOffset;
		coordYMax += yOffset;
		///////////////////////////////////////////////////////////////////////////////
		coordXMin -= 0.1 * coordXRange;
		coordXMax += 0.1 * coordXRange;
		coordYMin -= 0.1 * coordYRange;
		coordYMax += 0.1 * coordYRange;
		double dW = coordXMax - coordXMin;
		double dH = coordYMax - coordYMin;
		int nW;
		int nH;
		int nShortSide = 500;
		if (dW > dH)
		{
			nH = nShortSide;
			nW = int(nH * dW / dH + 0.5);
		}
		else
		{
			nW = nShortSide;
			nH = int(nW * dH / dW + 0.5);
		}
		int nXE = 50;
		int nYE = 50;
		XYChart* c = new XYChart(nW + 2 * nXE, nH + 2 * nYE, 0xFFFFCC, 0, 1);
		c->addTitle("Spatial Coordinates", "timesbi.ttf", 14, 0xFFFFFF)->setBackground(0x804020);
		c->setPlotArea(nXE, nYE, nW, nH, 0xFFFFFF, -1, -1, Transparent, Transparent);
		c->setClipping();
		c->xAxis()->setDateScale(coordXMin, coordXMax);
		c->xAxis()->setAutoScale(0.0, 0.0, 0.0);
		c->xAxis()->setTickDensity(nShortSide / 10);
		c->xAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
		c->yAxis()->setDateScale(coordYMin, coordYMax);
		c->yAxis()->setAutoScale(0.0, 0.0, 0.0);
		c->yAxis()->setTickDensity(nShortSide / 10);
		c->yAxis()->setColors(LineColor, Transparent, Transparent, Transparent);
		ScatterLayer* pslPoints = c->addScatterLayer(
			DoubleArray(&coordxs[0], tniisf),
			DoubleArray(&coordys[0], tniisf),
			"Coordinates", Chart::CircleSymbol, 5, 0xFF0000, 0x000000);
		c->makeChart(graphFullName.toAscii().constData());
		delete c;

		bool showResult = generateDialog->showResult->checkState() == Qt::Checked;
		if (showResult)
		{
			loadData(generateDialog->rfLineEdit->text());
		}
		bool showCoords = generateDialog->showCoords->checkState() == Qt::Checked;
		if (showCoords)
		{
			loadGraph(graphFullName);
		}
		if (showResult || showCoords)
		{
			workspace->tile();
		}

		QApplication::restoreOverrideCursor();
	}
	delete generateDialog;
}

void TESSGUI::resample()
{
	ResampleDialog *resampleDialog = new ResampleDialog;
	if (resampleDialog->exec() == QFileDialog::Accepted)
	{
		QApplication::setOverrideCursor(Qt::WaitCursor);

		const int N = resampleDialog->nLineEdit->text().toInt();
		const int D = resampleDialog->dLineEdit->text().toInt();
		const int A = resampleDialog->aLineEdit->text().toInt();
		const int L = resampleDialog->lLineEdit->text().toInt();
		const int R = resampleDialog->rLineEdit->text().toInt();
		const int C = resampleDialog->cLineEdit->text().toInt();
		const int S = resampleDialog->sLineEdit->text().toInt();

		vector< bool > flags(L, false);
		vector< int > src;
		int l;
		for (l = 0; l < L; l++)
		{
			src.push_back(l);
		}
		int s;
		if (resampleDialog->rRadioButton->isChecked())
		{
			vector< int > dst(S, 0);
			gsl_rng* rng = NULL;
			AllocRNG(rng, gsl_rng_ranlxs2);
			gsl_ran_choose(rng, &dst[0], S, &src[0], L, sizeof(int));
			FreeRNG(rng);
			for (l = 0; l < L; l++)
			{
				for (s = 0; s < S; s++)
				{
					if (l == dst[s])
					{
						flags[l] = true;
					}
				}
			}
		}
		if (resampleDialog->fRadioButton->isChecked())
		{
			for (s = 0; s < S; s++)
			{
				flags[s] = true;
			}
		}
		if (resampleDialog->mRadioButton->isChecked())
		{
			for (s = (L - S) / 2; s < (L + S) / 2; s++)
			{
				flags[s] = true;
			}
		}
		if (resampleDialog->lRadioButton->isChecked())
		{
			for (s = L - S; s < L; s++)
			{
				flags[s] = true;
			}
		}
		if (resampleDialog->sRadioButton->isChecked())
		{
			QList<QListWidgetItem *> selectedItems = 
				resampleDialog->sListWidget->selectedItems();
			const int S = selectedItems.size();  // New Local "S" in if () { }
			for (l = 0; l < L; l++)
			{
				for (s = 0; s < S; s++)
				{
					if (l == selectedItems[s]->text().toInt() - 1)
					{
						flags[l] = true;
					}
				}
			}
		}

		QFile df(resampleDialog->dfLineEdit->text());
		if (!df.open(QFile::ReadOnly | QFile::Text)) 
		{
			QMessageBox::warning(this, GUI_TITLE, 
				tr("Cannot open the data file %1!")
				.arg(resampleDialog->dfLineEdit->text()));
			QApplication::restoreOverrideCursor();
			delete resampleDialog;
			return;
		}
		QTextStream dfStream(&df);
		QFile rf(resampleDialog->rfLineEdit->text());
		if (!rf.open(QFile::WriteOnly | QFile::Text)) 
		{
			QMessageBox::warning(this, GUI_TITLE, 
				tr("Cannot open the result file %1!")
				.arg(resampleDialog->rfLineEdit->text()));
			QApplication::restoreOverrideCursor();
			delete resampleDialog;
			return;
		}
		QTextStream rfStream(&rf);
		for (int r = 0; r < R; r++)
		{
			QString extraRow = dfStream.readLine();
			rfStream << extraRow << '\n';
		}
		for (int i = 0; i < N + D; i++)
		{
			for (int a = 0; a < A; a++)
			{
				for (int c = 0; c < C; c++)
				{
					QString extraCol;
					dfStream >> extraCol;
					rfStream << extraCol << ' ';
				}
				if (resampleDialog->containSI->checkState() == Qt::Checked)
				{
					QString x, y;
					dfStream >> x >> y;
					rfStream << x << ' ' << y << ' ';
				}
				for (l = 0; l < L; l++)
				{
					QString datum;
					dfStream >> datum;
					if (flags[l])
					{
						rfStream << datum << ' ';
					}
				}
				if (resampleDialog->aCheckBox->checkState() == Qt::Checked)
				{
					QString candidateLocus, phenotype;
					dfStream >> candidateLocus >> phenotype;
					rfStream << candidateLocus << ' ' << phenotype << ' ';
				}
				rfStream << '\n';
			}
		}
		df.close();
		rfStream.flush();
		rf.close();

		bool showResult = resampleDialog->showResult->checkState() == Qt::Checked;
		if (showResult)
		{
			loadData(resampleDialog->rfLineEdit->text());
			workspace->tile();
		}

		QApplication::restoreOverrideCursor();
	}
	delete resampleDialog;
}

void TESSGUI::clearInfoWindow()
{
	infoTextEdit->clear();
	QFont courierFont("Courier", 9, QFont::Normal);
	infoTextEdit->setCurrentFont(courierFont);
}

void TESSGUI::openReference()
{
	QString referenceFilePath = QCoreApplication::applicationDirPath() + 
		tr("/manual.pdf");
	if (!QFile::exists(referenceFilePath))
	{
		QMessageBox::warning(this, GUI_TITLE, tr("Reference manual is missing!"));
		return;
	}
	QUrl url(referenceFilePath);
	QDesktopServices::openUrl(url);
}

void TESSGUI::about()
{
	AboutDialog *aboutDialog = new AboutDialog;
	aboutDialog->exec();
	delete aboutDialog;
}

void TESSGUI::updateMenus()
{
	// File Menu
	newProjectAct->setEnabled(cleState == QProcess::NotRunning && !modifying);
	openProjectAct->setEnabled(cleState == QProcess::NotRunning && !modifying);
	closeProjectAct->setEnabled(projectOpened && cleState == QProcess::NotRunning 
		&& !modifying);
	saveProjectAct->setEnabled(projectOpened && projectModified && 
		cleState == QProcess::NotRunning && !modifying);
	quitAct->setEnabled(cleState == QProcess::NotRunning && !modifying);

	// Project Menu
	modifyAct->setEnabled(projectOpened && cleState == QProcess::NotRunning 
		&& !modifying);
	runAct->setEnabled(projectOpened && cleState == QProcess::NotRunning && !modifying);
	abortAct->setEnabled(projectOpened && cleState != QProcess::NotRunning);
	bool hasRun = project.runs.size() > 0;
	summarizeAct->setEnabled(projectOpened && !modifying && !summaryOpened && hasRun);// && cleState == QProcess::NotRunning);
	
	
			
	// Window Menu
	bool hasChild = workspace->activeWindow() != 0;
	closeAct->setEnabled(hasChild);
	closeAllAct->setEnabled(hasChild);
	tileAct->setEnabled(hasChild);
	cascadeAct->setEnabled(hasChild);
	arrangeAct->setEnabled(hasChild);
	nextAct->setEnabled(hasChild);
	previousAct->setEnabled(hasChild);
	windowSeparatorAct->setVisible(hasChild);
}

void TESSGUI::updateWindowMenu()
{
	windowMenu->clear();
	windowMenu->addAction(closeAct);
	windowMenu->addAction(closeAllAct);
	windowMenu->addSeparator();
	windowMenu->addAction(tileAct);
	windowMenu->addAction(cascadeAct);
	windowMenu->addAction(arrangeAct);
	windowMenu->addSeparator();
	windowMenu->addAction(nextAct);
	windowMenu->addAction(previousAct);
	windowMenu->addAction(windowSeparatorAct);

	QList<QWidget *> windows = workspace->windowList();
	windowSeparatorAct->setVisible(!windows.isEmpty());

	for (int i = 0; i < windows.size(); i++) 
	{
		QWidget *child = windows.at(i);
		DataWindow *dataChild = qobject_cast<DataWindow *>(child);
		GraphWindow * graphChild = qobject_cast<GraphWindow *>(child);
		TextWindow * textChild = qobject_cast<TextWindow *>(child);

		QString fileName;
		if (dataChild)
		{
			fileName = dataChild->currentFile();
		}
		if (graphChild)
		{
			fileName = graphChild->currentFile();
		}
		if (textChild)
		{
			fileName = textChild->currentFile();
		}

		QString text;
		if (i < 9) 
		{
			text = tr("&%1 %2").arg(i + 1).arg(fileName);
		} 
		else 
		{
			text = tr("%1 %2").arg(i + 1).arg(fileName);
		}
		QAction *action  = windowMenu->addAction(text);
		action->setCheckable(true);
		action ->setChecked(child == workspace->activeWindow());
		connect(action, SIGNAL(triggered()), windowMapper, SLOT(map()));
		windowMapper->setMapping(action, child);
	}
}

void TESSGUI::loadSummaryItem(QTableWidgetItem *item)
{
	if (item->text().endsWith(".png"))
	{
		loadGraph(project.path + "/" + item->text());
	}
}

void TESSGUI::loadProjectItem(QTreeWidgetItem *item, int column)
{
	if (item->text(column).startsWith(tr("Project Data")))
	{
		loadData(project.path + "/" + project.data, project.C.toInt(), project.R.toInt());
	}
	if (item->text(column).endsWith(".png"))
	{
		int nIndex = item->text(column).indexOf(QString(": ")) + 2;
		loadGraph(project.path + "/" + item->text(column).mid(nIndex));
	}
	if (!item->text(column).startsWith(tr("Project Data")) && 
		    item->text(column).endsWith(".txt") && !item->text(column).startsWith(tr("Geographic")))
	{
		int nIndex = item->text(column).indexOf(QString(": ")) + 2;
		loadText(project.path + "/" + item->text(column).mid(nIndex));
	}
	
	if (item->text(column).startsWith(tr("Geographic")))
	{
		loadData(project.geoData);
	}
}

void TESSGUI::deleteRunItem(QString item)
{
	int Kremoved = 0;
	for (int i = 0; i < project.runs.size(); i++)
	{
		if (project.runs.at(i).name == item)
		{
			Kremoved = project.runs.at(i).K.toInt();
			project.runs.removeAt(i);
			removeRunFromSummaryTable(i,Kremoved);
			projectModified = true;
			saveProject();
			updateMenus();
			break;
		}
	}

	removeRunDir(project.path + "/" + item);
}

void TESSGUI::removeRunDir(QString dirName)
{
	QDir runDir(dirName);
	if (runDir.exists())
	{
		runDir.setFilter(QDir::Files | QDir::NoDotAndDotDot);
		QStringList fileList = runDir.entryList();
		for (int i = 0; i < fileList.size(); i++)
		{
			runDir.remove(fileList[i]);
		}
		runDir.rmdir(dirName);
	}
}

void TESSGUI::notSummarizing()
{
	summaryOpened = false;
	updateMenus();	
}

void TESSGUI::notModifying()
{
	modifying = false;
	updateMenus();
}

void TESSGUI::reloadNeighborhoodDiagram()
{
	QString v = project.path + "/" + project.v;
	QString n = project.path + "/" + project.n;
	QString c = project.path + "/" + project.c;

	if (QFile::exists(v) && QFile::exists(n) && QFile::exists(c))
	{
		closeGraph(n);
		loadGraph(n);
	}
}

void TESSGUI::cleError(QProcess::ProcessError error)
{
	switch(error) 
	{
		case QProcess::FailedToStart:
			infoTextEdit->append(tr("Error: Failed to start %1 (%2).\n")
								 .arg(CMD_TITLE)
								 .arg(newRun.T));
			break;

		case QProcess::Crashed:
			infoTextEdit->append(tr("Error: %1 (%2) aborted or crashed.\n")
								 .arg(CMD_TITLE)
								 .arg(newRun.T));
			break;

		case QProcess::Timedout:
			infoTextEdit->append(tr("Error: Waiting for %1 (%2) timed out.\n")
								 .arg(CMD_TITLE)
								 .arg(newRun.T));
			break;

		case QProcess::WriteError:
			infoTextEdit->append(
				tr("Error: An error occurred when attempting to write to %1 (%2).\n")
				.arg(CMD_TITLE)
				.arg(newRun.T));
			break;

		case QProcess::ReadError:
			infoTextEdit->append(
				tr("Error: An error occurred when attempting to read from %1 (%2).\n")
				.arg(CMD_TITLE)
				.arg(newRun.T));
			break;

		default:
			infoTextEdit->append(tr("Error: An unknown error occurred.\n"));
	}
}

void TESSGUI::cleFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
	infoTextEdit->append(tr("%1 (%2) Exit Code: %3, %4 (%5) Exit Status: %6.\n")
						 .arg(CMD_TITLE)
						 .arg(newRun.T)
						 .arg(exitCode)
						 .arg(CMD_TITLE)
						 .arg(newRun.T)
						 .arg(exitStatus));

	if (mainRun)
	{
		currMRun++;

		
		if (exitCode == EXIT_SUCCESS && 
			QFile::exists(lhName) && 
			QFile::exists(alName) &&
			QFile::exists(dicName) && 
			QFile::exists(imName) && 
			QFile::exists(hcName) && 
			QFile::exists(apName) && 
			QFile::exists(trName)
                    )
                {
			
                       	addMRunToProject();
			
		}
		
				
		if (currMRun <= totMRun)
		{
			if (currMRun < totMRun)
			{
				performMRun();
			}
		}
		
	}
}

void TESSGUI::cleReadStandardError()
{
}

void TESSGUI::cleReadStandardOutput()
{
	infoTextEdit->append(QString(cle->readAll()));
}

void TESSGUI::cleStarted()
{
	infoTextEdit->append(tr("%1 (%2) started and is running. Please wait...\n")
						 .arg(CMD_TITLE)
						 .arg(newRun.T));
}

void TESSGUI::cleStateChanged(QProcess::ProcessState newState)
{
	cleState = newState;
	updateMenus();
}

void TESSGUI::createActions()
{
	// File
	openDataAct = new QAction(QIcon(":/images/filedata.png"), 
		tr("Open &Data..."), this);
	openDataAct->setShortcut(tr("Ctrl+D"));
	openDataAct->setStatusTip(tr("Open %1 data").arg(GUI_TITLE));
	connect(openDataAct, SIGNAL(triggered()), this, SLOT(openData()));

	newProjectAct = new QAction(QIcon(":/images/filenew.png"), 
		tr("&New Project..."), this);
	newProjectAct->setShortcut(tr("Ctrl+N"));
	newProjectAct->setStatusTip(tr("Create a new %1 project").arg(GUI_TITLE));
	connect(newProjectAct, SIGNAL(triggered()), this, SLOT(newProject()));

	openProjectAct = new QAction(QIcon(":/images/fileopen.png"), 
		tr("&Open Project..."), this);
	openProjectAct->setShortcut(tr("Ctrl+O"));
	openProjectAct->setStatusTip(tr("Open an existing %1 project").arg(GUI_TITLE));
	connect(openProjectAct, SIGNAL(triggered()), this, SLOT(openProject()));

	closeProjectAct = new QAction(QIcon(":/images/fileclose.png"), 
		tr("&Close Project"), this);
	closeProjectAct->setStatusTip(tr("Close the opened %1 project").arg(GUI_TITLE));
	connect(closeProjectAct, SIGNAL(triggered()), this, SLOT(closeProject()));

	saveProjectAct = new QAction(QIcon(":/images/filesave.png"), 
		tr("&Save Project"), this);
	saveProjectAct->setShortcut(tr("Ctrl+S"));
	saveProjectAct->setStatusTip(tr("Save the current %1 project").arg(GUI_TITLE));
	connect(saveProjectAct, SIGNAL(triggered()), this, SLOT(saveProject()));

	openGraphicalResultsAct = new QAction(QIcon(":/images/filegraph.png"), 
		tr("Open &Graphical Results..."), this);
	openGraphicalResultsAct->setShortcut(tr("Ctrl+G"));
	openGraphicalResultsAct->setStatusTip(tr("Open graphical %1 results").arg(GUI_TITLE));
	connect(openGraphicalResultsAct, SIGNAL(triggered()), 
		this, SLOT(openGraph()));

	openTextualResultsAct = new QAction(QIcon(":/images/filetext.png"), 
		tr("Open &Textual Results..."), this);
	openTextualResultsAct->setShortcut(tr("Ctrl+T"));
	openTextualResultsAct->setStatusTip(tr("Open textual %1 results").arg(GUI_TITLE));
	connect(openTextualResultsAct, SIGNAL(triggered()), 
		this, SLOT(openText()));

	recentProjectSeparatorAct = new QAction(this);
	recentProjectSeparatorAct->setSeparator(true);

	for (int i = 0; i < MAX_RECENT_PROJECTS; i++) 
	{
		recentProjectActs[i] = new QAction(this);
		recentProjectActs[i]->setVisible(false);
		connect(recentProjectActs[i], SIGNAL(triggered()), 
			this, SLOT(openRecentProject()));
	}

	quitAct = new QAction(QIcon(":/images/filequit.png"), tr("&Quit"), this);
	quitAct->setShortcut(tr("Ctrl+Q"));
	quitAct->setStatusTip(tr("Quit %1").arg(GUI_TITLE));
	connect(quitAct, SIGNAL(triggered()), this, SLOT(quit()));

	// Project
	modifyAct = new QAction(QIcon(":/images/projectmodify.png"), 
		tr("&Modify Neighborhood System..."), this);
	modifyAct->setShortcut(tr("Ctrl+M"));
	modifyAct->setStatusTip(tr("Modify neighborhood system"));
	connect(modifyAct, SIGNAL(triggered()), this, SLOT(modify()));

	runAct = new QAction(QIcon(":/images/projectrun.png"), 
		tr("&Run..."), this);
	runAct->setShortcut(tr("Ctrl+R"));
	runAct->setStatusTip(tr("Run %1 project").arg(GUI_TITLE));
	connect(runAct, SIGNAL(triggered()), this, SLOT(run()));

	abortAct = new QAction(QIcon(":/images/projectabort.png"), 
		tr("&Abort..."), this);
	abortAct->setStatusTip(tr("Abort running %1 project").arg(GUI_TITLE));
	connect(abortAct, SIGNAL(triggered()), this, SLOT(abort()));

	summarizeAct = new QAction(QIcon(":/images/projectsummary.png"),tr("&Summarize Project Runs"),this);
	summarizeAct->setStatusTip(tr("Summarize %1 project runs").arg(GUI_TITLE));
	connect(summarizeAct,SIGNAL(triggered()),this,SLOT(summarize()));
	
	// Tools
	generateAct = new QAction(QIcon(":/images/toolsgenerate.png"), 
		tr("&Generate Spatial Coordinates..."), this);
	// generateAct->setShortcut(tr("Ctrl+G"));
	generateAct->setStatusTip(tr("Generate spatial coordinates for individuals"));
	connect(generateAct, SIGNAL(triggered()), this, SLOT(generate()));
	
	geoAct = new QAction(QIcon(":/images/toolsgeo.png"), 
				  tr("&Compute Geographic Distances"), this);
	// generateAct->setShortcut(tr("Ctrl+G"));
	geoAct->setStatusTip(tr("Compute Pairwise Geographical Distances for individuals"));
	connect(geoAct, SIGNAL(triggered()), this, SLOT(computeGeo()));

	resampleAct = new QAction(QIcon(":/images/toolsresample.png"), 
		tr("&Resample Loci..."), this);
	// resampleAct->setShortcut(tr("Ctrl+G"));
	resampleAct->setStatusTip(tr("Resample loci"));
	connect(resampleAct, SIGNAL(triggered()), this, SLOT(resample()));

	
	// View
	clearAct = new QAction(QIcon(":/images/viewclear.png"), 
		tr("&Clear Information Window"), this);
	clearAct->setStatusTip(tr("Clear information window"));
	connect(clearAct, SIGNAL(triggered()), this, SLOT(clearInfoWindow()));

	// Windows
	closeAct = new QAction(tr("Cl&ose"), this);
	closeAct->setShortcut(tr("Ctrl+F4"));
	closeAct->setStatusTip(tr("Close the active window"));
	connect(closeAct, SIGNAL(triggered()), workspace, SLOT(closeActiveWindow()));

	closeAllAct = new QAction(tr("Close &All"), this);
	closeAllAct->setStatusTip(tr("Close all the windows"));
	connect(closeAllAct, SIGNAL(triggered()), workspace, SLOT(closeAllWindows()));

	tileAct = new QAction(tr("&Tile"), this);
	tileAct->setStatusTip(tr("Tile the windows"));
	connect(tileAct, SIGNAL(triggered()), workspace, SLOT(tile()));

	cascadeAct = new QAction(tr("&Cascade"), this);
	cascadeAct->setStatusTip(tr("Cascade the windows"));
	connect(cascadeAct, SIGNAL(triggered()), workspace, SLOT(cascade()));

	arrangeAct = new QAction(tr("Arrange &Icons"), this);
	arrangeAct->setStatusTip(tr("Arrange the icons"));
	connect(arrangeAct, SIGNAL(triggered()), workspace, SLOT(arrangeIcons()));

	nextAct = new QAction(tr("Ne&xt"), this);
	nextAct->setShortcut(tr("Ctrl+F6"));
	nextAct->setStatusTip(tr("Move the focus to the next window"));
	connect(nextAct, SIGNAL(triggered()), workspace, SLOT(activateNextWindow()));

	previousAct = new QAction(tr("Pre&vious"), this);
	previousAct->setShortcut(tr("Ctrl+Shift+F6"));
	previousAct->setStatusTip(tr("Move the focus to the previous window"));
	connect(previousAct, SIGNAL(triggered()), 
		workspace, SLOT(activatePreviousWindow()));

	windowSeparatorAct = new QAction(this);
	windowSeparatorAct->setSeparator(true);

	// Help
	referenceAct = new QAction(QIcon(":/images/helpreference.png"), 
		tr("&Reference Manual"), this);
	referenceAct->setStatusTip(tr("Open the reference manual"));
	connect(referenceAct, SIGNAL(triggered()), this, SLOT(openReference()));
	aboutAct = new QAction(QIcon(":/images/helpabout.png"), tr("&About..."), this);
	aboutAct->setStatusTip(tr("Show the About box of %1").arg(GUI_TITLE));
	connect(aboutAct, SIGNAL(triggered()), this, SLOT(about()));
}

void TESSGUI::createMenus()
{
	// File
	fileMenu = menuBar()->addMenu(tr("&File"));
	fileMenu->addAction(openDataAct);
	fileMenu->addSeparator();
	fileMenu->addAction(newProjectAct);
	fileMenu->addAction(openProjectAct);
	fileMenu->addAction(closeProjectAct);
	fileMenu->addAction(saveProjectAct);
	fileMenu->addSeparator();
	fileMenu->addAction(openGraphicalResultsAct);
	fileMenu->addAction(openTextualResultsAct);
	fileMenu->addAction(recentProjectSeparatorAct);
	for (int i = 0; i < MAX_RECENT_PROJECTS; i++)
	{
		fileMenu->addAction(recentProjectActs[i]);
	}
	fileMenu->addSeparator();
	fileMenu->addAction(quitAct);
	updateRecentProjectActions();

	// Project
	projectMenu = menuBar()->addMenu(tr("&Project"));
	projectMenu->addAction(modifyAct);
	projectMenu->addSeparator();
	projectMenu->addAction(runAct);
	projectMenu->addAction(abortAct);
	projectMenu->addAction(summarizeAct);

	// Tools
	toolsMenu = menuBar()->addMenu(tr("&Tools"));
	toolsMenu->addAction(generateAct);
	toolsMenu->addSeparator();
	toolsMenu->addAction(resampleAct);
	toolsMenu->addSeparator();
	toolsMenu->addSeparator();
	toolsMenu->addAction(geoAct);
	
	// View
	viewMenu = menuBar()->addMenu(tr("&View"));
	viewMenu->addAction(clearAct);

	// Window
	windowMenu = menuBar()->addMenu(tr("&Window"));
	connect(windowMenu, SIGNAL(aboutToShow()), this, SLOT(updateWindowMenu()));

	menuBar()->addSeparator();

	// Help
	helpMenu = menuBar()->addMenu(tr("&Help"));
	helpMenu->addAction(referenceAct);
	helpMenu->addSeparator();
	helpMenu->addAction(aboutAct);
}

void TESSGUI::createToolBars()
{
	// File
	fileToolBar = addToolBar(tr("File"));
	fileToolBar->addAction(openDataAct);
	fileToolBar->addSeparator();
	fileToolBar->addAction(newProjectAct);
	fileToolBar->addAction(openProjectAct);
	fileToolBar->addAction(closeProjectAct);
	fileToolBar->addAction(saveProjectAct);
	fileToolBar->addSeparator();
	fileToolBar->addAction(openGraphicalResultsAct);
	fileToolBar->addAction(openTextualResultsAct);
	fileToolBar->addSeparator();
	fileToolBar->addAction(quitAct);

	// Project
	projectToolBar = addToolBar(tr("Project"));
	projectToolBar->addAction(modifyAct);
	projectToolBar->addAction(runAct);
	projectToolBar->addAction(abortAct);
	projectToolBar->addAction(summarizeAct);

	// Tools
	toolsToolBar = addToolBar(tr("Tools"));
	toolsToolBar->addAction(generateAct);
	toolsToolBar->addAction(resampleAct);
	toolsToolBar->addAction(geoAct);
	
	
	// View
	viewToolBar = addToolBar(tr("View"));
	viewToolBar->addAction(clearAct);

	// Help
	helpToolBar = addToolBar(tr("Help"));
	helpToolBar->addAction(referenceAct);
	helpToolBar->addSeparator();
	helpToolBar->addAction(aboutAct);
}

void TESSGUI::createStatusBar()
{
	statusBar()->showMessage(tr("Ready"));
}

void TESSGUI::createDockWindows()
{
	QDockWidget *dock;

	dock = new QDockWidget(tr("Project"), this);
	dock->setAllowedAreas(Qt::LeftDockWidgetArea);
	dock->setFeatures(dock->features() & ~QDockWidget::DockWidgetClosable);
	projectTreeWidget = new TreeWidget(dock);
	projectTreeWidget->setColumnCount(1);
	projectTreeWidget->setItemHidden(projectTreeWidget->headerItem(), true);
	dock->setWidget(projectTreeWidget);
	addDockWidget(Qt::LeftDockWidgetArea, dock);
	connect(projectTreeWidget, SIGNAL(runItemDeleted(QString)), 
		this, SLOT(deleteRunItem(QString)));

	dock = new QDockWidget(tr("Information"), this);
	dock->setAllowedAreas(Qt::BottomDockWidgetArea);
	dock->setFeatures(dock->features() & ~QDockWidget::DockWidgetClosable);
	infoTextEdit = new QTextEdit(dock);
	infoTextEdit->setReadOnly(true);
	QFont courierFont("Courier", 9, QFont::Normal);
	infoTextEdit->setCurrentFont(courierFont);
	infoTextEdit->setLineWrapMode(QTextEdit::NoWrap);
	dock->setWidget(infoTextEdit);
	addDockWidget(Qt::BottomDockWidgetArea, dock);
}

DataWindow *TESSGUI::createDataWindow(int EC, int ER)
{
	DataWindow *window = new DataWindow(0,EC,ER);
	workspace->addWindow(window);
	return window;
}

DataWindow *TESSGUI::findDataWindow(const QString &fileName)
{
	QString canonicalFilePath = QFileInfo(fileName).canonicalFilePath();

	foreach (QWidget *window, workspace->windowList()) 
	{
		DataWindow *dataWindow = qobject_cast<DataWindow *>(window);
		if (dataWindow && dataWindow->currentFile() == canonicalFilePath)
		{
			return dataWindow;
		}
	}

	return 0;
}

GraphWindow *TESSGUI::createGraphWindow()
{
	
	GraphWindow *window = new GraphWindow;
	
		
	workspace->addWindow(window);
	
		
	return window;
}

GraphWindow *TESSGUI::findGraphWindow(const QString &fileName)
{
	QString canonicalFilePath = QFileInfo(fileName).canonicalFilePath();

	foreach (QWidget *window, workspace->windowList()) 
	{
		GraphWindow *graphWindow = 
			qobject_cast<GraphWindow *>(window);
		if (graphWindow && graphWindow->currentFile() == canonicalFilePath)
		{
			return graphWindow;
		}
	}

	return 0;
}

TextWindow *TESSGUI::createTextWindow()
{
	TextWindow *window = new TextWindow;
	workspace->addWindow(window);
	return window;
}

TextWindow *TESSGUI::findTextWindow(const QString &fileName)
{
	QString canonicalFilePath = QFileInfo(fileName).canonicalFilePath();

	foreach (QWidget *window, workspace->windowList()) 
	{
		TextWindow *textWindow = qobject_cast<TextWindow *>(window);
		if (textWindow && textWindow->currentFile() == canonicalFilePath)
		{
			return textWindow;
		}
	}

	return 0;
}

bool TESSGUI::loadData(const QString &fullDataPath, int EC, int ER)
{
	if (!fullDataPath.isEmpty())
	{
		DataWindow *existingWindow = findDataWindow(fullDataPath);
		if (existingWindow) 
		{
			workspace->setActiveWindow(existingWindow);
			return true;
		}

		DataWindow *window = createDataWindow(EC,ER);
		if (window->loadFile(fullDataPath))
		{
			window->showMaximized();
			statusBar()->showMessage(tr("%1 Loaded").arg(fullDataPath), 2000);
			return true;
		}
	}

	return false;
}

bool TESSGUI::loadProject(const QString &projectName)
{
	if (!projectName.isEmpty())
	{
		if (!readProjectSettings(projectName))
		{
			return false;
		}
		if (!populateProjectTreeWidget())
		{
			return false;
		}
		if (!loadData(project.path + "/" + project.data,project.C.toInt(),project.R.toInt()))
		{
			return false;
		}
		if (!initSummary())
		{
			return false;
		}
		

		projectOpened = true;

		setCurrentProject(projectName);

		setDefaultRunParameters();

		return true;
	}

	return false;
}

bool TESSGUI::readProjectSettings(const QString &projectName)
{
	if (!projectName.isEmpty())
	{
		QFileInfo projectInfo(projectName);
		project.name = projectInfo.fileName();
		project.path = projectInfo.absolutePath();

		QSettings projectSettings(projectName, QSettings::IniFormat);

		QString projectSignature = 
			projectSettings.value(tr("projectSignature")).toString();
		if (projectSignature != tr("%1 Project").arg(GUI_TITLE))
		{
			// Invalid Project
			return false;
		}

		// Project Information
		projectSettings.beginGroup(tr("projectInfo"));
		project.data = projectSettings.value(tr("data")).toString();
		project.v =    projectSettings.value(tr("v")).toString();
		project.n =    projectSettings.value(tr("n")).toString();
		project.c =    projectSettings.value(tr("c")).toString();
		project.znoAdm =    projectSettings.value(tr("znoAdm")).toString();
		project.zadmCAR =    projectSettings.value(tr("zadmCAR")).toString();
		project.zadmBYM =    projectSettings.value(tr("zadmBYM")).toString();
                project.mlAdmCAR =   projectSettings.value(tr("mlAdmCAR"),tr("NA")).toString();
		project.mlAdmBYM =   projectSettings.value(tr("mlAdmBYM"),tr("NA")).toString();
		project.mlnoAdm =   projectSettings.value(tr("mlnoAdm")).toString();
		project.hasGeoData = projectSettings.value(tr("hasGeo"), false).toBool();  // For Backward Compatibility
		project.geoData = projectSettings.value(tr("geoData")).toString();
		projectSettings.endGroup();

		// Data Information
		projectSettings.beginGroup(tr("dataInfo"));
		project.N = projectSettings.value(tr("N")).toString();
		project.D = projectSettings.value(tr("D"), tr("0")).toString();  // For Backward Compatibility
		project.A = projectSettings.value(tr("A")).toString();
		project.L = projectSettings.value(tr("L")).toString();
		project.M = projectSettings.value(tr("M")).toString();
		project.specialFormat = projectSettings.value(tr("sp"), false).toBool(); // For Backward Compatibility
		project.isRecessiveAllele = projectSettings.value(tr("rc"), false).toBool(); // For Backward Compatibility
		projectSettings.endGroup();

		// Data Format
		projectSettings.beginGroup(tr("dataFormat"));
		project.R = projectSettings.value(tr("R")).toString();
		project.C = projectSettings.value(tr("C")).toString();
		projectSettings.endGroup();

		// Run Information
		projectSettings.beginGroup(tr("runInfo"));
		project.i = projectSettings.value(tr("i")).toInt();
		projectSettings.endGroup();

		// Project Runs
		project.runs.clear();
		int size = projectSettings.beginReadArray(tr("runs"));
		for (int i = 0; i < size; i++) 
		{
			projectSettings.setArrayIndex(i);
			Run run;
			run.name = projectSettings.value(tr("name")).toString();
			run.T    = projectSettings.value(tr("T"), tr("without Admixture")).toString();  // For Backward Compatibility
			run.admMod = projectSettings.value(tr("admMod"), tr("NA")).toString();  // For Backward Compatibility
			run.K    = projectSettings.value(tr("K")).toString();
			run.toK    = projectSettings.value(tr("toK")).toString();
			run.P    = projectSettings.value(tr("P")).toString();
                        run.updateParameters = projectSettings.value(tr("updateParameters"), false).toBool();
			run.updatePsiParameter = projectSettings.value(tr("updatePsiParameter"), false).toBool();
			run.D    = projectSettings.value(tr("D")).toString();
			run.S    = projectSettings.value(tr("S")).toString();
			run.B    = projectSettings.value(tr("B")).toString();
			run.C    = projectSettings.value(tr("C"), false).toBool();  // For Backward Compatibility
			run.NJ    = projectSettings.value(tr("NJ"), false).toBool();  // For Backward Compatibility
			run.map  = projectSettings.value(tr("map"), tr("NA")).toString();
			run.LH   = projectSettings.value(tr("LH")).toString();
			run.L    = projectSettings.value(tr("L"), tr("NA")).toString();  // For Backward Compatibility
			run.AL   = projectSettings.value(tr("AL"), tr("NA")).toString();  // For Backward Compatibility
			run.DIC  = projectSettings.value(tr("DIC"), tr("NA")).toString();
			run.fDIC = projectSettings.value(tr("fDIC"), tr("NA")).toString();
			run.IM   = projectSettings.value(tr("IM")).toString();
			run.HC   = projectSettings.value(tr("HC")).toString();
			run.AP   = projectSettings.value(tr("AP")).toString();
			run.TR   = projectSettings.value(tr("TR")).toString();
			run.q    = projectSettings.value(tr("q"),false).toBool();
			run.trendDegree = projectSettings.value(tr("trendDegree")).toString();
			run.sigma = projectSettings.value(tr("sigma")).toString();
			run.scOpt = projectSettings.value(tr("scOpt"), tr("m")).toString(); //For backward compatibility
			run.BH   = projectSettings.value(tr("BH"), tr("NA")).toString();
			project.runs.append(run);
		}
		projectSettings.endArray();

		return true;
	}
	return false;
}

bool TESSGUI::populateProjectTreeWidget()
{
	projectTreeWidget->clear();

	QTreeWidgetItem *projectItem = new QTreeWidgetItem(projectTreeWidget, 
		QStringList(QFileInfo(project.path + "/" + project.name).baseName()));

	// Project Information
	QTreeWidgetItem *projectInfoItem = new QTreeWidgetItem(projectItem, 
		QStringList(QString(tr("Project Information"))));
	new QTreeWidgetItem(projectInfoItem, 
		QStringList(QString(tr("Project Name: %1")).arg(project.name)));
	new QTreeWidgetItem(projectInfoItem, 
		QStringList(QString(tr("Project Path: %1")).arg(project.path)));
	new QTreeWidgetItem(projectInfoItem, 
		QStringList(QString(tr("Project Data: %1")).arg(project.data)));
	new QTreeWidgetItem(projectInfoItem, 
		QStringList(QString(tr("Voronoi: %1")).arg(project.v)));
	new QTreeWidgetItem(projectInfoItem, 
		QStringList(QString(tr("Neighborhood: %1")).arg(project.n)));
	if (project.hasGeoData)
	{
		new QTreeWidgetItem(projectInfoItem, QStringList(QString(tr("Geographic Distances: %1")).arg(project.geoData)));
	}

	// Data Information
	QTreeWidgetItem *dataInfoItem = new QTreeWidgetItem(projectItem, 
		QStringList(QString(tr("Data Information"))));
	new QTreeWidgetItem(dataInfoItem, 
		QStringList(QString(tr("Number of Individuals: %1")).arg(project.N)));
	new QTreeWidgetItem(dataInfoItem, 
		QStringList(QString(tr("Number of Dummy Individuals: %1")).arg(project.D)));
	new QTreeWidgetItem(dataInfoItem, 
		QStringList(QString(tr("Ploidy: %1")).arg(project.A)));
	new QTreeWidgetItem(dataInfoItem, 
		QStringList(QString(tr("Number of Loci: %1")).arg(project.L)));
	new QTreeWidgetItem(dataInfoItem, 
		QStringList(QString(tr("Missing Data Value: %1")).arg(project.M)));

	// Data Format
	QTreeWidgetItem *dataFormatItem = new QTreeWidgetItem(projectItem, 
		QStringList(QString(tr("Data Format"))));
	new QTreeWidgetItem(dataFormatItem, 
		QStringList(QString(tr("Number of Extra Rows: %1")).arg(project.R)));
	new QTreeWidgetItem(dataFormatItem, 
		QStringList(QString(tr("Number of Extra Columns: %1")).arg(project.C)));

	int i;

	// Project Runs
	projectRunsItem = new QTreeWidgetItem(projectItem, 
		QStringList(QString(tr("Project Runs"))));
	for (i = 0; i < project.runs.size(); i++)
	{
		QTreeWidgetItem *runNameItem = new QTreeWidgetItem(projectRunsItem, 
			QStringList(project.runs[i].name));
                new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Used Admixture: %1"))
						.arg(project.runs[i].q ? tr("Yes") : tr("No"))));
		
		if (project.runs[i].q)
		{
			new QTreeWidgetItem(runNameItem, 
					    QStringList(QString(tr("Admixture Model: %1"))
							    .arg(project.runs[i].admMod)));
		}
		
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Maximal Number of Clusters: %1"))
						.arg(project.runs[i].K)));
	
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("DIC: %1"))
						    .arg(project.runs[i].DIC)));
		
		if (!newRun.q || project.runs[i].admMod != "BYM")
		{
			new QTreeWidgetItem(runNameItem, 
				QStringList(QString(tr("Spatial Interaction Parameter (init. value): %1"))
							.arg(project.runs[i].P)));
		}
	
		if (project.hasGeoData)
		{
			if (project.runs[i].scOpt == "m")
			{
				new QTreeWidgetItem(runNameItem, 
						QStringList(QString(tr("Scale Parameter: Mean Distance"))));
									
			}
			else if (project.runs[i].scOpt == "d")
			{
				new QTreeWidgetItem(runNameItem, 
						QStringList(QString(tr("Scale Parameter: Median Distance"))));
									
			}
			else if (project.runs[i].scOpt == "x")
			{
				new QTreeWidgetItem(runNameItem, 
						QStringList(QString(tr("Scale Parameter: Max Distance"))));
									
			}
			else
			{
				new QTreeWidgetItem(runNameItem, 
						QStringList(QString(tr("Scale Parameter: %1"))
								.arg(project.runs[i].scOpt)));
				
			}
		}
		
		if (project.runs[i].T == tr("with Admixture") && project.runs[i].q)
		{
			new QTreeWidgetItem(runNameItem, 
					QStringList(QString(tr("Trend Degree: %1"))
							.arg(project.runs[i].trendDegree)));
			new QTreeWidgetItem(runNameItem, 
					QStringList(QString(tr("Initial CAR Variance: %1"))
							.arg(project.runs[i].sigma)));
		}
		
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("Parameter of Allele Freq. Model: %1"))
						    .arg(project.runs[i].D)));
		
		
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("Total Number of Sweeps: %1"))
						    .arg(project.runs[i].S)));
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("Burn In Number of Sweeps: %1"))
						    .arg(project.runs[i].B)));
		
		new QTreeWidgetItem(runNameItem,
			QStringList(QString(tr("Continued Lowest DIC Run: %1"))
						.arg(project.runs[i].C ? tr("Yes") : tr("No"))));
		new QTreeWidgetItem(runNameItem,
				    QStringList(QString(tr("Started from Neighbour Joining Tree: %1"))
						    .arg(project.runs[i].NJ ? tr("Yes") : tr("No"))));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Log-Likelihood History: %1"))
						.arg(project.runs[i].LH)));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Average Log-Likelihood: %1"))
						.arg(project.runs[i].L)));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Initial Membership of Individuals: %1"))
						.arg(project.runs[i].IM)));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Hard Clustering: %1"))
						.arg(project.runs[i].HC)));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Assignment Probabilities: %1"))
						.arg(project.runs[i].AP)));
		
		if (project.runs[i].T == tr("with Admixture") && project.runs[i].q)
		{
			new QTreeWidgetItem(runNameItem, 
					    QStringList(QString(tr("Beta History: %1"))
							    .arg(project.runs[i].BH)));
		}
		
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Textual Results: %1"))
						.arg(project.runs[i].TR)));
	}

	projectTreeWidget->expandItem(projectItem);

	return true;
}

void TESSGUI::loadGraph(const QString &fileName)
{
	if (!fileName.isEmpty())
	{
		GraphWindow *existingWindow = findGraphWindow(fileName);
		if (existingWindow) 
		{
			workspace->setActiveWindow(existingWindow);
			return;
		}

				
		GraphWindow *window = createGraphWindow();
		if (window->loadFile(fileName))
		{
			window->showMaximized();
			statusBar()->showMessage(tr("%1 Loaded").arg(fileName), 2000);
		}
		else
		{
			window->close();
		}
	}
}

void TESSGUI::loadText(const QString &fileName)
{
	if (!fileName.isEmpty())
	{
		TextWindow *existingWindow = findTextWindow(fileName);
		if (existingWindow) 
		{
			workspace->setActiveWindow(existingWindow);
			return;
		}

		TextWindow *window = createTextWindow();
		if (window->loadFile(fileName))
		{
			window->showMaximized();
			statusBar()->showMessage(tr("%1 Loaded").arg(fileName), 2000);
		}
		else
		{
			window->close();
		}
	}
}

void TESSGUI::setCurrentProject(const QString &projectName)
{
	currentProject = projectName;

	QSettings settings(tr("SuperSoft"), GUI_TITLE);
	QStringList projects = settings.value(tr("recentProjectList")).toStringList();
	projects.removeAll(projectName);
	projects.prepend(projectName);
	while (projects.size() > MAX_RECENT_PROJECTS)
	{
		projects.removeLast();
	}
	settings.setValue(tr("recentProjectList"), projects);
	updateRecentProjectActions();
}

void TESSGUI::updateRecentProjectActions()
{
	QSettings settings(tr("SuperSoft"), GUI_TITLE);
	QStringList projects = settings.value(tr("recentProjectList")).toStringList();

	int numRecentProjects = qMin(projects.size(), MAX_RECENT_PROJECTS);

	for (int i = 0; i < numRecentProjects; i++) 
	{
		QString text = tr("Recent Project &%1: %2")
			.arg(i + 1).arg(strippedProjectName(projects[i]));
		recentProjectActs[i]->setText(text);
		recentProjectActs[i]->setData(projects[i]);
		recentProjectActs[i]->setVisible(true);
	}
	for (int j = numRecentProjects; j < MAX_RECENT_PROJECTS; j++)
	{
		recentProjectActs[j]->setVisible(false);
	}

	recentProjectSeparatorAct->setVisible(numRecentProjects > 0);
}

QString TESSGUI::strippedProjectName(const QString &projectName)
{
	return QFileInfo(projectName).fileName();
}

bool TESSGUI::writeProjectSettings(const QString &projectName)
{
	if (!projectName.isEmpty())
	{
		QSettings projectSettings(projectName, QSettings::IniFormat);

		// Project Signature
		QString projectSignature = tr("%1 Project").arg(GUI_TITLE);
		projectSettings.setValue(tr("projectSignature"), projectSignature);

		// Project Information
		projectSettings.beginGroup(tr("projectInfo"));
		projectSettings.setValue(tr("data"), project.data);
		projectSettings.setValue(tr("v"), project.v);
		projectSettings.setValue(tr("n"), project.n);
		projectSettings.setValue(tr("c"), project.c);
		projectSettings.setValue(tr("znoAdm"), project.znoAdm);
		projectSettings.setValue(tr("zadmCAR"), project.zadmCAR);
		projectSettings.setValue(tr("zadmBYM"), project.zadmBYM);
                projectSettings.setValue(tr("mlAdmCAR"), project.mlAdmCAR);
		projectSettings.setValue(tr("mlAdmBYM"), project.mlAdmBYM);
		projectSettings.setValue(tr("mlnoAdm"), project.mlnoAdm);
		projectSettings.setValue(tr("hasGeo"),project.hasGeoData);	//hasGeo: geographic distances loaded ?
		projectSettings.setValue(tr("geoData"),project.geoData);
		projectSettings.endGroup();

		// Data Information
		projectSettings.beginGroup(tr("dataInfo"));
		projectSettings.setValue(tr("N"), project.N);
		projectSettings.setValue(tr("D"), project.D);
		projectSettings.setValue(tr("A"), project.A);
		projectSettings.setValue(tr("L"), project.L);
		projectSettings.setValue(tr("M"), project.M);
		projectSettings.setValue(tr("sp"),project.specialFormat); // sp: SPecial data format?
		projectSettings.setValue(tr("rc"),project.isRecessiveAllele); // rc: Recessive available?
		projectSettings.endGroup();

		// Data Format
		projectSettings.beginGroup(tr("dataFormat"));
		projectSettings.setValue(tr("R"), project.R);
		projectSettings.setValue(tr("C"), project.C);
		projectSettings.endGroup();

		// Run Information
		projectSettings.beginGroup(tr("runInfo"));
		projectSettings.setValue(tr("i"), project.i);
		projectSettings.endGroup();

		// Project Runs
		projectSettings.beginWriteArray(tr("runs"));
		for (int i = 0; i < project.runs.size(); i++) 
		{
			projectSettings.setArrayIndex(i);
			projectSettings.setValue(tr("name"), project.runs.at(i).name);
			projectSettings.setValue(tr("q"),    project.runs.at(i).q);
			projectSettings.setValue(tr("trendDegree"), project.runs.at(i).trendDegree);
			projectSettings.setValue(tr("sigma"), project.runs.at(i).sigma);
			projectSettings.setValue(tr("scOpt"), project.runs.at(i).scOpt);
			projectSettings.setValue(tr("T"),    project.runs.at(i).T);
			projectSettings.setValue(tr("admMod"),    project.runs.at(i).admMod);
			projectSettings.setValue(tr("K"),    project.runs.at(i).K);
			projectSettings.setValue(tr("P"),    project.runs.at(i).P);
                        projectSettings.setValue(tr("updateParameters"),    project.runs.at(i).updateParameters);
			projectSettings.setValue(tr("updatePsiParameter"),    project.runs.at(i).updatePsiParameter);
			projectSettings.setValue(tr("D"),    project.runs.at(i).D);
			projectSettings.setValue(tr("S"),    project.runs.at(i).S);
			projectSettings.setValue(tr("B"),    project.runs.at(i).B);
			projectSettings.setValue(tr("C"),    project.runs.at(i).C);
			projectSettings.setValue(tr("NJ"),    project.runs.at(i).NJ);
			projectSettings.setValue(tr("LH"),   project.runs.at(i).LH);
			projectSettings.setValue(tr("L"),    project.runs.at(i).L);
			projectSettings.setValue(tr("AL"),   project.runs.at(i).AL);
			projectSettings.setValue(tr("DIC"),  project.runs.at(i).DIC);
			projectSettings.setValue(tr("fDIC"), project.runs.at(i).fDIC);
			projectSettings.setValue(tr("IM"),   project.runs.at(i).IM);
			projectSettings.setValue(tr("HC"),   project.runs.at(i).HC);
			projectSettings.setValue(tr("BH"),   project.runs.at(i).BH);
			projectSettings.setValue(tr("AP"),   project.runs.at(i).AP);
			projectSettings.setValue(tr("TR"),   project.runs.at(i).TR);
			projectSettings.setValue(tr("map"),   project.runs.at(i).map);
// 			projectSettings.setValue(tr("hasPrediction"),   project.runs.at(i).hasPrediction);
// 			projectSettings.setValue(tr("Predict"),   project.runs.at(i).Predict);
		}
		projectSettings.endArray();

		return true;
	}

	return false;
}

void TESSGUI::closeData(const QString &fileName)
{
	foreach (QWidget *window, workspace->windowList()) 
	{
		DataWindow *dataWindow = qobject_cast<DataWindow *>(window);
		if (dataWindow && dataWindow->currentFile() == fileName)
		{
			dataWindow->close();
		}
	}
}

void TESSGUI::closeGraph(const QString &fileName)
{
	foreach (QWidget *window, workspace->windowList()) 
	{
		GraphWindow *graphWindow = qobject_cast<GraphWindow *>(window);
		if (graphWindow && graphWindow->currentFile() == fileName)
		{
			graphWindow->close();
		}
	}
}

void TESSGUI::closeText(const QString &fileName)
{
	foreach (QWidget *window, workspace->windowList()) 
	{
		TextWindow *textWindow = qobject_cast<TextWindow *>(window);
		if (textWindow && textWindow->currentFile() == fileName)
		{
			textWindow->close();
		}
	}
}

// Translate the XY coordinates to all positive values to circumvent the quirks of
// ChartDirector in the XYChart.
bool TESSGUI::translateCoordinates(vector< vector< double > > &C)
{
	int N = int(C.size());
	if (N == 0 || C[0].size() != 2)
	{
		return false;
	}
	double xMin = +1.0E+300;
	double xMax = -1.0E+300;
	double yMin = +1.0E+300;
	double yMax = -1.0E+300;
	int i;
	for (i = 0; i < N; i++)
	{
		if (C[i][0] < xMin)
		{
			xMin = C[i][0];
		}
		if (C[i][0] > xMax)
		{
			xMax = C[i][0];
		}
		if (C[i][1] < yMin)
		{
			yMin = C[i][1];
		}
		if (C[i][1] > yMax)
		{
			yMax = C[i][1];
		}
	}
	double xOffset = -xMin + (xMax - xMin) * 2.0;
	double yOffset = -yMin + (yMax - yMin) * 2.0;
	for (i = 0; i < N; i++)
	{
		C[i][0] += xOffset;
		C[i][1] += yOffset;
	}

	return true;
}

bool TESSGUI::generateVNC()
{
	QString v = project.path + "/" + project.v;
	QString n = project.path + "/" + project.n;
	QString c = project.path + "/" + project.c;

	if (QFile::exists(v) && QFile::exists(n) && QFile::exists(c))
	{
		return true;
	}
	else
	{
		infoTextEdit->append(tr("Generating Voronoi Tessellation & Neighborhood System...\n"));
		QApplication::setOverrideCursor(Qt::WaitCursor);

		const int N = project.N.toInt();
		const int D = project.D.toInt();
		const int A = project.A.toInt();
		const int L = project.L.toInt();

		vector< vector< double > > C;
		int i;
		for (i = 0; i < N + D; i++)
		{
			C.push_back(vector< double >(2, 0.0));
		}

		vector< vector< vector< int > > > X;
		vector< vector< int > > XElement;
		for (i = 0; i < A; i++)
		{
			XElement.push_back(vector< int >(L, 0));
		}
		for (i = 0; i < N; i++)
		{
			X.push_back(XElement);
		}

		QString data = project.path + "/" + project.data;
		LoadData(C, X, project.R.toInt(), project.C.toInt(), data.toAscii().constData(),project.specialFormat, project.isRecessiveAllele);
		translateCoordinates(C);

		//adding small perturbation to coordinates to ensure one sample per location
		int nbDigitMax = 0;
		int nbDigit;
		string xCoord = "";
		string yCoord = "";
		
		for (i = 0; i < N; i ++)
		{
			stringstream tmp1,tmp2;
			tmp1 << C[i][0];
			xCoord = tmp1.str();
			tmp2 << C[i][1];
			yCoord = tmp2.str();
			nbDigit = max((xCoord.size()-xCoord.find('.')),(yCoord.size()-yCoord.find('.'))) - 1;

			if (nbDigit > nbDigitMax)
			{
				nbDigitMax = nbDigit;
			}
			tmp1.clear();
			tmp2.clear();
		}
	

	
		double perturb = gsl_pow_int(10,nbDigitMax);
		perturb = 1/(10.0*perturb);
		
				
		for (i = 0; i < N; i++)
		{
			C[i][0] += gsl_ran_gaussian(rng,perturb);
			C[i][1] += gsl_ran_gaussian(rng,perturb);
		}
		
		SPoint ptThis;
		vector< SPoint > vptC(N + D, ptThis);
		for (int i = 0; i < N + D; i++)
		{
			vptC[i].m_nIndex = i;
			vptC[i].m_psXY.m_dX = C[i][0];
			vptC[i].m_psXY.m_dY = C[i][1];
		}

		vector< bool > vbKeep;
		vector< double > vdDataMinMax;
		vector< double > vdDataScale;
		vector< CEdge > veVoronoi;
		vector< vector< int > > vvnNS;

		CVoronoi::GetVoronoi(vptC, vbKeep, vdDataMinMax, vdDataScale, veVoronoi);
		CVoronoi::DrawVoronoi(vptC, N, vbKeep, vdDataMinMax, veVoronoi, false, 
			v.toAscii().constData());
		CVoronoi::GetNeighborhoodSystem(N, veVoronoi, vvnNS);
		CVoronoi::DrawNeighborhoodSystem(vptC, vdDataScale, vvnNS, true, 
			n.toAscii().constData());
		CVoronoi::SaveVoronoi(vptC, vbKeep, vdDataMinMax, vdDataScale, veVoronoi, vvnNS, 
			c.toAscii().constData());

		QApplication::restoreOverrideCursor();
		if (QFile::exists(v) && QFile::exists(n) && QFile::exists(c))
		{
			infoTextEdit->append(tr("Succeeded.\n"));
			return true;
		}
		else
		{
			infoTextEdit->append(tr("Failed.\n"));
			return false;
		}
	}

	return false;
}

void TESSGUI::setDefaultRunParameters()
{
	oldRun.T = tr("without Admixture");
	oldRun.admMod = tr("BYM");
	oldRun.N = "1";
	oldRun.baseK = "";
	oldRun.toK = "";
	oldRun.P = "0.6";
	oldRun.map = "";
    oldRun.D = "1.0";
    oldRun.sigma = "1.0";
	oldRun.scOpt = "m";
	oldRun.trendDegree = "1";
    oldRun.S = "1200";
	oldRun.B = "200";
	oldRun.C = false;
	oldRun.NJ = false;
  	oldRun.q = false;
  	oldRun.updateParameters = false;
	oldRun.updatePsiParameter = false;
// 	oldRun.hasPrediction = false;
	oldRun.script = false;
}

void TESSGUI::performMRun()
{
	mainRun = true;

	if (totMRun == 1)
	{
		infoTextEdit->append(QString(tr("Run %1:\n")).arg(newRun.T));
	}
	
	if (totMRun > 1)
	{
		if (currMRun > 0)
		{
			infoTextEdit->append("\n\n");
		}
		infoTextEdit->append(QString(tr("Run %1 of %2 Runs %3:\n"))
							 .arg(currMRun + 1)
							 .arg(totMRun)
							 .arg(newRun.T));
	}

	if (newRun.script)
	{
		newRun.K = QString::number((newRun.baseK.toInt() + currMRun / newRun.N.toInt()));
	}
	
	project.i++;
	newRun.name = QFileInfo(project.name).baseName() + tr("_RUN_") 
		+ QString("%1").arg(project.i, 6, 10, QChar('0'));
	newRun.LH = newRun.name + "/" + project.data + tr("LH.png");
	newRun.AL = newRun.name + "/" + project.data + tr("AL.txt");
	newRun.fDIC = newRun.name + "/" + project.data + tr("DIC.txt");
	newRun.IM = newRun.name + "/" + project.data + tr("IM.png");
	newRun.HC = newRun.name + "/" + project.data + tr("HC.png");
	newRun.BH = newRun.name + "/" + project.data + tr("BH.png");
	newRun.AP = newRun.name + "/" + project.data + tr("AP.png");
	newRun.TR = newRun.name + "/" + project.data + tr("TR.txt");
	
	oldRun.T = newRun.T;
	oldRun.admMod = newRun.admMod;
	oldRun.N = newRun.N;
	oldRun.K = newRun.K;
	oldRun.baseK = newRun.K;
	oldRun.toK = newRun.toK;
	oldRun.script = newRun.script;
	oldRun.P = newRun.P;
	oldRun.map = newRun.map;
        oldRun.updateParameters= newRun.updateParameters;
	oldRun.updatePsiParameter= newRun.updatePsiParameter;
	oldRun.D = newRun.D;
	oldRun.trendDegree = newRun.trendDegree;
        oldRun.sigma = newRun.sigma;
	oldRun.scOpt = newRun.scOpt;
        oldRun.S = newRun.S;
	oldRun.B = newRun.B;
	oldRun.C = newRun.C;
	oldRun.NJ = newRun.NJ;
        oldRun.q = newRun.q;

	QString dataName = project.data;
	QString enclosedDataName = dataName;
	if (dataName.contains(QChar(' ')))
	{
		enclosedDataName = "\"" + dataName + "\""; 
	}
	
	QString mapPredictName = newRun.map;
	QString enclosedMapPredictName = mapPredictName;
	if (mapPredictName.contains(QChar(' ')))
	{
		enclosedMapPredictName = "\"" + mapPredictName + "\""; 
	}
	
	
	QString geoDataName = project.geoData;
	QString enclosedGeoDataName = geoDataName;
	if (geoDataName.contains(QChar(' ')))
	{
		enclosedGeoDataName = "\"" + geoDataName + "\""; 
	}

	QString projectPath = project.path;
	QString enclosedProjectPath = projectPath;
	if (projectPath.contains(QChar(' ')))
	{
		enclosedProjectPath = "\"" + projectPath + "\""; 
	}

	QString fullRunPath = project.path + "/" + newRun.name;
	QString enclosedFullRunPath = fullRunPath;
	if (fullRunPath.contains(QChar(' ')))
	{
		enclosedFullRunPath = "\"" + fullRunPath + "\"";
	}
	QDir runDir;
	runDir.mkdir(fullRunPath);

	QString fullZName;
	if (newRun.C)
	{
		if (!newRun.q)
		{
			fullZName = project.path + "/" + project.znoAdm;
		}
		else
		{
			if (newRun.admMod == "CAR")
			{
				fullZName = project.path + "/" + project.zadmCAR;
			}
			else
			{
				fullZName = project.path + "/" + project.zadmBYM;
			}
		}
	}
	QString enclosedFullZName = fullZName;
	if (fullZName.contains(QChar(' ')))
	{
		enclosedFullZName = "\"" + fullZName + "\"";
	}

	QString fullVNCName = project.path + "/" + project.c;
	QString enclosedFullVNCName = fullVNCName;
	if (fullVNCName.contains(QChar(' ')))
	{
		enclosedFullVNCName = "\"" + fullVNCName + "\"";
	}

	QString specialFormatOption = project.specialFormat ? "y" : "n";
	QString recessiveOption = project.isRecessiveAllele ? "y" : "n";
    QString updateParameters = newRun.updateParameters ? "y" : "n";
	QString updatePsiParameter = newRun.updatePsiParameter ? "y" : "n";
	QString NJ = newRun.NJ ? "y" : "n";

	lhName = project.path + "/" + newRun.LH;
	alName = project.path + "/" + newRun.AL;
	dicName = project.path + "/" + newRun.fDIC;
	imName = project.path + "/" + newRun.IM;
	hcName = project.path + "/" + newRun.HC;
	apName = project.path + "/" + newRun.AP;
	trName = project.path + "/" + newRun.TR;
	

	QString cmdLine;
#ifdef Q_WS_WIN
	
	if (newRun.q)
	{
		if (newRun.admMod == "CAR")
		{
			cmdLine = 
		
				tr("tessmAdmCAR -F%1 -N%2 -A%3 -L%4 -K%5 -P%6 -D%7 -S%8 -B%9 -T%10 -r%11 -c%12 -d%13 -i%14 -o%15 -p%16 -v%17 -x%18 -g%19 -j%20 -sp%21 -u%22 -sc%23 -m%24 -up%25 -rc%26")
				.arg(enclosedDataName)
				.arg(project.N)
				.arg(project.A)
				.arg(project.L)
				.arg(newRun.K)
				.arg(newRun.P)
				.arg(newRun.D)	
				.arg(newRun.S)
				.arg(newRun.B)
				.arg(newRun.trendDegree)
				.arg(project.R)
				.arg(project.C)
				.arg(project.D)
				.arg(enclosedProjectPath)
				.arg(enclosedFullRunPath)
				.arg(enclosedFullZName)
				.arg(enclosedFullVNCName)
				.arg(newRun.sigma)
        	       	 	.arg(enclosedGeoDataName)
				.arg(NJ)
				.arg(specialFormatOption)
				.arg(updateParameters)
				.arg(newRun.scOpt)
				.arg(enclosedMapPredictName)
				.arg(updatePsiParameter)
				.arg(recessiveOption);
		}
		if (newRun.admMod == "BYM")
		{
			cmdLine =
			tr("tessmAdmBYM -F%1 -N%2 -A%3 -L%4 -K%5 -D%6 -S%7 -B%8 -T%9 -r%10 -c%11 -d%12 -i%13 -o%14 -p%15 -v%16 -x%17 -g%18 -j%19 -sp%20 -u%21 -sc%22 -m%23 -rc%24")
			.arg(enclosedDataName)
			.arg(project.N)
			.arg(project.A)
			.arg(project.L)
			.arg(newRun.K)
			.arg(newRun.D)
			.arg(newRun.S)
			.arg(newRun.B)
			.arg(newRun.trendDegree)
			.arg(project.R)
			.arg(project.C)
			.arg(project.D)
			.arg(enclosedProjectPath)
			.arg(enclosedFullRunPath)
			.arg(enclosedFullZName)
			.arg(enclosedFullVNCName)
			.arg(newRun.sigma)
			.arg(enclosedGeoDataName)
			.arg(NJ)
			.arg(specialFormatOption)
			.arg(updateParameters)
			.arg(newRun.scOpt)
			.arg(enclosedMapPredictName)
			.arg(recessiveOption);
		}
	}
	else
	{
		cmdLine = tr("tessm -F%1 -N%2 -A%3 -L%4 -K%5 -P%6 -D%7 -S%8 -B%9 -r%10 -c%11 -d%12 -i%13 -o%14 -p%15 -v%16 -j%17 -sp%18 -rc%19")
		.arg(enclosedDataName)
		.arg(project.N)
		.arg(project.A)
		.arg(project.L)
		.arg(newRun.K)
		.arg(newRun.P)
		.arg(newRun.D)
		.arg(newRun.S)
		.arg(newRun.B)
		.arg(project.R)
		.arg(project.C)
		.arg(project.D)
		.arg(enclosedProjectPath)
		.arg(enclosedFullRunPath)
		.arg(enclosedFullZName)
		.arg(enclosedFullVNCName)
		.arg(NJ)
		.arg(specialFormatOption)
		.arg(recessiveOption);
	}
	
	
#endif
#ifdef Q_WS_X11
	
	if (newRun.q)
	{
		if (newRun.admMod == "CAR")
		{
			cmdLine = 		
					tr("./tessmAdmCAR -F%1 -N%2 -A%3 -L%4 -K%5 -P%6 -D%7 -S%8 -B%9 -T%10 -r%11 -c%12 -d%13 -i%14 -o%15 -p%16 -v%17 -x%18 -g%19 -j%20 -sp%21 -u%22 -sc%23 -m%24 -up%25 -rc%26")
					.arg(enclosedDataName)
					.arg(project.N)
					.arg(project.A)
					.arg(project.L)
					.arg(newRun.K)
					.arg(newRun.P)
					.arg(newRun.D)
					.arg(newRun.S)
					.arg(newRun.B)
					.arg(newRun.trendDegree)
					.arg(project.R)
					.arg(project.C)
					.arg(project.D)
					.arg(enclosedProjectPath)
					.arg(enclosedFullRunPath)
					.arg(enclosedFullZName)
					.arg(enclosedFullVNCName)
					.arg(newRun.sigma)
					.arg(enclosedGeoDataName)
					.arg(NJ)
					.arg(specialFormatOption)
					.arg(updateParameters)
					.arg(newRun.scOpt)
					.arg(enclosedMapPredictName)
					.arg(updatePsiParameter)
					.arg(recessiveOption);
		}
		
		if (newRun.admMod == "BYM")
		{
			cmdLine = 
					tr("./tessmAdmBYM -F%1 -N%2 -A%3 -L%4 -K%5 -D%6 -S%7 -B%8 -T%9 -r%10 -c%11 -d%12 -i%13 -o%14 -p%15 -v%16 -x%17 -g%18 -j%19 -sp%20 -u%21 -sc%22 -m%23 -rc%24")
					.arg(enclosedDataName)
					.arg(project.N)
					.arg(project.A)
					.arg(project.L)
					.arg(newRun.K)
					.arg(newRun.D)
					.arg(newRun.S)
					.arg(newRun.B)
					.arg(newRun.trendDegree)
					.arg(project.R)
					.arg(project.C)
					.arg(project.D)
					.arg(enclosedProjectPath)
					.arg(enclosedFullRunPath)
					.arg(enclosedFullZName)
					.arg(enclosedFullVNCName)
					.arg(newRun.sigma)
					.arg(enclosedGeoDataName)
					.arg(NJ)
					.arg(specialFormatOption)
					.arg(updateParameters)
					.arg(newRun.scOpt)
					.arg(enclosedMapPredictName)
					.arg(recessiveOption);
		}
	}
	else
	{
		cmdLine = tr("./tessm -F%1 -N%2 -A%3 -L%4 -K%5 -P%6 -D%7 -S%8 -B%9 -r%10 -c%11 -d%12 -i%13 -o%14 -p%15 -v%16 -j%17 -sp%18 -rc%19")
		.arg(enclosedDataName)
		.arg(project.N)
		.arg(project.A)
		.arg(project.L)
		.arg(newRun.K)
		.arg(newRun.P)
		.arg(newRun.D)
		.arg(newRun.S)
		.arg(newRun.B)
		.arg(project.R)
		.arg(project.C)
		.arg(project.D)
		.arg(enclosedProjectPath)
		.arg(enclosedFullRunPath)
		.arg(enclosedFullZName)
		.arg(enclosedFullVNCName)
		.arg(NJ)
		.arg(specialFormatOption)
		.arg(recessiveOption);
	}
#endif

#ifdef Q_WS_MAC
	QString applPath = QCoreApplication::applicationDirPath();
	if (applPath.contains(QChar(' ')))
	{
		applPath = "\"" + applPath + "\""; 
	}
	if (newRun.q)
	{
		if (newRun.admMod == "CAR")
		{
			cmdLine = 		
					applPath + tr("/tessmAdmCAR -F%1 -N%2 -A%3 -L%4 -K%5 -P%6 -D%7 -S%8 -B%9 -T%10 -r%11 -c%12 -d%13 -i%14 -o%15 -p%16 -v%17 -x%18 -g%19 -j%20 -sp%21 -u%22 -sc%23 -m%24 -up%25 -rc%26")
					.arg(enclosedDataName)
					.arg(project.N)
					.arg(project.A)
					.arg(project.L)
					.arg(newRun.K)
					.arg(newRun.P)
					.arg(newRun.D)
					.arg(newRun.S)
					.arg(newRun.B)
					.arg(newRun.trendDegree)
					.arg(project.R)
					.arg(project.C)
					.arg(project.D)
					.arg(enclosedProjectPath)
					.arg(enclosedFullRunPath)
					.arg(enclosedFullZName)
					.arg(enclosedFullVNCName)
					.arg(newRun.sigma)
					.arg(enclosedGeoDataName)
					.arg(NJ)
					.arg(specialFormatOption)
					.arg(updateParameters)
					.arg(newRun.scOpt)
					.arg(enclosedMapPredictName)
					.arg(updatePsiParameter)
					.arg(recessiveOption);
		}
		
		if (newRun.admMod == "BYM")
		{
			cmdLine = 
					applPath + tr("/tessmAdmBYM -F%1 -N%2 -A%3 -L%4 -K%5 -D%6 -S%7 -B%8 -T%9 -r%10 -c%11 -d%12 -i%13 -o%14 -p%15 -v%16 -x%17 -g%18 -j%19 -sp%20 -u%21 -sc%22 -m%23 -rc%24")
					.arg(enclosedDataName)
					.arg(project.N)
					.arg(project.A)
					.arg(project.L)
					.arg(newRun.K)
					.arg(newRun.D)
					.arg(newRun.S)
					.arg(newRun.B)
					.arg(newRun.trendDegree)
					.arg(project.R)
					.arg(project.C)
					.arg(project.D)
					.arg(enclosedProjectPath)
					.arg(enclosedFullRunPath)
					.arg(enclosedFullZName)
					.arg(enclosedFullVNCName)
					.arg(newRun.sigma)
					.arg(enclosedGeoDataName)
					.arg(NJ)
					.arg(specialFormatOption)
					.arg(updateParameters)
					.arg(newRun.scOpt)
					.arg(enclosedMapPredictName)
					.arg(recessiveOption);
		}
	}
	else
	{
		
		cmdLine = applPath + tr("/tessm -F%1 -N%2 -A%3 -L%4 -K%5 -P%6 -D%7 -S%8 -B%9 -r%10 -c%11 -d%12 -i%13 -o%14 -p%15 -v%16 -j%17 -sp%18 -rc%19")
		.arg(enclosedDataName)
		.arg(project.N)
		.arg(project.A)
		.arg(project.L)
		.arg(newRun.K)
		.arg(newRun.P)
		.arg(newRun.D)
		.arg(newRun.S)
		.arg(newRun.B)
		.arg(project.R)
		.arg(project.C)
		.arg(project.D)
		.arg(enclosedProjectPath)
		.arg(enclosedFullRunPath)
		.arg(enclosedFullZName)
		.arg(enclosedFullVNCName)
		.arg(NJ)
		.arg(specialFormatOption)
		.arg(recessiveOption);
	}
#endif
	cle->start(cmdLine);
	
}

void TESSGUI::addMRunToProject()
{
	QFile al(alName);
	al.open(QIODevice::ReadOnly);
	QTextStream alIn(&al);
	newRun.L = alIn.readLine();
	al.close();
	
	QFile dic(dicName);
	dic.open(QIODevice::ReadOnly);
	QTextStream dicIn(&dic);
	newRun.DIC = dicIn.readLine();
	dic.close();

	project.runs.append(newRun);

	if (projectRunsItem)
	{
		runNameItem = new QTreeWidgetItem(projectRunsItem, 
			QStringList(newRun.name));
                new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Used Admixture: %1"))
						.arg(newRun.q ? tr("Yes") : tr("No"))));
                
		if (newRun.q)
		{
			new QTreeWidgetItem(runNameItem, 
					    QStringList(QString(tr("Admixture Model: %1"))
							    .arg(newRun.admMod)));
		}
		
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("Maximal Number of Clusters: %1"))
						    .arg(newRun.K)));
		

		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("DIC: %1"))
						    .arg(newRun.DIC)));
		
		if (!newRun.q || newRun.admMod != "BYM")
		{
			new QTreeWidgetItem(runNameItem, 
				QStringList(QString(tr("Spatial Interaction Parameter (init. value): %1"))
							.arg(newRun.P)));
		}
		
		
		if (project.hasGeoData)
		{
			if (newRun.scOpt == "m")
			{
				new QTreeWidgetItem(runNameItem, 
						QStringList(QString(tr("Scale Parameter: Mean Distance"))));
									
			}
			else if (newRun.scOpt == "d")
			{
				new QTreeWidgetItem(runNameItem, 
						QStringList(QString(tr("Scale Parameter: Median Distance"))));
									
			}
			else if (newRun.scOpt == "x")
			{
				new QTreeWidgetItem(runNameItem, 
						QStringList(QString(tr("Scale Parameter: Max Distance"))));
									
			}
			else
			{
				new QTreeWidgetItem(runNameItem, 
						QStringList(QString(tr("Scale Parameter: %1"))
								.arg(newRun.scOpt)));
				
			}
		}
		
		if (newRun.T == tr("with Admixture") && newRun.q)
		{
			new QTreeWidgetItem(runNameItem, 
					QStringList(QString(tr("Trend Degree: %1"))
							.arg(newRun.trendDegree)));
				
			new QTreeWidgetItem(runNameItem, 
					QStringList(QString(tr("Initial CAR Variance: %1"))
							.arg(newRun.sigma)));
		}
		
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("Parameter of Allele Freq. Model: %1"))
						    .arg(newRun.D)));
		
		
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("Total Number of Sweeps: %1"))
						    .arg(newRun.S)));
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("Burn In Number of Sweeps: %1"))
						    .arg(newRun.B)));
		
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Continued Lowest DIC Run: %1"))
						.arg(newRun.C ? tr("Yes") : tr("No"))));
		new QTreeWidgetItem(runNameItem, 
				    QStringList(QString(tr("Started from Neighbour Joining Tree: %1"))
						    .arg(newRun.NJ ? tr("Yes") : tr("No"))));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Log-Likelihood History: %1"))
						.arg(newRun.LH)));

		
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Average Log-Likelihood: %1"))
						.arg(newRun.L)));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Initial Membership of Individuals: %1"))
						.arg(newRun.IM)));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Hard Clustering: %1"))
						.arg(newRun.HC)));
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Assignment Probabilities: %1"))
						.arg(newRun.AP)));
		
		if (newRun.T == tr("with Admixture") && newRun.q)
		{
			new QTreeWidgetItem(runNameItem, 
					    QStringList(QString(tr("Beta History: %1"))
							    .arg(newRun.BH)));
		}
		
		new QTreeWidgetItem(runNameItem, 
			QStringList(QString(tr("Textual Results: %1"))
						.arg(newRun.TR)));
	}

	projectModified = true;
	saveProject();
	
	addRunToSummaryTable();
	

	updateMenus();
}
