#ifndef TESSGUI_H
#define TESSGUI_H

#include <QMainWindow>
#include <QProcess>
#include "modifynsdialog.h"
#include "project.h"
#include "RNGUtilities.h"
// #include "summarytable.h"
#include "summarydialog.h"

class QAction;
class QCloseEvent;
class QMenu;
class QSignalMapper;
class QTableWidget;
class QTextEdit;
class QToolBar;
class QTreeWidgetItem;
class QTableWidgetItem;
class QWorkspace;

class DataWindow;
class GraphWindow;
class TextWindow;
class TreeWidget;

#define MAX_RECENT_PROJECTS 8

class TESSGUI : public QMainWindow
{
    Q_OBJECT

public:
    TESSGUI(QWidget *parent = 0, Qt::WFlags flags = 0);
    ~TESSGUI();

protected:
	void closeEvent(QCloseEvent *event);

private slots:
	void openData();
	void newProject();
	void openProject();
	void closeProject();
	void saveProject();
	void openGraph();
	void openText();
	void openRecentProject();
	void quit();
	void modify();
	void run();
	void abort();
	void generate();
	void resample();
	void summarize();
	void computeGeo();
	void clearInfoWindow();
	void openReference();
	void about();
	void updateMenus();
	void updateWindowMenu();
	void loadSummaryItem(QTableWidgetItem *item);
	void loadProjectItem(QTreeWidgetItem *item, int column);
	void deleteRunItem(QString item);
	void removeRunDir(QString dirName);
	void notModifying();
	void notSummarizing();
	bool summaryRangeUpdated();
	void exportToClumppPopfile();
	void exportTableToText();
	void populateCandidateRuns(int KmaxIndex);
	void filterCandidateRuns(int percentageIndex);
	void reloadNeighborhoodDiagram();
	void cleError(QProcess::ProcessError error);
	void cleFinished(int exitCode, QProcess::ExitStatus exitStatus);
	void cleReadStandardError();
	void cleReadStandardOutput();
	void cleStarted();
	void cleStateChanged(QProcess::ProcessState newState);

private:
	void createActions();
	void createMenus();
	void createToolBars();
	void createStatusBar();
	void createDockWindows();

	DataWindow *createDataWindow(int EC = 0, int ER = 0);
	DataWindow *findDataWindow(const QString &fileName);

	GraphWindow *createGraphWindow();
	GraphWindow *findGraphWindow(const QString &fileName);

	TextWindow *createTextWindow();
	TextWindow *findTextWindow(const QString &fileName);

	bool loadData(const QString &fullDataPath, int EC = 0, int ER = 0);
	bool loadProject(const QString &projectName);
	bool readProjectSettings(const QString &projectName);
	bool populateProjectTreeWidget();
	bool initSummary();
	void loadGraph(const QString &fileName);
	void loadText(const QString &fileName);
	void setCurrentProject(const QString &projectName);
	void updateRecentProjectActions();
	QString strippedProjectName(const QString &projectName);
	bool writeProjectSettings(const QString &projectName);
	void closeData(const QString &fileName);
	void closeGraph(const QString &fileName);
	void closeText(const QString &fileName);
	bool translateCoordinates(vector< vector< double > > &C);
	bool generateVNC();
	void setDefaultRunParameters();
	void performMRun();
	void addMRunToProject();
	void performARun();
	void calculateSignificanceProbability();
	int summaryLowerRange;
	int summaryUpperRange;
	
	void updateSummaryTable();
	void updateDICTable(QStringList candidateList, int Kmax);
	void addRunToSummaryTable();
	void removeRunFromSummaryTable(int runLabel, int Kremoved);

	QWorkspace *workspace;
	QSignalMapper *windowMapper;

	TreeWidget *projectTreeWidget;
// 	SummaryTable *summaryTable;
	SummaryDialog *summaryDialog;
	QTreeWidgetItem *projectRunsItem;
	QTreeWidgetItem *runNameItem;

	QTextEdit *infoTextEdit;

	// File
	QAction *openDataAct;
	QAction *newProjectAct;
	QAction *openProjectAct;
	QAction *closeProjectAct;
	QAction *saveProjectAct;
	QAction *openGraphicalResultsAct;
	QAction *openTextualResultsAct;
	QAction *recentProjectSeparatorAct;
	QAction *recentProjectActs[MAX_RECENT_PROJECTS];
	QAction *quitAct;

	// Project
	QAction *modifyAct;
	QAction *runAct;
	QAction *abortAct;
	QAction *summarizeAct;

	// Tools
	QAction *generateAct;
	QAction *resampleAct;
	QAction *kinshipAct;
	QAction *geoAct;

	// View
	QAction *clearAct;

	// Window
	QAction *closeAct;
	QAction *closeAllAct;
	QAction *tileAct;
	QAction *cascadeAct;
	QAction *arrangeAct;
	QAction *nextAct;
	QAction *previousAct;
	QAction *windowSeparatorAct;

	// Help
	QAction *referenceAct;
	QAction *aboutAct;

	QMenu *fileMenu;
	QMenu *projectMenu;
	QMenu *toolsMenu;
	QMenu *viewMenu;
	QMenu *windowMenu;
	QMenu *helpMenu;

	QToolBar *fileToolBar;
	QToolBar *projectToolBar;
	QToolBar *toolsToolBar;
	QToolBar *viewToolBar;
	QToolBar *helpToolBar;

	Project project;
	bool projectOpened;
	bool projectModified;
	QString currentProject;
	bool summaryOpened;

	bool modifying;
	ModifyNSDialog *mnsd;

	bool mainRun;
	int currARun;
	int currMRun;
	int totMRun;
	int currK;

	Run oldRun;
	Run newRun;

	QString enName;  // Estimated Number of Clusters
	QString lhName;  // Log-Likelihood History
	QString khName;	 // Kinship histogram
	QString alName;  // Average Log-Likelihood
	QString dicName; //Decision Information Criterion
	QString imName;  // Initial Membership
	QString hcName;  // Hard Clustering
	QString apName;  // Assignment Probabilities (Soft Clustering)
	QString trName;  // Textual Results
	QString lrName;  // Logarithm of Likelihood Ratio

	// Command-Line Engine (TESS MCMC and TESS EM)
	QProcess *cle;
	QProcess::ProcessState cleState;

	// For Tools
	gsl_rng *rng;
	
	// To populate clumpp popfile
	vector< vector < double > > tableDIC;
	
	
};

#endif // TESSGUI_H
