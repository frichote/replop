#include <QtCore>
#include <QtGui>
#include "textwindow.h"
#include "title.h"

TextWindow::TextWindow(QWidget *parent)
    : QTextEdit(parent)
{
	setAttribute(Qt::WA_DeleteOnClose);
	setWindowIcon(QIcon(":/images/filetext.png"));

	setReadOnly(true);
	QFont courierFont("Courier", 10, QFont::Bold);
	setCurrentFont(courierFont);
	setLineWrapMode(QTextEdit::NoWrap);
}

TextWindow::~TextWindow()
{
}

bool TextWindow::loadFile(const QString &fileName)
{
	QFile file(fileName);
	if (!file.open(QFile::ReadOnly | QFile::Text)) 
	{
		QMessageBox::warning(this, GUI_TITLE,
			tr("Cannot load text file %1!").arg(fileName));
		return false;
	}

	QTextStream in(&file);
	QApplication::setOverrideCursor(Qt::WaitCursor);
	setPlainText(in.readAll());
	QApplication::restoreOverrideCursor();

	setWindowTitle(fileName);
	setCurrentFile(fileName);

	return true;
}

void TextWindow::setCurrentFile(const QString &fileName)
{
	file = QFileInfo(fileName).canonicalFilePath();
}
