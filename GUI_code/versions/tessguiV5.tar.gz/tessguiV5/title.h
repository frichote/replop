#ifndef TITLE_H
#define TITLE_H

#define CMD_TITLE tr("TESS")
#define GUI_TITLE tr("TESS GUI")

#endif//TITLE_H
