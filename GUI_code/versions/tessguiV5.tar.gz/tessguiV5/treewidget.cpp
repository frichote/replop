#include <QtGui>
#include "treewidget.h"

TreeWidget::TreeWidget(QWidget *parent)
    : QTreeWidget(parent)
{
}

TreeWidget::~TreeWidget()
{
}

void TreeWidget::keyPressEvent(QKeyEvent *event)
{
	if (event->key() == Qt::Key_Delete && currentItem()->text(0).contains(tr("_RUN_")))
	{
		QTreeWidgetItem *itemToBeDeleted = currentItem();
		QString item = itemToBeDeleted->text(0);
		QTreeWidgetItem *parent = itemToBeDeleted->parent();  // Item of Project Runs
		delete parent->takeChild(parent->indexOfChild(itemToBeDeleted));
		emit runItemDeleted(item);
	}
	else
	{
		QTreeWidget::keyPressEvent(event);
	}
}
