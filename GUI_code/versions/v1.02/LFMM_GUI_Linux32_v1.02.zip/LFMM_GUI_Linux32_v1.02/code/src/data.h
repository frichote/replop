#ifndef DATA_H
#define DATA_H

#define SEP " " // Séparateur utilisé dans le fichier

void update_m(double *beta, int n, int nb);

void write_DIC(char *file_data, double deviance, double DIC);

void update_deviance(double *deviance, float *R, double *U, double *V, double *beta, double *C, 
                     int N, int M, int D, int K, int cur, int num_thrd, double var, double thrd_m2);

void zeros(double *A, int n);

int check_mat(double *A, int n, int nd, int nD);

void write_zscore_double(char *file_data, int M, int nD, double* dat);

void zscore_calc(double *beta, double *mean, double *sum, double *sum2, int n, int cur, int d, int nD);

void update_sum(double *beta, double *sum, int n);

void update_sum2(double *beta, double *sum2, int n);

void update_mean(double *beta, double *mean, int n, int cur);

void create_I(float* dat, int* I, int N, int M);

void print_data(float *dat, int N, int M);

void clean_data(float *dat, int*col, int N, int M, int n);

void modify_C(double *C, int N, int nD, double *Cpp, int d);

void write_data_float(char *file_data, int N, int M, float* dat);

void write_data_double(char *file_data, int N, int M, double* dat);

double var_data(float *R, double *U, double *V, double *C, double *beta, int N, int M, int K, int D, double *thrd_m2, int num_thrd);

void inputation(float *R, double *U, double *V, double *C, double *beta, int *I, int N, int M, int K, int D);

#endif // DATA_H
