#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "data.h"
#include "error.h"
#include "thread_var.h"
#include "rand.h"

void zeros(double *A, int n) {
	
	int i;

	for (i=0;i<n;i++)
		A[i] = 0;

}

int check_mat(double *A, int n, int nd, int nD) {

	int i;

	for(i=0;i<n;i++) {
		if (isnan(A[i*nD+nd]))
			return 1;
	}
	return 0;

}

void zscore_calc(double *beta, double *mean, double *sum, double *sum2, int n, int cur, int d, int nD) {

	int i;
	double var;

	for(i=n;i<2*n;i++) {
		var = ((sum2[i] - 2*mean[i]*sum[i] + mean[i]*mean[i]*(double)cur)/(double)(cur-1));
		beta[(i-n)*nD+d] = (mean[i])/sqrt(var);
	}

}

void update_sum(double *beta, double *sum, int n) {

	int i;

	for(i=0;i<n;i++) 
		sum[i] += beta[i];

}

void update_sum2(double *beta, double *sum2, int n) {

	int i;

	for(i=0;i<n;i++) 
		sum2[i] += (beta[i] * beta[i]);

}

void update_deviance(double *deviance, float *R, double *U, double *V, double *beta, double *C, 
		     int N, int M, int D, int K, int cur, int num_thrd, double var) {
	int i,j,k,d;
	double mean;
	double tmp1, tmp2;

        thrd_var(R,U,V,C,beta,K,D,M,N,num_thrd,slice_var,0,&mean);
	mean /= var;

	*deviance  = ((double)(cur-1)*(*deviance) + mean)/(double)cur;
}

void update_mean(double *beta, double *mean, int n, int cur) {

	int i;

	for(i=0;i<n;i++) 
		mean[i] = ((double)(cur-1)*mean[i] + beta[i])/(double)cur;

}

void modify_C(double *C, int N, int nD, double *Cpp,int d) {

	int i,k;

	for (i=0; i<N; i++)
		Cpp[i*nD] = 1.0;

	for (i=0; i<N; i++) {
		//for (k=0; k<K-1; k++) {
			Cpp[i*nD+1] = C[i*nD+d];
		//}
	}


}

void create_I(float* dat, int* I, int N, int M) {

	int i;
	for (i=0; i<N*M; i++) {
		if (dat[i] == -9)
			I[i] = 0;
		else
			I[i] = 1;
	}
}

void write_DIC(char *file_data, double deviance, double DIC) {

	FILE *file = NULL;
	int i,j;

	file = fopen(file_data,"a");
	if (!file) 
		print_error("open",file_data,0);

	fprintf(file, "%G %G\n",deviance,DIC);        
	fclose(file);
}

void write_data_float(char *file_data, int N, int M, float* dat) {

	FILE *file = NULL;
	int i,j;

	file = fopen(file_data,"w");
	if (!file) 
		print_error("open",file_data,0);

	for(i=0; i<N; i++) {
		for(j = 0; j < M-1; j++) {
			fprintf(file, "%G ", dat[i*M+j]);        
		}
		fprintf(file, "%G", dat[i*M+(M-1)]);        
		fprintf(file, "\n");        
	}
	fclose(file);
}

void write_zscore_double(char *file_data, int M, int nD, double* dat) {

	FILE *file = NULL;
	int i,j;
	double pvalue;

	file = fopen(file_data,"w");
	if (!file) 
		print_error("open",file_data,0);

	for(j = 0; j < M; j++) {
		for(i = 0; i < nD; i++) {
			pvalue = zscore2pvalue(dat[j*nD+i]);
			fprintf(file, "%G %G %G ",fabs(dat[j*nD+i]),-log(pvalue)/log(10),pvalue);        
		}
		fprintf(file, "\n");
	}
	fclose(file);
}

void write_data_double(char *file_data, int N, int M, double* dat) {

	FILE *file = NULL;
	int i,j;

	file = fopen(file_data,"w");
	if (!file) 
		print_error("open",file_data,0);

	for(i=0; i<N; i++) {
		for(j = 0; j < M-1; j++) {
			fprintf(file, "%G ", dat[i*M+j]);        
		}
		fprintf(file, "%G", dat[i*M+(M-1)]);        
		fprintf(file, "\n");        
	}
	fclose(file);
}

void print_data(float *dat, int N, int M) {

	int i,j;

	for(i=0; i<N; i++) {
		for(j = 0; j < M; j++) {
			printf("%f ", dat[i*M+j]);        
		}
		printf("\n");        
	}
}

void clean_data(float *dat, int*col, int N, int M, int nM) {
	int i,j,jp;
	float *tmp, *tmp2;
	int newM;

	if(nM) {
		newM = M - nM;
		tmp = (float*)malloc(N*newM*sizeof(float));
		jp = 0;
		for(j = 0; j < M; j++) {
			if(!col[j]) {	
				for(i=0; i<N; i++) {
					tmp[i*M+jp] = dat[i*M+j];
				}
				jp ++;
			}
		}
		tmp2 = dat;
		free(tmp2);
		dat = tmp;
	}
}

double var_data(float *R, double *U, double *V, double *C, double *beta, int N, int M, int K, int D, int num_thrd) {

	int i,j,k,d;
	double mean;
	double tmp1,tmp2;
	double var;

	if (num_thrd > 1) {
		thrd_var(R,U,V,C,beta,K,D,M,N,num_thrd,slice_mean,0,&mean);
		mean /= N*M;
		thrd_var(R,U,V,C,beta,K,D,M,N,num_thrd,slice_var,mean,&var);
		return var/(N*M -1);


	} else {
		mean = 0;
		for(i=0;i<N;i++) {
			for(j=0;j<M;j++) {
				tmp1 = 0;
				for(k=0;k<K;k++)
					tmp1 += C[i*K+k]*beta[k*M+j];
				tmp2 = 0;
				for(d=0;d<D;d++)
					tmp2 += U[d*N+i]*V[d*M+j];
				mean += (double)(R[i*M+j])-tmp1-tmp2;
			}
		}
		mean /= N*M;

		var = 0;
		for(i=0;i<N;i++) {
			for(j=0;j<M;j++) {
				tmp1 = 0;
				for(k=0;k<K;k++)
					tmp1 += C[i*K+k]*beta[k*M+j];
				tmp2 = 0;
				for(d=0;d<D;d++)
					tmp2 += U[d*N+i]*V[d*M+j];
				var += ((double)(R[i*M+j])-tmp1-tmp2 - mean)*((double)(R[i*M+j])-tmp1-tmp2 - mean);
			}
		}
		return var/(N*M-1);
	}

}

void inputation(float *R, double *U, double *V, double *C, double *beta, int *I, int N, int M, int K, int D) {

	int i,j,k,d;
	double tmp1, tmp2;

	for(i=0;i<N;i++) {
		for(j=0;j<M;j++) {
			if (!I[i*M+j]) {
				tmp1 = 0;
				for(k=0;k<K;k++)
					tmp1 += C[i*K+k]*beta[k*M+j];
				tmp2 = 0;
				for(d=0;d<D;d++)
					tmp2 += U[d*N+i]*V[d*M+j];
				R[i*M+j] = (float)(tmp1+tmp2);
			}
		}
	}
}
