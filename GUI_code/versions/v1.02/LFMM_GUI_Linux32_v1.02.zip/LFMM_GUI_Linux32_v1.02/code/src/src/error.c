#include "error.h"
#include "print.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void print_error(char* msg, char*file, int n) {

	printf("\n");
	if(!strcmp(msg,"open")) {
	        printf("ERROR: unable to open file %s. Please, check that the name of the file you provided is correct.\n",file);
	} else if (!strcmp(msg,"read")) {
	        printf("ERROR: unable to read file %s. Please, check check that the format is correct (refer to the documentation).\n",file);
	} else if (!strcmp(msg,"interne")) {
	        printf("ERROR: internal error. Please run the program again. If the error is repeated, contact us.\n");
	} else if (!strcmp(msg,"constant")) {
	        printf("ERROR: %d SNPs are invariant. Please, remove these SNPs before the analysis.\n",n);
	} else if (!strcmp(msg,"nan")) {
	        printf("ERROR: internal error. Please, run the program again. If the error is still present, contact us.\n");
	} else if (!strcmp(msg,"cmd")) {
	        printf("ERROR: no value for %s.\n\n",file);
		print_help();
	} else if (!strcmp(msg,"option")) {
	        printf("ERROR: the following option is mandatory: %s.\n\n",file);
		print_help();
	} else if (!strcmp(msg,"missing")) {
	        printf("ERROR: one of the following options is missing or equal 0: -K / -L / -n / -b / -i \n\n");
		print_help();
	} else if (!strcmp(msg,"basic")) {
	        printf("ERROR: the command is not written correctly.\n\n");
		print_help();
	} else if (!strcmp(msg,"specific")) {
	        printf("ERROR: %s.\n\n",file);
		print_help();
	} else {
		printf("ERROR: Internal error.\n");
	}

	printf("\n");
	exit(1); 

}
