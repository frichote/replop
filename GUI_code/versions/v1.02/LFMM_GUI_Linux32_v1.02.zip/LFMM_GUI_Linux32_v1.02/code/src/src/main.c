#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "rand.h"
#include "matrix.h"
#include "data.h"
#include "normalize.h"
#include "analyse.h"
#include "inverse.h"
#include "print.h"
#include "generative.h"
#include "beta.h"
#include "U.h"
#include "V.h"
#include "error.h"
#include "thread_var.h"
#include "register.h"
#include "read.h"
#include <time.h>

int main (int argc, char *argv[]) {

	// Parameters initialization

	// be careful: K and D are switched.
	int N = 0;
	int M = 0;
	int D = 2;
	int nD = 1;
	int nd;
	int K = 0;
	int burn = 0;
	int Niter = 0;
	int num_thrd = 1;
	int missing_data = 0;
	int g_data = -1;
int g_cov = -1;
	char output_file[512];
	char input_file[512];
	char cov_file[512];
	//char dev_file[512];

	// temporary variables

	double *m_beta, *m_U, *m_V;			// mean 
	double *inv_cov_beta, *inv_cov_U, *inv_cov_V;	// covariance matrix
	double *beta, *U, *V;				// beta, U, V
	double *C,*nC, *CCt;			// covariable
	double *nbeta;
	//double *Cpp;

	float *dat;					// data matrix
	int *I = NULL;					// missing value matrix
	double *mean, *sum, *sum2;			// to calculate zscore
	double deviance, dp, *mean_U, *mean_V;		// to calculate zscore
	double alpha_R, *alpha_beta, alpha_U; 		// prior alpha*
	double epsilon = 1000;				// hyperprior epsilon

	double *bb, b;
	int a;
	int nM = 0;
	int i,d,j,jp,n;
	int shell_size = 77;
	int shell_unit;
	struct timespec start, finish;
	double elapsed;

	char dev_file[512] = "DIC.txt";
	FILE *file = NULL;
        file = fopen(dev_file,"w");
	fprintf(file, "Deviance DIC\n");
	fclose(file);

	print_head();
	// clock start

	clock_gettime(CLOCK_MONOTONIC, &start);

	// random initialization

	init_random();

	// analyse of the command line

	analyse_param(argc,argv,&nD,
                       	&N, &M, &K, &Niter, &burn,
                        &missing_data, output_file, input_file, cov_file, 
                        &g_data, &g_cov,
			&num_thrd);

	// print summary of command line

	print_summary (N, M, K,nD,Niter, burn,
                        missing_data, output_file, input_file, cov_file, num_thrd);

	// allocate data memory

	m_beta = (double*)malloc(D*M*sizeof(double));
	inv_cov_beta = (double*)malloc(D*D*sizeof(double));
	m_U = (double*)malloc(K*N*sizeof(double));
	inv_cov_U = (double*)malloc(K*K*sizeof(double));
	m_V = (double*)malloc(K*M*sizeof(double));
	inv_cov_V = (double*)malloc(K*K*sizeof(double));

	dat = (float*)calloc(N*M,sizeof(float));
	if (missing_data) {
		I = (int*)calloc(N*M,sizeof(int));
	}
	//C = (double*)calloc(N*(D-1),sizeof(double));	// (N,(D-1))
	nC = (double*)calloc(N*nD,sizeof(double));	// (N,(D-1))
	U = (double*)calloc(K*N,sizeof(double));	// (N,K)
	V = (double*)calloc(K*M,sizeof(double));	// (N,K)
	mean = (double*)calloc(D*M,sizeof(double));
	mean_U = (double*)calloc(K*N,sizeof(double));
	mean_V = (double*)calloc(K*M,sizeof(double));
	sum = (double*)calloc(D*M,sizeof(double));
	sum2 = (double*)calloc(D*M,sizeof(double));
	beta = (double*)calloc(D*M,sizeof(double));
	nbeta = (double*)calloc(nD*M,sizeof(double));
	CCt = (double*)calloc(D*D,sizeof(double));
	bb = (double*)calloc(D,sizeof(double));
	alpha_beta = (double*)calloc(D,sizeof(double));
        C = (double*)calloc(N*D,sizeof(double));        // (N,K)
	

	// read covariable

	/*
	if(g_cov) {
		rand_matrix_double(C,N,D-1);
	} else
	*/
	read_data_double2(cov_file,N,nD,nC);
	
	normalize_cov(nC,N,nD);

        // add of the biais

	//C = Cpp;
	//free(tmp);

	printf("Read variable file %s:\t\tOK.\n\n",cov_file);

	// read data
	read_data_float2(input_file,N,M,dat);
	

	//if (missing_data && g_data)
	//	NULL;
	if (missing_data && !g_data)
		create_I(dat,I,N,M);

	// (pré) analyse data
	//analyse_col(dat,N,M,&nM,missing_data,I);
	
	// clean data
	// clean_data(dat,col,N,M,nM);
	if(nM) {
		M = M - nM;
		print_error("constant",NULL,nM);
		//printf("**** Warning: %d colums are constant *****\n",nM);
	} //else
	//	printf("**** No column is constant *****\n");

	if(nD>1) {
		printf("WARNING: You launched LFMM command line with several covariables. The model will be\nlaunched sequentially (independently) for each covariable.\n\n");
	}

	printf("Read genotype file %s:\t\tOK.\n",input_file);


	for (nd=0;nd<nD;nd++) {
	
	// Gibbs Sampler
	printf("\nStart of the Gibbs Sampler algorithm.\n\n");

	deviance = 0;
	dp = 0;
	zeros(mean,D*M);
	zeros(mean_U,K*N);
	zeros(mean_V,K*M);
	zeros(sum,D*M);
	zeros(sum2,D*M);
	zeros(m_beta,D*M);
	zeros(inv_cov_beta,D*D);
	zeros(m_U,K*N);
	zeros(inv_cov_U,K*K);
	zeros(m_V,K*M);
	zeros(inv_cov_V,K*K);
	zeros(CCt,D*D);

	printf("Analyse for covariable %d\n\n",nd+1);
        modify_C(nC,N,nD,C,nd);

	create_CCt(CCt,C,D,N);	

	//tmp = C;
	// init U, V and beta
	rand_matrix_double(beta,D,M);
	rand_matrix_double(U,K,N);
	rand_matrix_double(V,K,M);
	rand_matrix_double(&alpha_R,1,1);

	// shell print
	shell_unit = (int)(Niter/shell_size);
	i = 0;
	j = 0;
	printf("[");

	n = 0;
	while(n<Niter) {

		// print time

		// printf("itération %d %s beta %G\n",n,ctime(&timer),beta[0]);
		// print_mat(beta,K,M);
		/*
		file = fopen(time_file,"a");
		timer = time(NULL);
		fprintf(file,"itération %d %s beta %G\n",n,ctime(&timer),beta[0]);
		fclose(file);	
		*/		

		// print shell
		if (i<shell_unit)
			i++;
		else {
			j++;
			for (i=0; i<100; i++)
			{
  				printf("\b");
			}
			printf("\r[");
			i = 0;
			for (jp=0;jp<j;jp++)
				printf("=");
			for (jp=j;jp<shell_size-5;jp++)
				printf(" ");
			printf("]");
		}	

	// >>>>>>>>>>>>>>>>           inputation        <<<<<<<<<<<<<<<<<<<<

		if (missing_data)
			inputation(dat,U,V,C,beta,I,N,M,D,K);


	// >>>>>>>>>>>>>>>>>       update alpha_R       <<<<<<<<<<<<<<<<<<<<
	
		//a = (int)(epsilon) + N*M/2;
    		//b = 1/2*sum(sum(U.^2)) + 1/2*sum(sum(V.^2));
		//b = 0.5 *(N*M-1)* var_data(dat,U,V,C,beta,N,M,D,K,num_thrd)+ epsilon; // U(D,N) V(D,M)
		//printf("1: %d %f\n",a,b);
		
		//alpha_R = rand_gamma(a,1.0/b);
		//printf("1: %d %f %f\n",a,b,alpha_R);
		//alpha_R = 1;

	// >>>>>>>>>>>>>>>>>       update alpha         <<<<<<<<<<<<<<<<<<<<

		//a = 1 + (N+M)*D/2;
		a = (int)(epsilon) + N*K/2;
    		// b = 1/2*sum(sum(U.^2)) + 1/2*sum(sum(V.^2));
		b = 0.5 * dble_sum(U,N*K) + epsilon; // U(D,N) V(D,M)
		
		alpha_U = rand_gamma(a,1.0/b);
		//printf("2: %d %f %f\n",a,b,alpha_U);

	// >>>>>>>>>>>>>>>>>       update alpha_beta     <<<<<<<<<<<<<<<<<<<<

		//a = 1 + M/2;
		a = (int)(epsilon) + M/2;

    		// b = 1/2 * sum(sum(beta.^2));
                dble_sum2(beta,D,M,bb,epsilon);	// beta(K,M)

    		for (d=0;d<D;d++) {
        	        alpha_beta[d] = rand_gamma(a,1.0/(double)(bb[d]));
		}	
		//printf("3: %d %f %f %f %f\n",a,bb[0],bb[1],alpha_beta[0],alpha_beta[1]);

	// >>>>>>>>>>>>>>>>>         update beta         <<<<<<<<<<<<<<<<<<<<

    		// m_beta = C' * (I.*(R - U'*V));  			(D,M)
		create_m_beta(C,dat,U,V,m_beta,M,N,K,D,dat,num_thrd);

    		// cov_beta = alpha_beta .* eye(D) + alpha_R .* C'*C;	(D,D)
		create_inv_cov_beta(inv_cov_beta,alpha_beta,alpha_R,D,CCt);

    	/*	mu_beta = alpha_R .* inv(cov_beta) * m_beta;		(D,M)
    		for j=1:M
        		beta(:,j) = mvnrnd(mu_beta(:,j),inv(cov_beta));
    		end								*/
		rand_beta(beta,m_beta,inv_cov_beta,alpha_R,D,M,num_thrd);

		if (isnan(beta[0]))
			print_error("nan",NULL,0);

	// >>>>>>>>>>>>>>>>>         update U             <<<<<<<<<<<<<<<<<<<<
//
    		// m_U = (I.*(R - C*beta)) * V';			(N,K)
		create_m_U(V,dat,C,beta,m_U,M,N,K,D,dat,num_thrd);

    		// cov_U = alpha .* eye(K) + alpha_R .* V*V';		(K,K)
		create_inv_cov_U(inv_cov_U,alpha_U,alpha_R,V,K,M,num_thrd);

    	/*	mu_U = alpha_R .* inv(cov_U) * m_U';			(N,K)
    		for i=1:N
        		U(:,i) = mvnrnd(mu_U(:,i),inv(cov_U));
    		end 								*/
		rand_U(U,m_U,inv_cov_U,alpha_R,K,N,num_thrd);

		if (isnan(U [0]))
			print_error("nan",NULL,0);

	// >>>>>>>>>>>>>>>>>         update V             <<<<<<<<<<<<<<<<<<<<

    		// m_V = U * (I.*(R - C*beta));				(K,M)
		create_m_V(U,dat,C,beta,m_V,M,N,K,D,dat,num_thrd);

    		// cov_V = alpha .* eye(K) + alpha_R .* U*U';		(K,K)
		create_inv_cov_V(inv_cov_V,(double)(1),alpha_R,U,K,N,num_thrd);

    	/*	mu_V = alpha_R .* inv(cov_V) * m_V;			(K,M)
    		for j=1:M
        		V(:,j) = mvnrnd(mu_V(:,j),inv(cov_V));
    		end 								*/
		rand_V(V,m_V,inv_cov_V,alpha_R,K,M,num_thrd);

		if (isnan(V[0])) 
			print_error("nan",NULL,0);
	
	// >>>>>>>>>>>>>>>>>         z score update      <<<<<<<<<<<<<<<<<<<<

		alpha_R = 1.0/var_data(dat,U,V,C,beta,N,M,D,K,num_thrd);	
		if (n >= burn) {
			//update_mean(1/alpha_R,&mean_var,1,n-burn+1);
			update_mean(beta,mean,D*M,n-burn+1);
			update_mean(U,mean_U,K*N,n-burn+1);
			update_mean(V,mean_V,K*M,n-burn+1);
			update_sum(beta,sum,D*M);
			update_sum2(beta,sum2,D*M);
			update_deviance(&deviance,dat,U,V,beta,C,N,M,K,D,n-burn+1,num_thrd,1/alpha_R);
		}
		n++;
	} 

	printf("\n\n");
	printf("End of the Gibbs Sampler algorithm.\n\n");

	// calculate zscore
	zscore_calc(nbeta,mean,sum,sum2,M,Niter-burn,nd,nD);

	// check zscore
	if (check_mat(nbeta,M,nd,nD))
		print_error("nan",NULL,0);

        thrd_var(dat,mean_U,mean_V,C,mean,D,K,M,N,num_thrd,slice_var,0,&dp);
        dp /= var_data(dat,mean_U,mean_V,C,mean,N,M,D,K,num_thrd);


	// register beta and zscore
	printf(">>>> The execution for covariable %d worked without error. <<<<\n\n",nd+1);
	printf("Deviance: %3.10G \t DIC: %3.10G \n\n",deviance,2*deviance - dp);
	write_DIC(dev_file,deviance,2*deviance-dp);
	}

	write_zscore_double(output_file,M,nD,nbeta);

	printf("The zscores were registered in %s.\n\n",output_file);
	// free memory
	if (missing_data) {
		free(I);
	}
	free(C);
	free(nC);
	free(m_beta);
	free(inv_cov_beta);
	free(m_U);
	free(inv_cov_U);
	free(m_V);
	free(inv_cov_V);
	free(U);
	free(V);
	free(beta);
	free(nbeta);
	free(mean);
	free(mean_U);
	free(mean_V);
	free(sum2);
	free(sum);
	free(dat);	
	free(CCt);	
	free(bb);	
	free(alpha_beta);	

	clock_gettime(CLOCK_MONOTONIC, &finish);

	elapsed = (finish.tv_sec - start.tv_sec);
	elapsed += (finish.tv_nsec - start.tv_nsec) / 1000000000.0;
	printf("Execution time: %2.2fs\n\n",elapsed);

   	return 0;
}

