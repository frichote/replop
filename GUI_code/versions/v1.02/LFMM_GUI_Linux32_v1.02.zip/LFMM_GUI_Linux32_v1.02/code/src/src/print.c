#include "print.h"
#include <stdio.h>
#include <stdlib.h>

void print_head() {
	printf("****                      LFMM Version 1.01                     		*****\n" 
	       "****   E. Frichot, S. Schoville, G. Bouchard, O. Francois       		*****\n" 
	       "****         	        Please cite our paper !                 	     	*****\n" 
	       "****   Information at http://membres-timc.imag.fr/Olivier.Francois/lfmm.html 	*****\n\n"); 
}


void print_help() {

   printf("\nHELP: ./LFMM options \n\n"
         "mandatory:\n"
         "	-g genotype_file   				-- genotype file\n"
         "        -v variable_file     				-- variable file\n"
         "        -n n 						-- number n of individus\n"  
         "        -L L 						-- number L of SNPS\n"  
         "        -K K 						-- K number of latent factors\n"
         "        -D D 						-- D number of covariables\n"
         "        -o output_file 			  		-- output file with z-scores\n"
         "        -i Niter             				-- number of iterations in the GS\n"
         "        -b burn         				-- burn parameter in the GS\n\n"

         "optional:\n"
         "        -m						-- missing data\n"
         "        -p p						-- number of process used\n"
         "        -h              				-- help\n\n");
}

void print_mat(double*A, int N, int M) {

	int i,j;
	for(i=0; i<N; i++) {
		for(j=0; j<M; j++) {
			printf("%5.5G ",A[i*M+j]);
		}
		printf("\n");
	}
	printf("\n");
}

void print_summary (     int N, int M, int K, int D, int Niter, int burn,
                        int m, char *output, char *input, char *cov_file, int num_thrd) {

   printf("Summary of the options:\n\n"
         "        -n 	%d\n"  
         "        -L  	%d\n"
         "        -K	%d\n"
         "        -D	%d\n"
         "        -o	%s\n"
         "        -i	%d\n" 
         "        -b	%d\n" 
         "        -p	%d\n"
	 "	-g    	%s\n"
	 "	-v	%s\n", N,M,K,D,output,Niter,burn,num_thrd,input,cov_file);

   if(m)
	printf("	-m 	\n");

   printf("\n");
}

