#ifndef READ_H
#define READ_H

#define SEP " " // Séparateur utilisé dans le fichier

void read_data_float(char *file_data, int N, int M, float* dat);

void read_data_float2(char *file_data, int N, int M, float* dat);

void read_data_double(char *file_data, int N, int M, double* dat);

void read_data_double2(char *file_data, int N, int M, double* dat);

void read_data_int(char *file_data, int N, int M, int* dat);

#endif // READ_H
