#ifndef THREAD_U_H
#define THREAD_U_H

void slice_mU_U(void* G);

void slice_rand_U(void* G);

void slice_inv_cov_U(void* G);

#endif // THREAD_LIKE_H

