#ifndef THREAD_V_H
#define THREAD_V_H

void slice_mV_V(void* G);

void slice_rand_V(void* G);

void slice_inv_cov_V(void* G);

#endif // THREAD_LIKE_H

