/*
    LFMM, file: thread_V.c
    Copyright (C) 2012 Eric Frichot

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include "thread.h"
#include "rand.h"
#include "thread_beta.h"
#include <string.h>
#include <math.h>
#include <time.h>
#include <float.h>

void slice_mV_V(void* G) {

	Matrix Ma = (Matrix) G;
	float *R = Ma->R;
	double *U = Ma->U;
	double *beta = Ma->beta;
	double *C = Ma->C;
	double *m_V = Ma->m;
	int N = Ma->N;
	int M = Ma->M;
	int K = Ma->K;
	int D = Ma->D;
	double *tmp_j = (double *)malloc(N*sizeof(double));
	int nb_data = M;
	int s = Ma->slice;
	int num_thrd = Ma->num_thrd;
	int from = (s * nb_data)/num_thrd; // note that this 'slicing' works fine
	int to = ((s+1) * nb_data)/num_thrd; // even if SIZE is not divisible by num_thrd
	int i,j,k,d;

	for(j=from; j<to; j++) {
               for (i=0; i<N; i++) {
                                tmp_j[i] = (double)(R[i*M+j]);
                                for (k=0; k<K; k++) {
                                        tmp_j[i] -= C[i*K+k]*beta[k*M+j];
                                }
                }
                for (d=0; d<D; d++) {
                        m_V[d*M+j] = 0;
                        for (i=0; i<N; i++)
                                m_V[d*M+j] += U[d*N+i] * tmp_j[i];
                }

	}
	free(tmp_j);
}

void slice_rand_V(void* G) {

	Matrix Ma = (Matrix) G;
	double *m_V = Ma->m;
	double *inv_cov_V = Ma->inv_cov;
	double *V = Ma->V;
	double *L = Ma->L;
	double alpha_R = Ma->alpha_R;
	int M = Ma->M;
	int D = Ma->D;
	int nb_data = M;
	int s = Ma->slice;
	int num_thrd = Ma->num_thrd;
	int from = (s * nb_data)/num_thrd; // note that this 'slicing' works fine
	int to = ((s+1) * nb_data)/num_thrd; // even if SIZE is not divisible by num_thrd
	int j,d,dp;
        double* mu=(double*)calloc(D,sizeof(double));
        double* y=(double*)calloc(D,sizeof(double));


	for(j=from; j<to; j++) {
                for(d=0;d<D;d++) {
                        mu[d] = 0;
                        for(dp=0;dp<D;dp++) {
                                mu[d] += inv_cov_V[d*D+dp] * m_V[dp*M+j];
                        }
                        mu[d] *= alpha_R;
                }
                mvn_rand(mu,L,D,y);
                for(d=0;d<D;d++)
                        V[d*M+j] = y[d];
	}
	free(mu);
	free(y);
}

void slice_inv_cov_V(void* G) {

	Matrix Ma = (Matrix) G;
	double *inv_cov_V = Ma->inv_cov;
	double *U = Ma->U;
	int N = Ma->N;
	int D = Ma->D;
	double alpha = Ma->alpha;
	double alpha_R = Ma->alpha_R;
	int nb_data = D;
	int s = Ma->slice;
	int num_thrd = Ma->num_thrd;
	int from = (s * nb_data)/num_thrd; // note that this 'slicing' works fine
	int to = ((s+1) * nb_data)/num_thrd; // even if SIZE is not divisible by num_thrd
	int i,d1,d2;

        for(d1=from; d1<to; d1++) {
                for(d2=0; d2<D; d2++) {
                        inv_cov_V[d1*D+d2] = 0;
                        for(i=0; i<N; i++)
                                inv_cov_V[d1*D+d2] += U[d1*N+i]* U[d2*N+i];
                        inv_cov_V[d1*D+d2] *= alpha_R;
                }
                inv_cov_V[d1*D+d1] += alpha;

        }
}

