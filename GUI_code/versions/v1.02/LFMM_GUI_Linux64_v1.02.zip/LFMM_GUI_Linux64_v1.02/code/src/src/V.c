#include <stdio.h>
#include <stdlib.h>
#include "V.h"
#include "data.h"
#include "matrix.h"
#include "cholesky.h"
#include "inverse.h"
#include "rand.h"
#include "thread.h"
#include "thread_V.h"

extern void slice_mV_V(void *G);
extern void slice_rand_V(void *G);
extern void slice_inv_cov_V(void *G);

void create_m_V(double* U, float* R, double *C, double *beta, double *m_V, 
		int M, int N, int D, int K, float *datb, int num_thrd) {

	//int i,j,d,k;
	//double *tmp_j = (double *)malloc(N*sizeof(double)); 


        //if (num_thrd > 1) {
                thread_fct(R, datb,  U, NULL,C,beta,m_V,NULL,NULL,
                                K,D, M, N, num_thrd,slice_mV_V,0,0);
	/*
        } else {


	for(j=0; j<M; j++) {
		for (i=0; i<N; i++) {
				tmp_j[i] = (double)(R[i*M+j]);
				for (k=0; k<K; k++) {
					tmp_j[i] -= C[i*K+k]*beta[k*M+j];
				}
		}
		for (d=0; d<D; d++) {
			m_V[d*M+j] = 0;
			for (i=0; i<N; i++)
				m_V[d*M+j] += U[d*N+i] * tmp_j[i];
		}
	}
	}
	free(tmp_j);
	*/
}

void create_inv_cov_V(double* inv_cov_V, double alpha, double alpha_R, double *U, 
		     int D, int N, int num_thrd) {

	int d1,d2,i;
	double *tmp = (double*)calloc(D*D,sizeof(double));

        if (num_thrd > 1) {
                thread_fct(NULL, NULL,  U, NULL,NULL,NULL,NULL,tmp,NULL,
                                0,D, 0, N, num_thrd,slice_inv_cov_V,alpha,alpha_R);
        } else {
	for(d1=0; d1<D; d1++) {
		for(d2=0; d2<D; d2++) {
			tmp[d1*D+d2] = 0;
			for(i=0; i<N; i++)
				tmp[d1*D+d2] += U[d1*N+i]* U[d2*N+i];
			tmp[d1*D+d2] *= alpha_R;
		}
		tmp[d1*D+d1] += alpha;
	}	
	}	

	// inverse
	if (D == 1) {
		inv_cov_V[0] = 1/tmp[0];
	} else {
		fast_inverse(tmp,D,inv_cov_V);
	}

	free(tmp);
} 

void rand_V(double* V, double* m_V, double* inv_cov_V, double alpha_R, int D, int M, int num_thrd) {

	double* L=(double*)calloc(D*D,sizeof(double));
	double* mu=(double*)calloc(D,sizeof(double));
	double* y=(double*)calloc(D,sizeof(double));
	int j,d,dp;	


	cholesky(inv_cov_V,D,L);

        if(num_thrd > 1) {
                thread_fct(NULL, NULL,  NULL, V,NULL,NULL,m_V,inv_cov_V,L,
                                0,D, M, 0, num_thrd,slice_rand_V,0,alpha_R);
        } else {
	for(j=0;j<M;j++) {
		for(d=0;d<D;d++) {
			mu[d] = 0;
			for(dp=0;dp<D;dp++) {
				mu[d] += inv_cov_V[d*D+dp] * m_V[dp*M+j];
			}
			mu[d] *= alpha_R;
		}
		mvn_rand(mu,L,D,y);
		for(d=0;d<D;d++)
			V[d*M+j] = y[d];
	}
	}
	free(L);
	free(mu);
	free(y);

}

