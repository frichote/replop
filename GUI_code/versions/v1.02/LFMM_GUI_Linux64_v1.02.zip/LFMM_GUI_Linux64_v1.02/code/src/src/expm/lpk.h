#ifndef LPK_H
#define LPK_H

#include "f2c.h"

int dgetrf_(integer *m, integer *n, doublereal *a, integer *
        lda, integer *ipiv, integer *info);

int dgetri_(integer *n, doublereal *a, integer *lda, integer
        *ipiv, doublereal *work, integer *lwork, integer *info);

#endif // INVERSE_H

