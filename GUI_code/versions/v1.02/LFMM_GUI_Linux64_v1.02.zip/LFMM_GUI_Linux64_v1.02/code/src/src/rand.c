#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "rand.h"
#include "cholesky.h"

double zscore2pvalue(double z) {

	double res = 0;
	double step = 0.0001;
	double from; 
	if (z<0)
		z *= -1;
	from = -z;
	while(from < z) {
		res += step*1/sqrt(2*PI)*exp(-from*from/2);
		from += step;
	}
	
	return 1.0-res;
}

void mvn_rand(double* mu, double* L, int D, double* y) {

	int i,j;
	double *x = (double *)malloc(D*sizeof(double));

	for(i=0;i<D;i++)
		x[i] = rand_normal_r();


	for(i=0;i<D;i++) {
		y[i] = mu[i];
		for(j=0;j<D;j++) {
			y[i] += L[j*D+i]*x[j]; 
		}
	}
	free(x);
}

void init_random() {
        srand(time(NULL));
}

// Don t forget to initialize the random
int rand_int(int size) {

        int i;
        float r;
        float sum;

        r = rand()/(float)RAND_MAX * size;


        sum = 0;
        for(i=0; i<size; i++) {
                sum += 1.0;
                if ( r <= sum) {
                        return i;
                }
        }
        return -1;
}

void rand_matrix_double(double* A, int M, int N) {

	int i;
	for(i=0;i<N*M;i++) {
		A[i] = rand_double(0,1);
	}
}

double rand_double(double min, double max) {

        return rand()/(double)RAND_MAX * (max - min) + min;

}

void rand_matrix_float(float* A, int M, int N) {

	int i;
	for(i=0;i<N*M;i++) {
		A[i] = rand_float(0,1);
	}
}

float rand_float(float min, float max) {

        return rand()/(float)RAND_MAX * (max - min) + min;

}

// Don t forget to initialize the random
int rand_vector(float *Pi, int size) {

        int i;
        float r;
        float sum;

        r = rand()/(float)RAND_MAX;


        sum = 0;
        for(i=0; i<size; i++) {
                sum += Pi[i];
                if ( r <= sum) {
                        return i;
                }
        }
        return -1;
}

int rand_exp_int(float mean) {

        float r;
        rand_exp(mean,&r);
        
        return (int)r+1;
}

void rand_exp(float alpha, float *r) {

       *r = -  alpha * log(rand()/(float)RAND_MAX);
}

double drand()   /* uniform distribution, (0..1] */
{
  return (rand()+1.0)/(RAND_MAX+1.0);
}

double rand_gamma(int alpha, double beta) { // TO CHECK

        int i = 0;
        double y = 0;
	
	y = 0;
        for(i = 0;i<alpha;i++) {
        	y += log(drand());
	}
        y *= -beta;

	return y;
}

double rand_normal_r() {

        return sqrt(-2 * log (drand())) * cos(2 * PI * drand());
}

double rand_normal( double mean, double var) {

        double res;

        res = sqrt(-2 * log (drand())) * cos(2 * PI * drand());

        return sqrt(var) * res + mean;
}

int rand_min(float *dist_min, int* range_min, int min_nb) {

        int r = rand_vector(dist_min, min_nb);

        if (r==0) {
                return rand_int(range_min[0]);
        } else {
                return range_min[r-1] + rand_int(range_min[r]-range_min[r-1]);
        }
}
