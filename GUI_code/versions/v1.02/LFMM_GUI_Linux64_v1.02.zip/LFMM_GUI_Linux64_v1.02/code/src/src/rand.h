#ifndef RAND_H
#define RAND_H

#define PI (3.141592653589793)

double zscore2pvalue(double z);

double rand_normal_r();

void rand_matrix_double(double* A, int M, int N);

void rand_matrix_float(float* A, int M, int N);

void mvn_rand(double* mu, double* L, int D, double* y);

/*
 * Precondition:
 * Purpose : initialise srand. It has to be done only once.
 */
void init_random();

/*
 * Precondition: initialised srand
 * Purpose: return a uniform random int in [0,size-1] 
 */
int rand_int(int size);

float rand_float(float min, float max);

double rand_double(double min, double max);

/*
 * Precondition: initialised srand, Pi != NULL
 * Purpose: return a random int in [0,size-1] with frequency Pi
 */
int rand_vector(float *Pi, int size);

/*
 * Precondition: initialised srand
 * Purpose: return a random float among an exponential law of parameter alpha
 */
void  rand_exp(float alpha, float *r);

/*
 * Precondition: initialised srand
 * Purpose: return a random float among a gamma dist of alpha, beta
 */
double rand_gamma(int alpha, double beta);

/*
 * Precondition: initialised srand
 * Purpose: return a random float among a normal dist of mean and var
 */
double rand_normal( double mean, double var);

int rand_min(float *dist_min, int* range_min, int min_nb);

int rand_exp_int(float mean);

#endif // RAND_H 
