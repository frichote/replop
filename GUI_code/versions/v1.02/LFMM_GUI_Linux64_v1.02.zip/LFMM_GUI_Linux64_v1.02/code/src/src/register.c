#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "register.h"
#include "print.h"
#include "error.h"

void analyse_param(	int argc, char *argv[], int *D, 
			int *N, int* M, int* K, int* Niter, int* burn,
			int *m, char *output, char *input, char *cov_file, 
			int* g_data, int* g_cov, int* num_thrd) {
        int i;
	int out = 0;

        for (i = 1; i < argc; i++) {
                if (argv[i][0] == '-') {
                        switch (argv[i][1]) {
                        case 'D':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","D (number of covariables)",0);
                                *D = atoi(argv[i]);
                                break;
                        case 'n':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","n (number of individuals)",0);
                                *N = atoi(argv[i]);
                                break;
                        case 'L':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","L (number of SNPs)",0);
                                *M = atoi(argv[i]);
                                break;
                        case 'K':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","K (number of latent factors)",0);
                                *K = atoi(argv[i]);
                                break;
			case 'i':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","i (number of iterations in the GS)",0);
                                *Niter = atoi(argv[i]);
                                break;
                        case 'm':   // global
                                *m = 1;
                                break;
                        case 'h':   // global
                                print_help();
                                exit(1);
                                break;
			case 'b':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","b (burn parameter in the GS)",0);
                                *burn = atoi(argv[i]);
                                break;
			case 'p':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","p (number of processes used)",0);
                                *num_thrd = atoi(argv[i]);
                                break;
                        case 'o':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","o (output file with z-scores)",0);
                                strcpy(output,argv[i]);
				out = 1;
                                break;
                        case 'g':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","g (genotype file)",0);
                                *g_data = 0;
                                strcpy(input,argv[i]);
                                break;
                        case 'v':
                                i++;
                                if (argc == i || argv[i][0] == '-')
					print_error("cmd","v (variable file)",0);
                                *g_cov = 0;
                                strcpy(cov_file,argv[i]);
                                break;
                        default:    print_error("basic",NULL,0);
                        }
                }
        }

        if (*g_data == -1)
		print_error("option","-g genotype_file",0);

        if (*g_cov == -1)
		print_error("option","-v variable_file",0);

        if (!out)
		print_error("option","-o output_file",0);
        
        if (*D == 0 || *K == 0 || *M == 0 || *N == 0 || *burn == 0 || *Niter == 0)
		print_error("missing",NULL,0);

	if (*burn >= *Niter-1)
		print_error("specific","the number of iterations for burnin (b) is greater than the number total of iterations (i) minus one. i should be such as (i>b+1)",0);
	
}


