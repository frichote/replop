#ifndef THREAD_LIKE_H
#define THREAD_LIKE_H

typedef struct _matrix * Matrix;

struct _matrix {
        float *R;
	float *datb;
	double *U;
	double *V;
	double *C;
	double *beta;
	double *m;
	double *inv_cov;
	double *L;
	int D;
	int N;
	int M;	
	int K;	
	double alpha;	
	double alpha_R;	
        int slice;
        int c;
        int num_thrd;
}matrix;

void thread_fct(float *R, float *datb, double *U, double *V, double *C,
		double *beta, double *m, double *inv_cov, double *L,
		int K, int D, int M, int N, int num_thrd, void (*fct)(),
		double alpha, double alpha_R);

#endif // THREAD_LIKE_H

