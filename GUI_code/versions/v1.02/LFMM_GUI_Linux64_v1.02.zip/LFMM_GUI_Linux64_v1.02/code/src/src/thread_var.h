#ifndef THREAD_VAR_H
#define THREAD_VAR_H

typedef struct _mat * Mat;

struct _mat {
        float *R;
	double *U;
	double *V;
	double *C;
	double *beta;
	int D;
	int N;
	int M;	
	int K;	
	double mean;	
	double res;	
        int slice;
        int num_thrd;
}mat;

void thrd_var(float *R, double *U, double *V, double *C,
		double *beta, int K, int D, int M, int N, int num_thrd, void (*fct)(),
		double mean, double *res);

void slice_mean(void* G);

void slice_var(void* G);

#endif // THREAD_VAR_H

