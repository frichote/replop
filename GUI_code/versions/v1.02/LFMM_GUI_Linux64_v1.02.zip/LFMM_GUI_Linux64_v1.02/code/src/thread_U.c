/*
    LFMM, file: thread_U.c
    Copyright (C) 2012 Eric Frichot

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include "thread.h"
#include "rand.h"
#include "thread_beta.h"
#include <string.h>
#include <math.h>
#include <time.h>
#include <float.h>

void slice_mU_U(void* G) {

	Matrix Ma = (Matrix) G;
	float *R = Ma->R;
	double *beta = Ma->beta;
	double *V = Ma->V;
	double *C = Ma->C;
	double *m_U = Ma->m;
	int N = Ma->N;
	int M = Ma->M;
	int K = Ma->K;
	int D = Ma->D;
	double *tmp_i = (double *)malloc(M*sizeof(double));
	int nb_data = N;
	int s = Ma->slice;
	int num_thrd = Ma->num_thrd;
	int from = (s * nb_data)/num_thrd; // note that this 'slicing' works fine
	int to = ((s+1) * nb_data)/num_thrd; // even if SIZE is not divisible by num_thrd
	int i,j,k,d;

	for(i=from; i<to; i++) {
                for (j=0; j<M; j++) {
                                tmp_i[j] = (double)(R[i*M+j]);
                                for (k=0; k<K; k++) {
                                        tmp_i[j] -= C[i*K+k]*beta[k*M+j];
                                }
                }
                for (d=0; d<D; d++) {
                        m_U[i*D+d] = 0;
                        for (j=0; j<M; j++)
                                m_U[i*D+d] += V[d*M+j] * tmp_i[j];
                }
        }

	free(tmp_i);
}

void slice_rand_U(void* G) {

	Matrix Ma = (Matrix) G;
	double *m_U = Ma->m;
	double *inv_cov_U = Ma->inv_cov;
	double *U = Ma->U;
	double *L = Ma->L;
	double alpha_R = Ma->alpha_R;
	int N = Ma->N;
	int D = Ma->D;
	int nb_data = N;
	int s = Ma->slice;
	int num_thrd = Ma->num_thrd;
	int from = (s * nb_data)/num_thrd; // note that this 'slicing' works fine
	int to = ((s+1) * nb_data)/num_thrd; // even if SIZE is not divisible by num_thrd
	int i,d,dp;
        double* mu=(double*)calloc(D,sizeof(double));
        double* y=(double*)calloc(D,sizeof(double));

        for(i=from;i<to;i++) {
                for(d=0;d<D;d++) {
                        mu[d] = 0;
                        for(dp=0;dp<D;dp++) {
                                mu[d] += inv_cov_U[d*D+dp] * m_U[i*D+dp];
                        }
                        mu[d] *= alpha_R;
                }
                mvn_rand(mu,L,D,y);
                for(d=0;d<D;d++)
                        U[d*N+i] = y[d];
        }
	free(mu);
	free(y);
}

void slice_inv_cov_U(void* G) {

	Matrix Ma = (Matrix) G;
	double *inv_cov_U = Ma->inv_cov;
	double *V = Ma->V;
	int M = Ma->M;
	int D = Ma->D;
	double alpha = Ma->alpha;
	double alpha_R = Ma->alpha_R;
	int nb_data = D;
	int s = Ma->slice;
	int num_thrd = Ma->num_thrd;
	int from = (s * nb_data)/num_thrd; // note that this 'slicing' works fine
	int to = ((s+1) * nb_data)/num_thrd; // even if SIZE is not divisible by num_thrd
	int j,d1,d2;

        for(d1=from; d1<to; d1++) {
                for(d2=0; d2<D; d2++) {
                        inv_cov_U[d1*D+d2] = 0;
                        for(j=0; j<M; j++)
                                inv_cov_U[d1*D+d2] += (V[d1*M+j]* V[d2*M+j]);
                        inv_cov_U[d1*D+d2] *= alpha_R;
                }
                inv_cov_U[d1*(D+1)] += alpha;
        }
}

