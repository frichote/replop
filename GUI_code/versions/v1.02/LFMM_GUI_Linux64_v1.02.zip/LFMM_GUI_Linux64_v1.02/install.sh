#!/bin/sh

tmp=$(uname -m)
tmp2=$(uname -a)

if [ "x86_64" != "$tmp" ]; then
    echo "\n ERROR: you downloaded the 64bit linux version but your version is:\n $tmp2\n" 
    return 1
fi

cd code
make clean
make
if [ ! -e "GS" ]; then
        echo "\nERROR: an error occured during the compilation of LFMM command-line program."
	cd ..
	return 1
fi
cd ..

# Error a ne pas oublier.
cp code/src/LFMM_GUI ./
if [ ! -e "LFMM_GUI" ]; then
        echo "\nERROR: an error occured during the creation of LFMM GUI program."
	return 1
fi

echo "\nSUCCESS: LFMM GUI program was created without error."
return 0

