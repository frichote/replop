#ifndef U_H
#define U_H
#include "data.h"

void create_m_U(double* V, float* R, double *C, double *beta, double *m_U, 
		     int M, int N, int D, int K, float *datb, int num_thrd);

void create_inv_cov_U(double* inv_cov_U, double alpha, double alpha_R, double *V, 
		     int D, int M, int num_thrd); 

void rand_U(double* U, double* m_U, double* inv_cov_U, double alpha_R, int D, int N, int num_thrd);

#endif // U_H
