#ifndef V_H
#define V_H
#include "data.h"

void create_m_V(double* U, float* R, double *C, double *beta, double *m_V, 
		     int M, int N, int D, int K, float *datb, int num_thrd);

void create_inv_cov_V(double* inv_cov_V, double alpha, double alpha_R, double *C, 
		     int D, int N, int num_thrd); 

void rand_V(double* V, double* m_V, double* inv_cov_V, double alpha_R, int D, int M, int num_thrd);

#endif // V_H
