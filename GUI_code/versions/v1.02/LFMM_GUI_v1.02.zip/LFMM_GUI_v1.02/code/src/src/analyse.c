#include <stdio.h>
#include <stdlib.h>
#include "analyse.h"
#include "error.h"

void analyse_col(float *data, int N, int M, int* nM, int missing, int* I) {

	int i,j,ind;
	int* col = (int *)malloc(M*sizeof(int));
	float* tmp = (float *)calloc(M,sizeof(float));

	for(j = 0; j < M; j++) {
		col[j] = 1;        
		tmp[j] = 0;        
	}

	if (!missing) {
		for(i=1; i<N; i++) {
			for(j = 0; j < M; j++) {
				col[j] = col[j] && (data[i*M+j] == data[j]) ;        
			}
		}
	} else {
		ind = 0;
		i = 0;
		while (ind < M && i<N) {
			for(j = 0; j < M; j++) {
				if (!tmp[j] && I[i*M+j]) {
					tmp[j] = data[i*M+j];
					ind ++;
				}
			}
			i++;
		}
		if (i == M) {
			print_error("interne",NULL,0);
		}
		for(i=1; i<N; i++) {
			for(j = 0; j < M; j++) {
				if (I[i*M+j])
					col[j] = col[j] && (data[i*M+j] == tmp[j]);        
			}
		}

	} 

	*nM = 0;
	for(j = 0; j < M; j++) {
		if (col[j] == 1) {
			(*nM)++;       
		} 
	}

	free(col);
	free(tmp);
}

void analyse_row(float *data, int N, int M, int* row, int * nN) {

	int i,j;

	for(i = 0; i < N; i++) {
		row[i] = 1;        
	}

	for(i=0; i<N; i++) {
		for(j = 1; j < M; j++) {
			row[i] = row[i] && (data[i*M+j] == data[i*M]) ;        
		}
	}

	*nN = 0;
	for(i = 0; i < N; i++) {
		if (row[i] == 1) {
			(*nN)++;       
		} 
	}
}

