#ifndef BETA_H
#define BETA_H
#include "data.h"

void create_m_beta(double* C, float* R, double *U, double *V, double *m_beta, 
		     int M, int N, int D, int K, float* datb, int num_thrd);

void create_CCt(double *tmp, double *C, int K, int N);

void create_inv_cov_beta(double* inv_cov_beta, double *alpha_beta, double alpha_R,
		     int K, double *tmp); 

void rand_beta(double* beta, double* m_beta, double* inv_cov_beta, double alpha_R, int K, int M, int num_thrd);

#endif // BETA_H
