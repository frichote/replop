#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "normalize.h"

void normalize_data(float *data, int N, int M, int* I, int missing_data) {

	float mean;
	int i,j,sum;

	if(!missing_data) {
		for(j = 0; j < M; j++) {
			mean = 0;
			for(i=0; i<N; i++) {
				mean += data[i*M+j];
			}
			mean /= N;
			for(i=0; i<N; i++) {
				data[i*M+j] = (data[i*M+j] - mean); 
			}
		}
	} else {
		for(j = 0; j < M; j++) {
			mean = 0;
			sum = 0;
			for(i=0; i<N; i++) {
				if (I[i*M+j]) { 
					mean += data[i*M+j];
					sum ++;
				}
			}
			mean /= sum;
			for(i=0; i<N; i++) {
				if (I[i*M+j]) {
					data[i*M+j] = (data[i*M+j] - mean); 
				}
			}
		}
	}
}

void normalize_cov(double *C, int N, int K) {

	double mean;
	int i, k;

		for(k = 0; k < K; k++) {
			mean = 0;
			for(i=0; i<N; i++) {
				mean += C[i*K+k];
			}
			mean /= N;
			/*
			cov = 0;
			for(i=0; i<N; i++) {
				cov += (C[i*K+k] - mean) * (C[i*K+k] - mean); 
			}
			cov /= (N-1);
			*/
			for(i=0; i<N; i++) {
				C[i*K+k] = (C[i*K+k] - mean); // sqrt(cov); 
			}
		}
}

