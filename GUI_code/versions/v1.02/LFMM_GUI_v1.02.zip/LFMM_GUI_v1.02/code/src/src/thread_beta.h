#ifndef THREAD_BETA_H
#define THREAD_BETA_H

void slice_mbeta_beta(void* G);

void slice_rand_beta(void* G);

#endif // THREAD_LIKE_H

